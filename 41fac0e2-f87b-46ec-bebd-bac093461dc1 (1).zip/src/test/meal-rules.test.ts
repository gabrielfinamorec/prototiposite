import { describe, it, expect } from 'vitest';
import { mealDay, mealServedAt, manualMealSchema, visitorMealSchema } from '@/lib/meal-rules';
const company_id = '00000000-0000-4000-8000-000000000001';
const employee_id = '00000000-0000-4000-8000-000000000002';
const image = 'data:image/jpeg;base64,' + 'A'.repeat(100);
describe('regras de almoço', () => {
  it('vira o dia exatamente à meia-noite de Brasília', () => {
    expect(mealDay(new Date('2026-10-20T02:59:59Z'))).toBe('2026-10-19');
    expect(mealDay(new Date('2026-10-20T03:00:00Z'))).toBe('2026-10-20');
  });
  it('aceita data retroativa manual e preserva o horário de Brasília', () => {
    expect(manualMealSchema.parse({ company_id, employee_id, image, meal_date: '2026-10-10', time: '12:30' }).meal_date).toBe('2026-10-10');
    expect(mealServedAt('2026-10-10', '12:30')).toBe('2026-10-10T15:30:00.000Z');
  });
  it('exige foto em todo registro manual', () => expect(manualMealSchema.safeParse({ company_id, employee_id, meal_date: '2026-10-19', time: '12:00' }).success).toBe(false));
  it('exige nome e foto de visita no tablet', () => {
    expect(visitorMealSchema.safeParse({ company_id, visitor_name: '', image }).success).toBe(false);
    expect(visitorMealSchema.safeParse({ company_id, visitor_name: 'Ana' }).success).toBe(false);
    expect(visitorMealSchema.parse({ company_id, visitor_name: ' Ana ', image }).visitor_name).toBe('Ana');
  });
  it('permite visita sem colaborador e rejeita vínculo ambíguo', () => {
    expect(manualMealSchema.safeParse({ company_id, visitor_name: 'Ana', image, meal_date: '2026-10-19', time: '12:00' }).success).toBe(true);
    expect(manualMealSchema.safeParse({ company_id, employee_id, visitor_name: 'Ana', image, meal_date: '2026-10-19', time: '12:00' }).success).toBe(false);
  });
});