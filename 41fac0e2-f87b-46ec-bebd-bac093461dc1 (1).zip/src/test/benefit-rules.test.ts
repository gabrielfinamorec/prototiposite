import { describe, it, expect } from 'vitest';
import { eligiblePeople, benefitSchema } from '@/lib/benefit-rules';
const emps = [{ id: 'e1', company_id: 'A' }, { id: 'e2', company_id: 'B' }];
const deps = [{ id: 'd1', company_id: 'A' }];
describe('benefícios', () => {
  it('benefício de colaborador lista só colaboradores da empresa', () => expect(eligiblePeople({ company_id: 'A', target: 'colaborador' }, emps, deps).map(p => p.id)).toEqual(['e1']));
  it('benefício de dependente lista só dependentes da empresa', () => expect(eligiblePeople({ company_id: 'A', target: 'dependente' }, emps, deps).map(p => p.id)).toEqual(['d1']));
  it('nome do benefício é obrigatório', () => expect(benefitSchema.safeParse({ company_id: crypto.randomUUID(), name: ' ', target: 'colaborador' }).success).toBe(false));
});
