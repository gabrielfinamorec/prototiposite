import { describe, it, expect } from 'vitest';
import { defaultLayouts, encodeCsv } from '@/lib/export-layouts';
import { connectionSchema } from '@/lib/finance-schema';
import { visualEdges } from '@/lib/org-connections';
import { createJobPdf } from '@/lib/job-pdf';
import { demoData } from '@/lib/finance-demo';
describe('Ligações livres e exportações',()=>{
  it('aceita e preserva conexões pelos quatro lados',()=>{for(const side of ['top','right','bottom','left']){const value=connectionSchema.parse({company_id:'00000000-0000-4000-8000-000000000001',source_id:'00000000-0000-4000-8000-000000000002',target_id:'00000000-0000-4000-8000-000000000003',source_handle:side,target_handle:side});expect(value.source_handle).toBe(side);expect(value.target_handle).toBe(side);}});
  it('sem ligações manuais não desenha nenhuma seta',()=>{expect(visualEdges([],'empresa')).toEqual([]);});
  it('usa os lados salvos e não mistura empresas',()=>{expect(visualEdges([{id:'a',company_id:'empresa',source_id:'1',target_id:'2',source_handle:'bottom',target_handle:'top'},{id:'b',company_id:'outra',source_id:'3',target_id:'4'}],'empresa')).toEqual([{id:'a',source:'1',target:'2',sourceHandle:'bottom',targetHandle:'top'}]);});
  it('exporta somente as colunas escolhidas na ordem escolhida',()=>{const layout={...defaultLayouts().companies,fields:['CNPJ','Nome'],delimiter:',' as const};expect(encodeCsv([{Nome:'Empresa',CNPJ:'123'}],layout)).toBe('\uFEFF"CNPJ","Nome"\r\n"123","Empresa"');});
  it('remove cabeçalhos quando desativados',()=>{expect(encodeCsv([{Nome:'Empresa'}],{...defaultLayouts().companies,fields:['Nome'],headers:false})).toBe('\uFEFF"Empresa"');});
  it('orientação paisagem altera as dimensões reais do PDF',async()=>{const pdf=createJobPdf(demoData.jobs.slice(0,1),demoData,{...defaultLayouts().jobs,orientation:'landscape'});const text=await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=reject;reader.readAsText(pdf);});const dimensions=text.match(/MediaBox \[0 0 ([\d.]+) ([\d.]+)\]/);expect(Number(dimensions?.[1])).toBeCloseTo(841.89,2);expect(Number(dimensions?.[2])).toBeCloseTo(595.28,2);});
});