import { describe, expect, it } from 'vitest';
import { nationalHolidays, resolveDay } from '@/lib/calendar-rules';

describe('calendário da empresa', () => {
  it('Natal é feriado obrigatório', () => expect(nationalHolidays(2026)['2026-12-25']?.kind).toBe('obrigatorio'));
  it('Sexta-feira Santa 2026 é 03/04', () => expect(nationalHolidays(2026)['2026-04-03']?.title).toBe('Sexta-feira Santa'));
  it('Carnaval é facultativo', () => expect(nationalHolidays(2026)['2026-02-17']?.kind).toBe('facultativo'));
  it('domingo sem cadastro é folga', () => expect(resolveDay('2026-10-18').kind).toBe('folga'));
  it('dia útil sem cadastro é trabalhado', () => expect(resolveDay('2026-10-19').kind).toBe('trabalhado'));
  it('dia salvo prevalece sobre feriado', () => expect(resolveDay('2026-12-25', { kind: 'trabalhado', title: '' }).kind).toBe('trabalhado'));
});
