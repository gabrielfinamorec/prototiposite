import { describe,it,expect } from 'vitest';
import { assignedEmployees,documentStatus,expiryDate,typeSchema,typeDefaults } from '../lib/document-rules';
describe('Gestão de documentos',()=>{
 it('documentos novos permanecem pendentes mesmo sem validade',()=>expect(documentStatus({state:'pendente',expiry_date:null},'2026-10-19')).toBe('pendente'));
 it('documento validado fica em dia sem validade',()=>expect(documentStatus({state:'em dia',expiry_date:null},'2026-10-19')).toBe('em dia'));
 it('vence somente depois da data de validade',()=>{expect(documentStatus({state:'em dia',expiry_date:'2026-10-19'},'2026-10-19')).toBe('em dia');expect(documentStatus({state:'em dia',expiry_date:'2026-10-19'},'2026-10-20')).toBe('vencido');});
 it('cancelamento prevalece sobre vencimento',()=>expect(documentStatus({state:'cancelado',expiry_date:'2026-10-01'},'2026-10-19')).toBe('cancelado'));
 it('calcula duração em dias',()=>expect(expiryDate('2026-10-19',30,'dias')).toBe('2026-11-18'));
 it('calcula duração em semanas',()=>expect(expiryDate('2026-10-19',2,'semanas')).toBe('2026-11-02'));
 it('calcula duração em meses com ajuste de fim do mês',()=>expect(expiryDate('2026-01-31',1,'meses')).toBe('2026-02-28'));
 it('calcula duração em anos',()=>expect(expiryDate('2026-10-19',1,'anos')).toBe('2027-10-19'));
 it('atribui a colaboradores do departamento, do cargo e diretamente sem duplicar',()=>expect(assignedEmployees({department_ids:['d1'],job_ids:['j1'],employee_ids:['e1','e3']},[{id:'e1',job_id:'j1'},{id:'e2',job_id:'j2'},{id:'e3',job_id:'j3'},{id:'e4',job_id:'j3'}],[{id:'j1',department_id:'d1'},{id:'j2',department_id:'d1'},{id:'j3',department_id:'d2'}])).toEqual(['e1','e2','e3']));
 it('limita duração ao formato de três dígitos',()=>expect(typeSchema.safeParse({...typeDefaults(),name:'Teste',responsible_id:'00000000-0000-4000-8000-000000000001',duration:1000}).success).toBe(false));
});
