import { describe, it, expect } from 'vitest';
import { nextBirthday, buildReport, mealTime, type ConsultData, type Org } from '@/lib/report-rules';
describe('aniversários', () => {
  it('ainda este ano', () => expect(nextBirthday('1990-10-25', '2026-10-19')).toEqual({ date: '2026-10-25', days: 6, age: 36 }));
  it('já passou vai para o próximo ano', () => expect(nextBirthday('1990-01-05', '2026-10-19')?.date).toBe('2027-01-05'));
  it('hoje = 0 dias', () => expect(nextBirthday('2000-10-19', '2026-10-19')?.days).toBe(0));
});
describe('almoços', () => {
  it('horário no fuso de Brasília (UTC-3)', () => expect(mealTime('2026-10-19T15:25:00+00:00')).toBe('12:25'));
  const org: Org = { companies: [{ id: 'c1', name: 'ACME' }], departments: [], jobs: [{ id: 'j1', name: 'Empacotador', department_id: 'd1' }] };
  const data: ConsultData = {
    employees: [{ id: 'e1', company_id: 'c1', job_id: 'j1', name: 'Gabriel', registration: '1', birth_date: '1990-01-01', admission_date: '2020-01-01', sex: 'M' }],
    dependents: [], vacations: [], movements: [], movementTypes: [], documents: [], documentTypes: [], benefits: [],
    meals: [{ id: 'm1', company_id: 'c1', employee_id: 'e1', meal_date: '2026-10-19', created_at: '2026-10-19T15:25:00+00:00' }],
  };
  it('relatório traz data, horário, colaborador, cargo e empresa', () => {
    const r = buildReport('almocos', data, org, '2026-10-19');
    expect(r.rows[0]).toEqual({ company_id: 'c1', date: '2026-10-19', cells: ['Gabriel', 'Colaborador', 'Empacotador', 'ACME', '19/10/2026', '12:25', 'Facial'] });
  });
  it('inclui visita retroativa pelo horário informado, não pela criação', () => {
    const r = buildReport('almocos', { ...data, meals: [{ id: 'm2', company_id: 'c1', employee_id: null, visitor_name: 'Ana Visita', meal_date: '2026-10-10', served_at: '2026-10-10T15:00:00Z', created_at: '2026-10-19T18:00:00Z', source: 'manual' }] }, org, '2026-10-19');
    expect(r.rows[0]).toEqual({ company_id: 'c1', date: '2026-10-10', cells: ['Ana Visita', 'Visita', '—', 'ACME', '10/10/2026', '12:00', 'Manual'] });
  });
});
describe('movimentações separadas', () => {
  const org: Org = { companies: [{ id: 'c1', name: 'ACME' }], departments: [{ id: 'd1', name: 'Produção' }], jobs: [{ id: 'j1', name: 'Empacotador', department_id: 'd1' }] };
  const mv = (id: string, kind: string, extra: Partial<ConsultData['movements'][number]> = {}) => ({ id, kind, company_id: 'c1', employee_id: 'e1', type_id: 't1', start_date: '2026-10-10', end_date: '2026-10-12', return_date: null, has_notice: false, notice_type: '', notice_start: null, notice_end: null, ...extra });
  const data: ConsultData = {
    employees: [{ id: 'e1', company_id: 'c1', job_id: 'j1', name: 'Gabriel', registration: '1', birth_date: '1990-01-01', admission_date: '2020-01-01', sex: 'M' }],
    dependents: [], vacations: [], documents: [], documentTypes: [], benefits: [], meals: [],
    movementTypes: [{ id: 't1', name: 'Doença' }],
    movements: [
      mv('mv1', 'atestado'),
      mv('mv2', 'afastamento', { start_date: '2026-10-01', end_date: '2026-10-20', return_date: '2026-10-20' }),
      mv('mv3', 'demissao', { start_date: '2026-11-30', end_date: null, has_notice: true, notice_type: 'trabalhado', notice_start: '2026-10-15', notice_end: '2026-11-13' }),
      mv('mv4', 'demissao', { start_date: '2026-10-05', end_date: null }),
    ],
  };
  it('o relatório de atestados só traz atestados', () => {
    const r = buildReport('atestados', data, org, '2026-10-19');
    expect(r.rows).toEqual([{ company_id: 'c1', date: '2026-10-10', cells: ['Gabriel', 'Produção', 'Empacotador', 'Doença', '10/10/2026', '12/10/2026', '3', 'Encerrado'] }]);
  });
  it('o relatório de afastamentos só traz afastamentos, com data de retorno', () => {
    const r = buildReport('afastamentos', data, org, '2026-10-19');
    expect(r.rows).toEqual([{ company_id: 'c1', date: '2026-10-01', cells: ['Gabriel', 'Produção', 'Empacotador', 'Doença', '01/10/2026', '20/10/2026', '20/10/2026', '20', 'Em andamento'] }]);
  });
  it('o relatório de avisos prévios só traz quem tem aviso, com tipo e dias', () => {
    const r = buildReport('avisos', data, org, '2026-10-19');
    expect(r.rows).toEqual([{ company_id: 'c1', date: '2026-10-15', cells: ['Gabriel', 'Produção', 'Empacotador', 'Trabalhado', '15/10/2026', '13/11/2026', '30', 'Em andamento'] }]);
  });
  it('o relatório de demissões traz as demissões e diz se tem aviso', () => {
    const r = buildReport('demissoes', data, org, '2026-10-19');
    expect(r.rows.map(x => x.cells)).toEqual([
      ['Gabriel', 'Produção', 'Empacotador', 'Doença', '30/11/2026', 'Trabalhado 15/10/2026 a 13/11/2026', 'Em aviso prévio'],
      ['Gabriel', 'Produção', 'Empacotador', 'Doença', '05/10/2026', 'Sem aviso', 'Desligado'],
    ]);
  });
});
