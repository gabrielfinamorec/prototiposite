import { describe, it, expect } from 'vitest';
import { daysBetween, movementSchema, movementStatus } from '@/lib/movement-rules';
const id='00000000-0000-4000-8000-000000000001';
describe('movimentações', () => {
  it('conta dias incluindo início e fim', () => expect(daysBetween('2026-10-01','2026-10-03')).toBe(3));
  it('demissão com aviso exige tipo e datas', () => expect(movementSchema.safeParse({kind:'demissao',employee_id:id,type_id:id,start_date:'2026-11-01',end_date:'',return_date:'',notice_start:'',notice_end:'',has_notice:true}).success).toBe(false));
  it('atestado exige data final', () => expect(movementSchema.safeParse({kind:'atestado',employee_id:id,type_id:id,start_date:'2026-11-01',end_date:'',return_date:'',notice_start:'',notice_end:''}).success).toBe(false));
  it('em aviso prévio antes do desligamento', () => expect(movementStatus({kind:'demissao',start_date:'2026-11-30',end_date:null,return_date:null,has_notice:true,notice_start:'2026-11-01',notice_end:'2026-11-30'},'2026-11-10')).toBe('Em aviso prévio'));
});
import { employeeMovementStatus } from '@/lib/movement-rules';
describe('status do colaborador', () => {
  const base = { end_date: null, return_date: null, has_notice: false, notice_start: null, notice_end: null };
  it('atestado em andamento = Atestado', () => expect(employeeMovementStatus([{ ...base, employee_id: 'a', kind: 'atestado', start_date: '2026-10-18', end_date: '2026-10-20' }], '2026-10-19')['a']).toBe('Atestado'));
  it('desligado vence afastado', () => expect(employeeMovementStatus([{ ...base, employee_id: 'a', kind: 'atestado', start_date: '2026-10-18', end_date: '2026-10-20' }, { ...base, employee_id: 'a', kind: 'demissao', start_date: '2026-10-01' }], '2026-10-19')['a']).toBe('Desligado'));
});
describe('aviso', () => { it('aviso em andamento após data de desligamento', () => expect(movementStatus({kind:'demissao',start_date:'2026-10-19',end_date:null,return_date:null,has_notice:true,notice_start:'2026-10-16',notice_end:'2026-11-19'},'2026-10-19')).toBe('Em aviso prévio')); });
