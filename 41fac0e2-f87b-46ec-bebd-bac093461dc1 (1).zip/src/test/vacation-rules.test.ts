import { describe, expect, it } from 'vitest';
import { allowedActions, vacationDays, vacationStatus } from '@/lib/vacation-rules';

const v = (state: string, finished = false) => ({ state, start_date: '2026-11-01', end_date: '2026-11-30', finished });
describe('férias', () => {
  it('conta dias incluindo início e fim', () => expect(vacationDays('2026-11-01', '2026-11-30')).toBe(30));
  it('nova solicitação fica pendente', () => expect(vacationStatus(v('pendente'), '2026-12-10')).toBe('Pendente'));
  it('aprovada antes do início fica Aprovada', () => expect(vacationStatus(v('aprovada'), '2026-10-19')).toBe('Aprovada'));
  it('aprovada no período vira Confirmada', () => expect(vacationStatus(v('aprovada'), '2026-11-01')).toBe('Confirmada'));
  it('aprovada após o fim vira Aviso', () => expect(vacationStatus(v('aprovada'), '2026-12-01')).toBe('Aviso'));
  it('aviso finalizado vira Finalizada', () => expect(vacationStatus(v('aprovada', true), '2026-12-01')).toBe('Finalizada'));
  it('cancelada prevalece', () => expect(vacationStatus(v('cancelada'), '2026-11-05')).toBe('Cancelada'));
  it('pendente pode ser aprovada', () => expect(allowedActions('Pendente')).toContain('aprovar'));
  it('confirmada não pode ser cancelada', () => expect(allowedActions('Confirmada')).not.toContain('cancelar'));
  it('confirmada pode desfazer confirmação', () => expect(allowedActions('Confirmada')).toContain('desfazer'));
});
