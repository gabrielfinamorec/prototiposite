import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { ClipboardList, Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { useFinance } from './workspace';
import { SearchSelect } from './search-select';
import { DocumentAttachments } from './document-attachments';
import { deleteMovement, deleteMovementType, getMovements, getMovementTypes, saveMovement, saveMovementType } from '@/lib/movements.functions';
import { daysBetween, initiativeLabels, kindLabels, movementKinds, movementSchema, movementStatus, movementTypeSchema, typeLabels, type MovementKind } from '@/lib/movement-rules';
import type { Attachment } from '@/lib/document-rules';
import { ClearFilters, confirmDelete } from './confirm-delete';

const br = (d: string | null) => (d ? d.split('-').reverse().join('/') : '—');
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const err = (e: unknown) => (e instanceof Error ? e.message : 'Não foi possível salvar');

function useTypes() {
  const { session } = useFinance();
  const get = useServerFn(getMovementTypes);
  return useQuery({ queryKey: ['movement-types', session?.user.id], queryFn: () => get(), enabled: !!session });
}

function Filter({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options?: { value: string; label: string }[] }) {
  return <label className="table-filter">{label}{options
    ? <select aria-label={`Filtrar ${label}`} value={value || 'all'} onChange={e => onChange(e.target.value === 'all' ? '' : e.target.value)}><option value="all">Todos</option>{options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}</select>
    : <Input aria-label={`Filtrar ${label}`} value={value} onChange={e => onChange(e.target.value)} />}</label>;
}

type TypeForm = { id?: string; kind: MovementKind; name: string; description: string; initiative: '' | 'empresa' | 'colaborador' | 'outro'; requires_document: boolean; active: boolean };

export function MovementTypes() {
  const { session, requireAccess } = useFinance();
  const query = useTypes();
  const qc = useQueryClient();
  const save = useServerFn(saveMovementType), remove = useServerFn(deleteMovementType);
  const [tab, setTab] = useState<MovementKind>('atestado');
  const [nameF, setNameF] = useState(''), [activeF, setActiveF] = useState('');
  const [form, setForm] = useState<TypeForm | null>(null);
  const [busy, setBusy] = useState(false), [error, setError] = useState('');
  const rows = (query.data ?? []).filter(t => t.kind === tab && t.name.toLocaleLowerCase().includes(nameF.toLocaleLowerCase()) && (!activeF || String(t.active) === activeF));
  const refresh = () => qc.invalidateQueries({ queryKey: ['movement-types'] });
  const submit = async () => {
    if (!form) return;
    const p = movementTypeSchema.safeParse(form);
    if (!p.success) { setError(p.error.issues[0]?.message ?? 'Verifique os campos'); return; }
    setBusy(true); setError('');
    try { await save({ data: p.data }); await refresh(); setForm(null); toast.success('Salvo'); } catch (e) { setError(err(e)); } finally { setBusy(false); }
  };
  return <>
    <div className="page-heading"><div><h1>Cadastros de movimentações</h1><p>Tipos de atestado, tipos de afastamento e motivos de demissão.</p></div>
      <div className="heading-actions"><Button onClick={() => { if (!requireAccess()) return; setError(''); setForm({ kind: tab, name: '', description: '', initiative: '', requires_document: false, active: true }); }}><Plus />Novo</Button></div></div>
    <div className="flex gap-2 mb-2">{movementKinds.map(k => <Button key={k} size="sm" variant={tab === k ? 'default' : 'outline'} onClick={() => setTab(k)}>{typeLabels[k]}</Button>)}</div>
    <section className="records-section">
      <div className="filter-bar individual-filters"><ClearFilters/><Filter label="Nome" value={nameF} onChange={setNameF} /><Filter label="Ativo" value={activeF} onChange={setActiveF} options={[{ value: 'true', label: 'Sim' }, { value: 'false', label: 'Não' }]} /></div>
      {!session ? <div className="empty-state"><ClipboardList size={32} /><h3>Entre no seu espaço para cadastrar</h3></div>
        : query.isLoading ? <div className="loading-page">Carregando...</div>
        : <div className="table-scroll"><table className="records-table"><thead><tr><th>NOME</th>{tab === 'afastamento' && <th>EXIGE DOCUMENTO</th>}{tab === 'demissao' && <th>INICIATIVA</th>}<th>DESCRIÇÃO</th><th>ATIVO</th></tr></thead>
          <tbody>{rows.map(t => <tr key={t.id} className="document-row" onClick={() => { setError(''); setForm({ ...t, kind: t.kind as MovementKind, initiative: t.initiative as TypeForm['initiative'] }); }}>
            <td><strong>{t.name}</strong></td>{tab === 'afastamento' && <td>{t.requires_document ? 'Sim' : 'Não'}</td>}{tab === 'demissao' && <td>{initiativeLabels[t.initiative as keyof typeof initiativeLabels] ?? '—'}</td>}
            <td className="truncate max-w-xs">{t.description || '—'}</td><td><span className={`status-badge ${t.active ? 'active' : 'inactive'}`}>{t.active ? 'Ativo' : 'Inativo'}</span></td></tr>)}</tbody></table>
          {!rows.length && <div className="empty-state"><ClipboardList size={32} /><h3>Nenhum cadastro</h3></div>}</div>}
    </section>
    <Dialog open={!!form} onOpenChange={o => !o && setForm(null)}>
      <DialogContent><DialogHeader><DialogTitle>{form ? typeLabels[form.kind] : ''}</DialogTitle></DialogHeader>
        {form && <div className="form-grid">
          <label className="wide-field">Nome *<Input aria-label="Nome" maxLength={200} value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></label>
          {form.kind === 'demissao' && <label>Iniciativa<select aria-label="Iniciativa" value={form.initiative} onChange={e => setForm({ ...form, initiative: e.target.value as TypeForm['initiative'] })}><option value="">Selecione</option>{Object.entries(initiativeLabels).map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label>}
          {form.kind === 'afastamento' && <label className="flex items-center gap-2"><input type="checkbox" checked={form.requires_document} onChange={e => setForm({ ...form, requires_document: e.target.checked })} />Exige documento</label>}
          <label className="flex items-center gap-2"><input type="checkbox" checked={form.active} onChange={e => setForm({ ...form, active: e.target.checked })} />Ativo</label>
          <label className="wide-field">Descrição / orientações<Textarea maxLength={4000} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></label>
          {error && <p className="field-error" role="alert">{error}</p>}
        </div>}
        <DialogFooter>
          {form?.id && <Button variant="ghost" className="text-destructive mr-auto" disabled={busy} onClick={async () => { if (!form.id || !(await confirmDelete('Excluir?'))) return; setBusy(true); try { await remove({ data: { id: form.id } }); await refresh(); setForm(null); toast.success('Excluído'); } catch (e) { toast.error(err(e)); } finally { setBusy(false); } }}><Trash2 />Excluir</Button>}
          <Button variant="outline" onClick={() => setForm(null)}>Fechar</Button><Button disabled={busy} onClick={submit}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  </>;
}

type MForm = { id?: string; kind: MovementKind; employee_id: string; type_id: string; start_date: string; end_date: string; return_date: string; has_notice: boolean; notice_type: '' | 'trabalhado' | 'indenizado'; notice_start: string; notice_end: string; notes: string; attachments: Attachment[] };

const titles: Record<MovementKind, { title: string; text: string; start: string; end: string }> = {
  atestado: { title: 'Atestados', text: 'Registre os atestados dos colaboradores.', start: 'Data de início', end: 'Data final' },
  afastamento: { title: 'Afastamentos', text: 'Registre os afastamentos dos colaboradores.', start: 'Data de início', end: 'Data final prevista' },
  demissao: { title: 'Demissões', text: 'Registre os desligamentos e o aviso prévio.', start: 'Data do desligamento', end: '' },
};

export function Movements({ kind }: { kind: MovementKind }) {
  const { data, session, requireAccess } = useFinance();
  const types = useTypes();
  const get = useServerFn(getMovements), save = useServerFn(saveMovement), remove = useServerFn(deleteMovement);
  const query = useQuery({ queryKey: ['movements', kind, session?.user.id], queryFn: () => get({ data: { kind } }), enabled: !!session });
  const qc = useQueryClient();
  const [f, setF] = useState({ name: '', company: '', type: '', status: '' });
  const [form, setForm] = useState<MForm | null>(null);
  const [search, setSearch] = useState('');
  const [busy, setBusy] = useState(false), [uploading, setUploading] = useState(false), [error, setError] = useState('');
  const t = titles[kind];
  const employees = query.data?.employees ?? [];
  const kindTypes = (types.data ?? []).filter(x => x.kind === kind);
  const emp = (id: string) => employees.find(e => e.id === id);
  const job = (id?: string) => data.jobs.find(j => j.id === id);
  const dept = (id?: string) => data.departments.find(d => d.id === id)?.name ?? '—';
  const now = today();
  const rows = (query.data?.movements ?? []).map(m => ({ ...m, status: movementStatus({ ...m, kind }, now), emp: emp(m.employee_id), type: kindTypes.find(x => x.id === m.type_id) }))
    .filter(m => (m.emp?.name ?? '').toLocaleLowerCase().includes(f.name.toLocaleLowerCase()) && (!f.company || m.company_id === f.company) && (!f.type || m.type_id === f.type) && (!f.status || m.status === f.status));
  const statuses = kind === 'demissao' ? ['Agendada', 'Em aviso prévio', 'Desligado'] : ['Agendado', 'Em andamento', 'Encerrado'];
  const refresh = () => qc.invalidateQueries({ queryKey: ['movements'] });
  const selType = kindTypes.find(x => x.id === form?.type_id);
  const typeOptions = kindTypes.filter(x => x.active || x.id === form?.type_id);

  const open = (m?: (typeof rows)[number]) => {
    if (!requireAccess()) return; setError(''); setSearch('');
    setForm(m ? { id: m.id, kind, employee_id: m.employee_id, type_id: m.type_id, start_date: m.start_date, end_date: m.end_date ?? '', return_date: m.return_date ?? '', has_notice: m.has_notice, notice_type: m.notice_type as MForm['notice_type'], notice_start: m.notice_start ?? '', notice_end: m.notice_end ?? '', notes: m.notes, attachments: (m.attachments as Attachment[]) ?? [] }
      : { kind, employee_id: '', type_id: '', start_date: '', end_date: '', return_date: '', has_notice: false, notice_type: '', notice_start: '', notice_end: '', notes: '', attachments: [] });
  };
  const submit = async () => {
    if (!form) return;
    const p = movementSchema.safeParse(form);
    if (!p.success) { setError(p.error.issues[0]?.message ?? 'Verifique os campos'); return; }
    if (selType?.requires_document && !form.attachments.length) { setError('Este tipo exige anexar um documento'); return; }
    setBusy(true); setError('');
    try { await save({ data: p.data }); await refresh(); setForm(null); toast.success('Registro salvo'); } catch (e) { setError(err(e)); } finally { setBusy(false); }
  };

  return <>
    <div className="page-heading"><div><h1>{t.title}</h1><p>{t.text}</p></div><div className="heading-actions"><Button onClick={() => open()}><Plus />Novo registro</Button></div></div>
    <section className="records-section">
      <div className="filter-bar individual-filters"><ClearFilters/>
        <Filter label="Colaborador" value={f.name} onChange={v => setF({ ...f, name: v })} />
        <Filter label="Empresa" value={f.company} onChange={v => setF({ ...f, company: v })} options={data.companies.map(c => ({ value: c.id, label: c.name }))} />
        <Filter label={kind === 'demissao' ? 'Motivo' : 'Tipo'} value={f.type} onChange={v => setF({ ...f, type: v })} options={kindTypes.map(x => ({ value: x.id, label: x.name }))} />
        <Filter label="Situação" value={f.status} onChange={v => setF({ ...f, status: v })} options={statuses.map(s => ({ value: s, label: s }))} />
      </div>
      {!session ? <div className="empty-state"><ClipboardList size={32} /><h3>Entre no seu espaço para registrar</h3></div>
        : query.isLoading ? <div className="loading-page">Carregando...</div>
        : <div className="table-scroll"><table className="records-table"><thead><tr><th>COLABORADOR</th><th>DEPARTAMENTO</th><th>CARGO</th><th>{kind === 'demissao' ? 'MOTIVO' : 'TIPO'}</th>
          {kind === 'demissao' ? <><th>DESLIGAMENTO</th><th>AVISO PRÉVIO</th></> : <><th>INÍCIO</th><th>FINAL</th><th>DIAS</th></>}<th>ANEXOS</th><th>SITUAÇÃO</th></tr></thead>
          <tbody>{rows.map(m => { const j = job(m.emp?.job_id); return <tr key={m.id} className="document-row" onClick={() => open(m)}>
            <td><strong>{m.emp?.name ?? '—'}</strong></td><td>{dept(j?.department_id)}</td><td>{j?.name ?? '—'}</td><td>{m.type?.name ?? '—'}</td>
            {kind === 'demissao' ? <><td>{br(m.start_date)}</td><td>{m.has_notice ? `${m.notice_type === 'trabalhado' ? 'Trabalhado' : 'Indenizado'} · ${br(m.notice_start)} a ${br(m.notice_end)}` : 'Não'}</td></>
              : <><td>{br(m.start_date)}</td><td>{br(m.end_date)}</td><td>{daysBetween(m.start_date, m.end_date)}</td></>}
            <td>{(m.attachments as Attachment[]).length}</td><td><span className={`status-badge ${m.status === 'Em andamento' || m.status === 'Em aviso prévio' ? 'pending' : m.status === 'Desligado' ? 'inactive' : 'active'}`}>{m.status}</span></td></tr>; })}</tbody></table>
          {!rows.length && <div className="empty-state"><ClipboardList size={32} /><h3>Nenhum registro</h3></div>}</div>}
    </section>
    <Dialog open={!!form} onOpenChange={o => !o && setForm(null)}>
      <DialogContent className="large-dialog"><DialogHeader><DialogTitle>{form?.id ? `Editar ${kindLabels[kind].toLowerCase()}` : `Novo registro — ${kindLabels[kind]}`}</DialogTitle></DialogHeader>
        {form && <div className="form-grid">
          <label>Colaborador *<SearchSelect label="Colaborador" value={form.employee_id} onChange={v => setForm({ ...form, employee_id: v })} options={employees.map(e => ({ value: e.id, label: e.name }))} /></label>
          <label>{kind === 'demissao' ? 'Motivo da demissão *' : `Tipo de ${kind} *`}<select aria-label="Tipo" value={form.type_id} onChange={e => setForm({ ...form, type_id: e.target.value })}><option value="">Selecione</option>{typeOptions.map(x => <option key={x.id} value={x.id}>{x.name}</option>)}</select>
            {!kindTypes.length && <small className="field-hint">Cadastre primeiro em Cadastros de movimentações.</small>}</label>
          <label>{t.start} *<Input type="date" aria-label={t.start} value={form.start_date} onChange={e => setForm({ ...form, start_date: e.target.value })} /></label>
          {kind !== 'demissao' && <label>{t.end} *<Input type="date" aria-label={t.end} value={form.end_date} onChange={e => setForm({ ...form, end_date: e.target.value })} /></label>}
          {kind !== 'demissao' && <label>Quantidade de dias<Input readOnly value={daysBetween(form.start_date, form.end_date || null) || ''} /></label>}
          {kind === 'afastamento' && <label>Data real de retorno<Input type="date" aria-label="Data real de retorno" value={form.return_date} onChange={e => setForm({ ...form, return_date: e.target.value })} /></label>}
          {kind === 'demissao' && <>
            <label>Possui aviso prévio? *<select aria-label="Possui aviso prévio" value={form.has_notice ? 'sim' : 'nao'} onChange={e => setForm({ ...form, has_notice: e.target.value === 'sim' })}><option value="nao">Não</option><option value="sim">Sim</option></select></label>
            {form.has_notice && <>
              <label>Tipo do aviso *<select aria-label="Tipo do aviso" value={form.notice_type} onChange={e => setForm({ ...form, notice_type: e.target.value as MForm['notice_type'] })}><option value="">Selecione</option><option value="trabalhado">Trabalhado</option><option value="indenizado">Indenizado</option></select></label>
              <label>Início do aviso *<Input type="date" aria-label="Início do aviso" value={form.notice_start} onChange={e => setForm({ ...form, notice_start: e.target.value })} /></label>
              <label>Fim do aviso *<Input type="date" aria-label="Fim do aviso" value={form.notice_end} onChange={e => setForm({ ...form, notice_end: e.target.value })} /></label>
            </>}
          </>}
          <label className="wide-field">Observações<Textarea maxLength={4000} value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} /></label>
          <div className="wide-field"><strong>Anexos{selType?.requires_document ? ' *' : ''}</strong><DocumentAttachments owner={session?.user.id ?? ''} value={form.attachments} onBusy={setUploading} onChange={v => setForm(cur => cur && { ...cur, attachments: v })} /></div>
          {error && <p className="field-error" role="alert">{error}</p>}
        </div>}
        <DialogFooter>
          {form?.id && <Button variant="ghost" className="text-destructive mr-auto" disabled={busy} onClick={async () => { if (!form.id || !(await confirmDelete('Excluir este registro?'))) return; setBusy(true); try { await remove({ data: { id: form.id } }); await refresh(); setForm(null); toast.success('Excluído'); } catch (e) { toast.error(err(e)); } finally { setBusy(false); } }}><Trash2 />Excluir</Button>}
          <Button variant="outline" onClick={() => setForm(null)}>Fechar</Button><Button disabled={busy || uploading} onClick={submit}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  </>;
}
