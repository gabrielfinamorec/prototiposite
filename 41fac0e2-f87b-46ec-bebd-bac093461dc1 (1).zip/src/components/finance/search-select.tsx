import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Input } from '@/components/ui/input';

/** Lista suspensa com campo "Pesquisar" dentro da própria lista. */
export function SearchSelect({ value, onChange, options, label, placeholder = 'Selecione', disabled }: { value: string; onChange: (v: string) => void; options: { value: string; label: string }[]; label: string; placeholder?: string; disabled?: boolean }) {
  const [open, setOpen] = useState(false), [q, setQ] = useState('');
  const shown = options.filter(o => o.label.toLocaleLowerCase().includes(q.toLocaleLowerCase()));
  const current = options.find(o => o.value === value);
  return <Popover open={open} onOpenChange={o => { setOpen(o); if (!o) setQ(''); }}>
    <PopoverTrigger asChild><button type="button" role="combobox" aria-expanded={open} aria-label={label} disabled={disabled}
      className="flex h-9 w-full items-center justify-between gap-2 rounded-md border border-input bg-background px-3 text-sm text-left disabled:opacity-50">
      <span className={`truncate ${current ? '' : 'text-muted-foreground'}`}>{current?.label ?? placeholder}</span><ChevronDown size={16} className="shrink-0 opacity-60" /></button></PopoverTrigger>
    <PopoverContent align="start" onClick={e => e.stopPropagation()} className="bg-card p-2 w-[var(--radix-popover-trigger-width)] min-w-64">
      <Input autoFocus placeholder="Pesquisar" aria-label={`Pesquisar ${label}`} value={q} onChange={e => setQ(e.target.value)} />
      <div role="listbox" className="mt-2 max-h-64 overflow-y-auto">
        {shown.map(o => <button type="button" role="option" aria-selected={o.value === value} key={o.value} onClick={() => { onChange(o.value); setOpen(false); setQ(''); }}
          className={`block w-full rounded px-2 py-1.5 text-left text-sm hover:bg-accent ${o.value === value ? 'bg-accent font-semibold' : ''}`}>{o.label}</button>)}
        {!shown.length && <p className="px-2 py-1.5 text-sm text-muted-foreground">Nenhum resultado</p>}
      </div>
    </PopoverContent>
  </Popover>;
}
