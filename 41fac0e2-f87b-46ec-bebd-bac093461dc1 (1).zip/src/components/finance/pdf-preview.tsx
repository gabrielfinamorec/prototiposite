import { useEffect, useRef, useState } from 'react';
export function PdfPreview({url}:{url:string}) {
  const canvas=useRef<HTMLCanvasElement>(null);const [error,setError]=useState(false);
    useEffect(()=>{let cancelled=false;let destroy:(()=>void)|undefined;setError(false);
    async function render(){try{const response=await fetch(url);const bytes=await response.arrayBuffer();if(cancelled)return;const pdfjs=await import('pdfjs-dist');const worker=await import('pdfjs-dist/build/pdf.worker.min.mjs?url');pdfjs.GlobalWorkerOptions.workerSrc=worker.default;const task=pdfjs.getDocument({data:bytes,useSystemFonts:true});destroy=()=>{void task.destroy();};const pdf=await task.promise;const page=await pdf.getPage(1);if(cancelled)return;const target=canvas.current;if(!target)return;const context=target.getContext('2d');if(!context)return;const viewport=page.getViewport({scale:1.5});target.width=viewport.width;target.height=viewport.height;await page.render({canvasContext:context,viewport}).promise;}catch(e){if(!cancelled){console.error('PDF preview failed',e);setError(true);}}}
    void render();return()=>{cancelled=true;destroy?.();};
  },[url]);
  return <div className="pdf-preview-paper">{error?<p>Não foi possível carregar a prévia.</p>:<canvas ref={canvas} aria-label="Primeira página do PDF"/>}</div>;
}