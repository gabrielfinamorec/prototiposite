import { useEffect, useRef, useState } from 'react';
import { Eraser } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';

type Ask = { message: string; resolve: (v: boolean) => void };
let open: ((a: Ask) => void) | null = null;

/** Pergunta "Tem certeza?" antes de apagar. Resolve true quando o usuário escolhe "Sim, apagar". */
export function confirmDelete(message = 'Esta ação não pode ser desfeita.') {
  return new Promise<boolean>(resolve => (open ? open({ message, resolve }) : resolve(false)));
}

export function ConfirmDeleteHost() {
  const [ask, setAsk] = useState<Ask | null>(null);
  useEffect(() => { open = setAsk; return () => { open = null; }; }, []);
  const done = (v: boolean) => { ask?.resolve(v); setAsk(null); };
  return <Dialog open={!!ask} onOpenChange={o => !o && done(false)}>
    <DialogContent className="max-w-sm"><DialogHeader><DialogTitle>Tem certeza?</DialogTitle><DialogDescription>{ask?.message}</DialogDescription></DialogHeader>
      <DeleteButtons onNo={() => done(false)} onYes={() => done(true)} />
    </DialogContent>
  </Dialog>;
}

export function DeleteButtons({ onNo, onYes, busy }: { onNo: () => void; onYes: () => void; busy?: boolean }) {
  return <div className="dialog-actions"><Button variant="outline" onClick={onNo}>Não, voltar</Button><Button variant="destructive" disabled={busy} onClick={onYes}>Sim, apagar</Button></div>;
}

/** Botão que limpa todos os campos da barra de filtros onde ele está. */
export function ClearFilters() {
  const ref = useRef<HTMLButtonElement>(null);
  const clear = () => {
    const bar = ref.current?.closest('.filter-bar');
    bar?.querySelectorAll<HTMLInputElement | HTMLSelectElement>('input, select').forEach(el => {
      if (el instanceof HTMLInputElement && (el.type === 'checkbox' || el.type === 'radio')) return;
      const target = el instanceof HTMLSelectElement ? (Array.from(el.options).some(o => o.value === 'all') ? 'all' : Array.from(el.options).some(o => o.value === '') ? '' : el.value) : '';
      if (el.value === target) return;
      const proto = el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, 'value')?.set?.call(el, target);
      el.dispatchEvent(new Event(el instanceof HTMLSelectElement ? 'change' : 'input', { bubbles: true }));
    });
  };
  return <Button ref={ref} type="button" variant="outline" size="sm" className="clear-filters" onClick={clear}><Eraser size={14} />Limpar filtros</Button>;
}
