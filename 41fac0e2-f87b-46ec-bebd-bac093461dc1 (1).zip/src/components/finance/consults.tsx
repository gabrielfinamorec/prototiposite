import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { BarChart3, Download, FileDown } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useFinance } from './workspace';
import { getConsultData } from '@/lib/reports.functions';
import { addDays, br, buildReport, employeeStatuses, nextBirthday, reportCsv, reportKinds, reportPdf, type ConsultData, type ReportKind } from '@/lib/report-rules';
import { documentStatus, todayLocal } from '@/lib/document-rules';
import { vacationStatus } from '@/lib/vacation-rules';
import { deliverFile } from '@/lib/download';
import { ClearFilters } from './confirm-delete';

function useConsult() {
  const { session } = useFinance();
  const get = useServerFn(getConsultData);
  return useQuery({ queryKey: ['consult', session?.user.id], queryFn: () => get(), enabled: !!session });
}

function byCompany(d: ConsultData, company: string): ConsultData {
  if (!company) return d;
  const f = <T extends { company_id: string }>(a: T[]) => a.filter(x => x.company_id === company);
  return { ...d, employees: f(d.employees), dependents: f(d.dependents), vacations: f(d.vacations), movements: f(d.movements), documents: f(d.documents), benefits: f(d.benefits) };
}

export function Dashboard() {
  const { data: org, session } = useFinance();
  const q = useConsult();
  const [company, setCompany] = useState('');
  const today = todayLocal();
  const view = useMemo(() => {
    if (!q.data) return null;
    const d = byCompany(q.data, company);
    const st = employeeStatuses(d, today);
    const count = (s: string) => Object.values(st).filter(x => x === s).length;
    const name = (id: string) => d.employees.find(e => e.id === id)?.name ?? '—';
    const job = (id: string) => org.jobs.find(j => j.id === d.employees.find(e => e.id === id)?.job_id);
    const deptCount: Record<string, number> = {};
    d.employees.filter(e => st[e.id] !== 'Desligado').forEach(e => { const n = org.departments.find(x => x.id === job(e.id)?.department_id)?.name ?? 'Sem departamento'; deptCount[n] = (deptCount[n] ?? 0) + 1; });
    const months = Array.from({ length: 12 }, (_, i) => { const dt = new Date(`${today.slice(0, 7)}-01T00:00:00Z`); dt.setUTCMonth(dt.getUTCMonth() - 11 + i); return dt.toISOString().slice(0, 7); });
    const flow = months.map(m => ({ mes: `${m.slice(5)}/${m.slice(2, 4)}`, Admissões: d.employees.filter(e => e.admission_date.startsWith(m)).length, Demissões: d.movements.filter(x => x.kind === 'demissao' && x.start_date.startsWith(m)).length }));
    const limit = addDays(today, 30);
    const alerts: { level: 'danger' | 'warning'; text: string }[] = [];
    d.documents.forEach(x => { const s = documentStatus(x, today); if (s === 'vencido') alerts.push({ level: 'danger', text: `Documento vencido: ${d.documentTypes.find(t => t.id === x.type_id)?.name ?? ''} — ${name(x.employee_id)}` }); });
    const pend = d.documents.filter(x => documentStatus(x, today) === 'pendente').length;
    if (pend) alerts.push({ level: 'warning', text: `${pend} documento(s) pendente(s) de validação` });
    d.documents.forEach(x => { if (documentStatus(x, today) === 'em dia' && x.expiry_date && x.expiry_date <= limit) alerts.push({ level: 'warning', text: `Documento vence em ${br(x.expiry_date)}: ${d.documentTypes.find(t => t.id === x.type_id)?.name ?? ''} — ${name(x.employee_id)}` }); });
    d.vacations.forEach(v => { const s = vacationStatus(v, today); if (s === 'Aviso') alerts.push({ level: 'warning', text: `Férias terminadas aguardando finalizar — ${name(v.employee_id)}` }); if (s === 'Pendente') alerts.push({ level: 'warning', text: `Solicitação de férias pendente — ${name(v.employee_id)} (${br(v.start_date)})` }); });
    d.movements.forEach(m => { if (m.kind === 'demissao' && m.has_notice && m.notice_end && m.notice_end >= today && m.notice_end <= addDays(today, 15)) alerts.push({ level: 'danger', text: `Aviso prévio termina em ${br(m.notice_end)} — ${name(m.employee_id)}` }); });
    const events: { date: string; text: string }[] = [];
    d.vacations.forEach(v => { if (v.state === 'aprovada' && v.start_date > today && v.start_date <= limit) events.push({ date: v.start_date, text: `Início de férias — ${name(v.employee_id)}` }); if (v.state === 'aprovada' && v.end_date >= today && v.end_date <= limit) events.push({ date: addDays(v.end_date, 1), text: `Volta de férias — ${name(v.employee_id)}` }); });
    d.movements.forEach(m => { const end = m.return_date ?? m.end_date; if (m.kind !== 'demissao' && end && end >= today && end <= limit) events.push({ date: m.return_date ?? addDays(end, 1), text: `Retorno de ${m.kind} — ${name(m.employee_id)}` }); if (m.kind === 'demissao' && m.start_date >= today && m.start_date <= limit) events.push({ date: m.start_date, text: `Desligamento — ${name(m.employee_id)}` }); });
    [...d.employees.map(e => ({ n: e.name, b: e.birth_date })), ...d.dependents.map(x => ({ n: `${x.name} (dependente)`, b: x.birth_date }))].forEach(p => { const nb = nextBirthday(p.b, today); if (nb && nb.days <= 30) events.push({ date: nb.date, text: `Aniversário — ${p.n} (${nb.age} anos)` }); });
    events.sort((a, b) => a.date.localeCompare(b.date));
    return { numbers: [['Ativos', count('Ativo')], ['Em férias', count('Em férias')], ['Atestado', count('Atestado')], ['Afastados', count('Afastado')], ['Em aviso prévio', count('Em aviso prévio')], ['Desligados', count('Desligado')], ['Dependentes', d.dependents.filter(x => x.active).length]] as const, dept: Object.entries(deptCount).map(([nome, total]) => ({ nome, Colaboradores: total })), flow, alerts, events };
  }, [q.data, company, org, today]);

  return <>
    <div className="page-heading"><div><h1>Dashboard</h1><p>Visão geral das pessoas, alertas e próximos eventos.</p></div>
      <label className="table-filter min-w-56">Empresa<select aria-label="Empresa" value={company} onChange={e => setCompany(e.target.value)}><option value="">Todas</option>{org.companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label></div>
    {!session ? <div className="empty-state"><BarChart3 size={32} /><h3>Entre no seu espaço para ver o dashboard</h3></div>
      : !view ? <div className="loading-page">{q.error ? 'Não foi possível carregar.' : 'Carregando...'}</div>
      : <div className="flex flex-col gap-3">
        <div className="grid grid-cols-2 gap-2 md:grid-cols-6">{view.numbers.map(([l, n]) => <div key={l} className="rounded-md border bg-card px-3 py-2"><small className="text-muted-foreground">{l}</small><div className="text-2xl font-semibold text-primary">{n}</div></div>)}</div>
        <div className="grid gap-3 lg:grid-cols-2">
          <section className="records-section p-3"><h2 className="mb-2 text-sm font-semibold">Colaboradores por departamento</h2><div className="h-60"><ResponsiveContainer><BarChart data={view.dept}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="nome" fontSize={11} /><YAxis allowDecimals={false} fontSize={11} /><Tooltip /><Bar dataKey="Colaboradores" fill="var(--primary)" /></BarChart></ResponsiveContainer></div></section>
          <section className="records-section p-3"><h2 className="mb-2 text-sm font-semibold">Admissões e demissões (12 meses)</h2><div className="h-60"><ResponsiveContainer><BarChart data={view.flow}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="mes" fontSize={11} /><YAxis allowDecimals={false} fontSize={11} /><Tooltip /><Legend /><Bar dataKey="Admissões" fill="var(--primary)" /><Bar dataKey="Demissões" fill="var(--muted-foreground)" /></BarChart></ResponsiveContainer></div></section>
          <section className="records-section p-3"><h2 className="mb-2 text-sm font-semibold">Alertas</h2><ul className="flex max-h-72 flex-col gap-1 overflow-y-auto text-sm">{view.alerts.map((a, i) => <li key={i} className={`rounded px-2 py-1 ${a.level === 'danger' ? 'bg-destructive/10 text-destructive' : 'bg-accent'}`}>{a.text}</li>)}{!view.alerts.length && <li className="text-muted-foreground">Nenhum alerta.</li>}</ul></section>
          <section className="records-section p-3"><h2 className="mb-2 text-sm font-semibold">Próximos 30 dias</h2><ul className="flex max-h-72 flex-col gap-1 overflow-y-auto text-sm">{view.events.map((e, i) => <li key={i} className="flex gap-3 border-b py-1"><strong className="w-20 shrink-0">{br(e.date)}</strong>{e.text}</li>)}{!view.events.length && <li className="text-muted-foreground">Nenhum evento.</li>}</ul></section>
        </div>
      </div>}
  </>;
}

export function Reports() {
  const { data: org, session } = useFinance();
  const q = useConsult();
  const [kind, setKind] = useState<ReportKind>('colaboradores');
  const [company, setCompany] = useState(''), [from, setFrom] = useState(''), [to, setTo] = useState(''), [text, setText] = useState('');
  const today = todayLocal();
  const report = useMemo(() => {
    if (!q.data) return null;
    const r = buildReport(kind, q.data, org, today);
    const t = text.toLocaleLowerCase();
    return { ...r, rows: r.rows.filter(x => (!company || x.company_id === company) && (!from || (x.date && x.date >= from)) && (!to || (x.date && x.date <= to)) && (!t || x.cells.some(c => c.toLocaleLowerCase().includes(t)))) };
  }, [q.data, kind, org, today, company, from, to, text]);
  const subtitle = `${org.companies.find(c => c.id === company)?.name ?? 'Todas as empresas'}${from || to ? ` · ${br(from) } a ${br(to)}` : ''} · gerado em ${br(today)}`;
  const file = `relatorio-${kind}-${today}`;
  return <>
    <div className="page-heading"><div><h1>Relatórios</h1><p>Escolha o relatório, filtre e baixe em PDF ou Excel (CSV).</p></div>
      <div className="heading-actions"><Button variant="outline" disabled={!report} onClick={() => report && void deliverFile(reportCsv(report), `${file}.csv`)}><Download />Excel (CSV)</Button><Button disabled={!report} onClick={() => report && void deliverFile(reportPdf(`Relatório de ${reportKinds[kind]}`, report, subtitle), `${file}.pdf`)}><FileDown />PDF</Button></div></div>
    <div className="mb-2 flex flex-wrap gap-2">{(Object.keys(reportKinds) as ReportKind[]).map(k => <Button key={k} size="sm" variant={k === kind ? 'default' : 'outline'} onClick={() => setKind(k)}>{reportKinds[k]}</Button>)}</div>
    <section className="records-section">
      <div className="filter-bar individual-filters"><ClearFilters/>
        <label className="table-filter">Empresa<select aria-label="Filtrar Empresa" value={company} onChange={e => setCompany(e.target.value)}><option value="">Todas</option>{org.companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
        {kind !== 'beneficios' && <><label className="table-filter">De<Input type="date" aria-label="Data inicial" value={from} onChange={e => setFrom(e.target.value)} /></label><label className="table-filter">Até<Input type="date" aria-label="Data final" value={to} onChange={e => setTo(e.target.value)} /></label></>}
        <label className="table-filter">Pesquisar<Input aria-label="Pesquisar no relatório" value={text} onChange={e => setText(e.target.value)} /></label>
      </div>
      {!session ? <div className="empty-state"><BarChart3 size={32} /><h3>Entre no seu espaço para ver os relatórios</h3></div>
        : !report ? <div className="loading-page">{q.error ? 'Não foi possível carregar.' : 'Carregando...'}</div>
        : <div className="table-scroll"><table className="records-table"><thead><tr>{report.columns.map(c => <th key={c}>{c.toUpperCase()}</th>)}</tr></thead>
          <tbody>{report.rows.map((r, i) => <tr key={i}>{r.cells.map((c, j) => <td key={j}>{j === 0 ? <strong>{c}</strong> : c}</td>)}</tr>)}</tbody></table>
          {!report.rows.length && <div className="empty-state"><BarChart3 size={32} /><h3>Nenhum registro</h3></div>}
          <div className="table-footer"><span>{report.rows.length} registro(s)</span></div></div>}
    </section>
  </>;
}
