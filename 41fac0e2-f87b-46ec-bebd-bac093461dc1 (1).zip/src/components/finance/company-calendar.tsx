import { useEffect, useMemo, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { useFinance } from './workspace';
import { getCalendar, saveCalendarDays } from '@/lib/calendar.functions';
import { dayKinds, iso, kindLabels, resolveDay, type DayKind } from '@/lib/calendar-rules';

const months = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
const weekdays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
const br = (d: string) => d.split('-').reverse().join('/');

export function CompanyCalendar() {
  const { data, session, requireAccess } = useFinance();
  const qc = useQueryClient();
  const load = useServerFn(getCalendar), save = useServerFn(saveCalendarDays);
  const now = new Date();
  const [company, setCompany] = useState('');
  const [year, setYear] = useState(now.getFullYear()), [month, setMonth] = useState(now.getMonth());
  const [edit, setEdit] = useState<{ start: string; end: string; kind: DayKind; title: string } | null>(null);
  const [error, setError] = useState(''), [busy, setBusy] = useState(false);
  useEffect(() => { if (!data.companies.some(c => c.id === company)) setCompany(data.companies[0]?.id ?? ''); }, [data.companies, company]);
  const query = useQuery({ queryKey: ['calendar', company, year], queryFn: () => load({ data: { company_id: company, year } }), enabled: !!session && !!company });
  const saved = useMemo(() => Object.fromEntries((query.data ?? []).map(r => [r.day, r])), [query.data]);

  const first = new Date(year, month, 1).getDay(), total = new Date(year, month + 1, 0).getDate();
  const cells: (string | null)[] = [...Array(first).fill(null), ...Array.from({ length: total }, (_, i) => iso(year, month + 1, i + 1))];
  const today = iso(now.getFullYear(), now.getMonth() + 1, now.getDate());
  const go = (delta: number) => { const d = new Date(year, month + delta, 1); setYear(d.getFullYear()); setMonth(d.getMonth()); };
  const open = (day: string) => { if (!requireAccess()) return; const r = resolveDay(day, saved[day]); setError(''); setEdit({ start: day, end: day, kind: r.kind, title: r.title }); };
  const submit = async (reset = false) => {
    if (!edit) return; setBusy(true); setError('');
    try { await save({ data: { company_id: company, ...edit, reset } }); await qc.invalidateQueries({ queryKey: ['calendar', company] }); setEdit(null); }
    catch (e) { setError(e instanceof Error ? e.message : 'Não foi possível salvar'); } finally { setBusy(false); }
  };

  return <section className="page-section">
    <div className="page-heading"><div><h1>Calendário da empresa</h1><p>Clique em um dia para classificar como trabalhado, feriado, recesso ou folga. Feriados nacionais já vêm preenchidos.</p></div></div>
    <div className="calendar-toolbar">
      <label className="calendar-company">Empresa
        <select value={company} onChange={e => setCompany(e.target.value)}>{data.companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
      </label>
      <div className="calendar-nav">
        <Button variant="outline" size="icon" onClick={() => go(-1)} aria-label="Mês anterior"><ChevronLeft /></Button>
        <strong>{months[month]} {year}</strong>
        <Button variant="outline" size="icon" onClick={() => go(1)} aria-label="Próximo mês"><ChevronRight /></Button>
        <Button variant="outline" onClick={() => { setYear(now.getFullYear()); setMonth(now.getMonth()); }}>Hoje</Button>
      </div>
    </div>
    <div className="calendar-legend">{dayKinds.map(k => <span key={k}><i className={`day-dot kind-${k}`} />{kindLabels[k]}</span>)}</div>
    {!company ? <div className="empty-state">Cadastre uma empresa para montar o calendário.</div> :
      <div className="calendar-grid">
        {weekdays.map(w => <div key={w} className="calendar-weekday">{w}</div>)}
        {cells.map((day, i) => {
          if (!day) return <div key={`e${i}`} className="calendar-cell empty" />;
          const r = resolveDay(day, saved[day]);
          return <button key={day} type="button" onClick={() => open(day)} className={`calendar-cell kind-${r.kind} ${day === today ? 'today' : ''}`} title={`${kindLabels[r.kind]}${r.title ? ` · ${r.title}` : ''}`}>
            <span className="calendar-num">{Number(day.slice(8))}</span>
            {r.title && <span className="calendar-title">{r.title}</span>}
            {r.kind !== 'trabalhado' && r.kind !== 'folga' && !r.title && <span className="calendar-title">{kindLabels[r.kind]}</span>}
          </button>;
        })}
      </div>}
    <Dialog open={!!edit} onOpenChange={o => !o && setEdit(null)}>
      <DialogContent><DialogHeader><DialogTitle>Classificar dia</DialogTitle></DialogHeader>
        {edit && <div className="form-grid">
          <label>Data inicial<Input type="date" value={edit.start} onChange={e => setEdit({ ...edit, start: e.target.value })} /></label>
          <label>Data final<Input type="date" value={edit.end} min={edit.start} onChange={e => setEdit({ ...edit, end: e.target.value })} /></label>
          <label>Tipo<select value={edit.kind} onChange={e => setEdit({ ...edit, kind: e.target.value as DayKind })}>{dayKinds.map(k => <option key={k} value={k}>{kindLabels[k]}</option>)}</select></label>
          <label>Nome / motivo<Input maxLength={150} value={edit.title} placeholder="Ex.: Feriado municipal" onChange={e => setEdit({ ...edit, title: e.target.value })} /></label>
          <p className="field-hint">Período: {br(edit.start)} a {br(edit.end || edit.start)}</p>
          {error && <p className="field-error">{error}</p>}
        </div>}
        <DialogFooter>
          <Button variant="outline" disabled={busy} onClick={() => submit(true)}>Voltar ao padrão</Button>
          <Button disabled={busy} onClick={() => submit()}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  </section>;
}
