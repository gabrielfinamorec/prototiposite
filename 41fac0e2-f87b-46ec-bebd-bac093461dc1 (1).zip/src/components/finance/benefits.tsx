import { useMemo, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { Gift, Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { useFinance } from './workspace';
import { deleteBenefit, getBenefits, saveBenefit, saveBenefitMembers } from '@/lib/benefits.functions';
import { benefitSchema, eligiblePeople, targetLabels, type BenefitTarget } from '@/lib/benefit-rules';
import { ClearFilters, confirmDelete } from './confirm-delete';

type Form = { id?: string; company_id: string; name: string; target: BenefitTarget | ''; notes: string };

function useBenefits() {
  const { session } = useFinance();
  const get = useServerFn(getBenefits);
  return useQuery({ queryKey: ['benefits', session?.user.id], queryFn: () => get(), enabled: !!session });
}

function useFilters<K extends string>() {
  const [filters, setFilters] = useState<Partial<Record<K, string>>>({});
  const field = (key: K, label: string, options?: { value: string; label: string }[]) => <label className="table-filter">{label}{options
    ? <select aria-label={`Filtrar ${label}`} value={filters[key] ?? 'all'} onChange={e => setFilters(f => ({ ...f, [key]: e.target.value }))}><option value="all">Todos</option>{options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}</select>
    : <Input aria-label={`Filtrar ${label}`} value={filters[key] ?? ''} onChange={e => setFilters(f => ({ ...f, [key]: e.target.value }))} />}</label>;
  const match = (key: K, value: string, exact = true) => { const f = filters[key]; if (!f || f === 'all') return true; return exact ? f === value : value.toLocaleLowerCase().includes(f.toLocaleLowerCase()); };
  return { field, match };
}
const targetOptions = (Object.keys(targetLabels) as BenefitTarget[]).map(t => ({ value: t, label: targetLabels[t] }));

export function Benefits() {
  const { data, session, requireAccess } = useFinance();
  const query = useBenefits();
  const qc = useQueryClient();
  const save = useServerFn(saveBenefit), saveMembers = useServerFn(saveBenefitMembers), remove = useServerFn(deleteBenefit);
  const { field, match } = useFilters<'name' | 'company_id' | 'target'>();
  const [form, setForm] = useState<Form | null>(null);
  const [members, setMembers] = useState<string[]>([]);
  const [search, setSearch] = useState(''), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const benefits = query.data?.benefits ?? [], employees = query.data?.employees ?? [], dependents = query.data?.dependents ?? [];
  const company = (id: string) => data.companies.find(c => c.id === id)?.name ?? '—';
  const visible = benefits.filter(b => match('name', b.name, false) && match('company_id', b.company_id) && match('target', b.target));
  const current = benefits.find(b => b.id === form?.id);
  const people = current ? eligiblePeople(current as { company_id: string; target: BenefitTarget }, employees, dependents) : [];
  const titular = (id: string) => employees.find(e => e.id === id)?.name ?? '';
  const shown = people.filter(p => p.name.toLocaleLowerCase().includes(search.toLocaleLowerCase()));
  const refresh = () => qc.invalidateQueries({ queryKey: ['benefits'] });

  const open = (b?: typeof benefits[number]) => {
    if (!requireAccess()) return;
    setError(''); setSearch('');
    setForm(b ? { id: b.id, company_id: b.company_id, name: b.name, target: b.target as BenefitTarget, notes: b.notes } : { company_id: '', name: '', target: '', notes: '' });
    setMembers(b?.member_ids ?? []);
  };
  const submit = async () => {
    if (!form) return; setError('');
    const parsed = benefitSchema.safeParse(form);
    if (!parsed.success) { setError(parsed.error.issues[0]?.message ?? 'Verifique os campos'); return; }
    setBusy(true);
    try {
      const keepMembers = current && current.company_id === form.company_id && current.target === form.target;
      const res = await save({ data: parsed.data });
      if (keepMembers) await saveMembers({ data: { id: res.id, member_ids: members } });
      await refresh();
      if (!form.id) { setForm({ ...form, id: res.id }); setMembers([]); toast.success('Benefício cadastrado. Agora marque os beneficiários.'); }
      else { setForm(null); toast.success('Benefício salvo'); }
    } catch (e) { setError(e instanceof Error ? e.message : 'Não foi possível salvar'); } finally { setBusy(false); }
  };
  const allShown = shown.length > 0 && shown.every(p => members.includes(p.id));
  const changedType = current && form && (current.company_id !== form.company_id || current.target !== form.target);

  return <>
    <div className="page-heading"><div><h1>Benefícios</h1><p>Cadastre os benefícios e clique em um deles para marcar os beneficiários.</p></div>
      <div className="heading-actions"><Button onClick={() => open()}><Plus />Novo benefício</Button></div></div>
    <section className="records-section">
      <div className="filter-bar individual-filters"><ClearFilters/>
        {field('name', 'Benefício')}
        {field('company_id', 'Empresa', data.companies.map(c => ({ value: c.id, label: c.name })))}
        {field('target', 'Para', targetOptions)}
      </div>
      {!session ? <div className="empty-state"><Gift size={32} /><h3>Entre no seu espaço para cadastrar benefícios</h3></div>
        : query.isLoading ? <div className="loading-page">Carregando...</div>
        : query.error ? <div className="empty-state"><p>Não foi possível carregar os benefícios.</p><Button onClick={() => query.refetch()}>Tentar novamente</Button></div>
        : <div className="table-scroll"><table className="records-table"><thead><tr><th>BENEFÍCIO</th><th>EMPRESA</th><th>PARA</th><th>BENEFICIÁRIOS</th><th>OBSERVAÇÕES</th></tr></thead>
          <tbody>{visible.map(b => <tr key={b.id} className="document-row" onClick={() => open(b)}>
            <td><strong>{b.name}</strong></td><td>{company(b.company_id)}</td><td>{targetLabels[b.target as BenefitTarget]}</td><td>{b.member_ids.length}</td><td className="truncate max-w-xs">{b.notes || '—'}</td>
          </tr>)}</tbody></table>
          {!visible.length && <div className="empty-state"><Gift size={32} /><h3>{benefits.length ? 'Nenhum resultado encontrado' : 'Nenhum benefício cadastrado'}</h3></div>}
        </div>}
    </section>

    <Dialog open={!!form} onOpenChange={o => !o && setForm(null)}>
      <DialogContent className="large-dialog"><DialogHeader><DialogTitle>{form?.id ? 'Informações do benefício' : 'Novo benefício'}</DialogTitle></DialogHeader>
        {form && <div className="form-grid">
          <label>Empresa *<select aria-label="Empresa" value={form.company_id} onChange={e => setForm({ ...form, company_id: e.target.value })}><option value="">Selecione</option>{data.companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
          <label>Nome do benefício *<Input aria-label="Nome do benefício" maxLength={200} value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></label>
          <label>Para *<select aria-label="Para" value={form.target} onChange={e => setForm({ ...form, target: e.target.value as BenefitTarget })}><option value="">Selecione</option>{targetOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}</select></label>
          <label>Observações<Textarea maxLength={4000} value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} /></label>
          {form.id && (changedType
            ? <p className="field-hint wide-field">Ao salvar com outra empresa ou tipo, a lista de beneficiários será limpa.</p>
            : <div className="wide-field flex flex-col gap-2">
              <strong>Beneficiários ({members.length} marcado(s))</strong>
              <Input placeholder={form.target === 'dependente' ? 'Buscar dependente' : 'Buscar colaborador'} aria-label="Buscar beneficiário" value={search} onChange={e => setSearch(e.target.value)} />
              {people.length ? <div className="assign-list max-h-72 overflow-y-auto border rounded-md p-2">
                <label className="flex items-center gap-2 font-semibold"><input type="checkbox" checked={allShown} onChange={e => setMembers(m => e.target.checked ? [...new Set([...m, ...shown.map(p => p.id)])] : m.filter(id => !shown.some(p => p.id === id)))} />Marcar todos</label>
                {shown.map(p => <label key={p.id} className="flex items-center gap-2"><input type="checkbox" aria-label={p.name} checked={members.includes(p.id)} onChange={e => setMembers(m => e.target.checked ? [...m, p.id] : m.filter(x => x !== p.id))} />
                  <span>{p.name}{'employee_id' in p ? <small className="text-muted-foreground"> · titular {titular(p.employee_id)}</small> : null}</span></label>)}
              </div> : <p className="field-hint">Nenhum {form.target === 'dependente' ? 'dependente' : 'colaborador'} cadastrado nesta empresa.</p>}
            </div>)}
          {error && <p className="field-error" role="alert">{error}</p>}
        </div>}
        <DialogFooter>
          {form?.id && <Button variant="ghost" className="text-destructive mr-auto" disabled={busy} onClick={async () => { if (!form.id || !(await confirmDelete('Excluir este benefício?'))) return; setBusy(true); try { await remove({ data: { id: form.id } }); await refresh(); setForm(null); toast.success('Benefício excluído'); } catch (e) { toast.error(e instanceof Error ? e.message : 'Erro'); } finally { setBusy(false); } }}><Trash2 />Excluir</Button>}
          <Button variant="outline" onClick={() => setForm(null)}>Fechar</Button><Button disabled={busy} onClick={submit}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  </>;
}

export function BenefitBeneficiaries() {
  const { data, session } = useFinance();
  const query = useBenefits();
  const { field, match } = useFilters<'benefit' | 'company_id' | 'target' | 'name' | 'holder'>();
  const rows = useMemo(() => {
    const q = query.data; if (!q) return [];
    return q.benefits.flatMap(b => b.member_ids.map(id => {
      const emp = q.employees.find(e => e.id === id), dep = q.dependents.find(d => d.id === id);
      const holder = dep ? q.employees.find(e => e.id === dep.employee_id) : emp;
      const job = data.jobs.find(j => j.id === holder?.job_id);
      return { key: `${b.id}-${id}`, benefit: b.name, benefit_id: b.id, company_id: b.company_id, target: b.target as BenefitTarget, name: emp?.name ?? dep?.name ?? '', holder: dep ? holder?.name ?? '—' : '—', degree: dep?.degree ?? '—', job: job?.name ?? '—' };
    }).filter(r => r.name));
  }, [query.data, data.jobs]);
  const visible = rows.filter(r => match('benefit', r.benefit_id) && match('company_id', r.company_id) && match('target', r.target) && match('name', r.name, false) && match('holder', r.holder, false));
  return <>
    <div className="page-heading"><div><h1>Consulta de beneficiários</h1><p>Todas as pessoas marcadas em cada benefício.</p></div></div>
    <section className="records-section">
      <div className="filter-bar individual-filters"><ClearFilters/>
        {field('benefit', 'Benefício', (query.data?.benefits ?? []).map(b => ({ value: b.id, label: b.name })))}
        {field('company_id', 'Empresa', data.companies.map(c => ({ value: c.id, label: c.name })))}
        {field('target', 'Tipo', targetOptions)}
        {field('name', 'Beneficiário')}
        {field('holder', 'Titular')}
      </div>
      {!session ? <div className="empty-state"><Gift size={32} /><h3>Entre no seu espaço para consultar beneficiários</h3></div>
        : query.isLoading ? <div className="loading-page">Carregando...</div>
        : query.error ? <div className="empty-state"><p>Não foi possível carregar.</p><Button onClick={() => query.refetch()}>Tentar novamente</Button></div>
        : <div className="table-scroll"><table className="records-table"><thead><tr><th>BENEFICIÁRIO</th><th>TIPO</th><th>TITULAR</th><th>GRAU</th><th>CARGO DO TITULAR</th><th>BENEFÍCIO</th><th>EMPRESA</th></tr></thead>
          <tbody>{visible.map(r => <tr key={r.key}><td><strong>{r.name}</strong></td><td>{targetLabels[r.target]}</td><td>{r.holder}</td><td>{r.degree}</td><td>{r.job}</td><td>{r.benefit}</td><td>{data.companies.find(c => c.id === r.company_id)?.name ?? '—'}</td></tr>)}</tbody></table>
          {!visible.length && <div className="empty-state"><Gift size={32} /><h3>{rows.length ? 'Nenhum resultado encontrado' : 'Nenhum beneficiário marcado ainda'}</h3></div>}
        </div>}
    </section>
  </>;
}
