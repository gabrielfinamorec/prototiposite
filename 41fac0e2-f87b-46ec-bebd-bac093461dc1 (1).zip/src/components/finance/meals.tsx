import { useEffect, useRef, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { Link } from '@tanstack/react-router';
import { Camera, CheckCircle2, Download, FileDown, ScanFace, Trash2, Upload, Utensils, XCircle, AlertTriangle, ArrowLeft, Plus, UserRound, Image } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { useFinance } from './workspace';
import { ClearFilters, confirmDelete } from './confirm-delete';
import { deleteFace, deleteMeal, getMeals, getTotemPeople, saveFace, validateMeal, saveManualMeal, saveVisitorMeal } from '@/lib/meals.functions';
import { br, reportCsv, reportPdf } from '@/lib/report-rules';
import { downloadBlob } from '@/lib/download';
import { SearchSelect } from './search-select';
import { mealDay, type MealRecord } from '@/lib/meal-rules';

const hour = (iso: string) => new Date(iso).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', timeZone: 'America/Sao_Paulo' });
const todayBr = mealDay;

/** Câmera ao vivo; devolve a foto em JPEG (data URL). */
function CameraBox({ onShot, label = 'Tirar foto', busy, disabled }: { onShot: (dataUrl: string) => void; label?: string; busy?: boolean; disabled?: boolean }) {
  const video = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    let stream: MediaStream | null = null;
    let disposed = false;
    if (!navigator.mediaDevices?.getUserMedia) { setError('Câmera indisponível neste navegador.'); return; }
    navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 640, height: 480 } })
      .then(s => { if (disposed) { s.getTracks().forEach(t => t.stop()); return; } stream = s; if (video.current) { video.current.srcObject = s; void video.current.play(); } })
      .catch(() => setError('Não foi possível abrir a câmera. Permita o acesso à câmera no navegador.'));
    return () => { disposed = true; stream?.getTracks().forEach(t => t.stop()); };
  }, []);
  const shoot = () => {
    const v = video.current; if (!v || !v.videoWidth) return;
    const c = document.createElement('canvas'); c.width = v.videoWidth; c.height = v.videoHeight;
    c.getContext('2d')?.drawImage(v, 0, 0); onShot(c.toDataURL('image/jpeg', 0.85));
  };
  return <div className="flex flex-col items-center gap-3">
    {error ? <p className="field-error" role="alert">{error}</p> : <video ref={video} playsInline muted className="w-full max-w-md rounded-lg bg-muted aspect-[4/3] object-cover -scale-x-100" />}
    <Button size="lg" disabled={!!error || busy || disabled} onClick={shoot}><Camera />{busy ? 'Verificando...' : label}</Button>
  </div>;
}

function FacePhoto({ path }: { path: string }) {
  const [url, setUrl] = useState('');
  useEffect(() => { void supabase.storage.from('people-documents').createSignedUrl(path, 600).then(({ data }) => setUrl(data?.signedUrl ?? '')); }, [path]);
  return url ? <img src={url} alt="Foto do registro" className="h-40 w-40 rounded-lg object-cover" /> : <div className="h-40 w-40 rounded-lg bg-muted" />;
}

export function Meals() {
  const { data, session, requireAccess } = useFinance();
  const get = useServerFn(getMeals), save = useServerFn(saveFace), removeFace = useServerFn(deleteFace), removeMeal = useServerFn(deleteMeal);
  const qc = useQueryClient();
  const query = useQuery({ queryKey: ['meals', session?.user.id], queryFn: () => get(), enabled: !!session });
  const [manual, setManual] = useState(false);
  const [photo, setPhoto] = useState<string | null>(null);
  const [tab, setTab] = useState<'almocos' | 'faciais'>('almocos');
  const [f, setF] = useState({ company: 'all', name: '', from: '', to: '', face: 'all' });
  const [editing, setEditing] = useState<{ id: string; name: string } | null>(null);
  const [camera, setCamera] = useState(false), [busy, setBusy] = useState(false);
  const refresh = () => qc.invalidateQueries({ queryKey: ['meals'] });
  const employees = query.data?.employees ?? [], faces = query.data?.faces ?? [], meals = query.data?.meals ?? [];
  const company = (id: string) => data.companies.find(c => c.id === id)?.name ?? '—';
  const job = (id?: string) => data.jobs.find(j => j.id === id)?.name ?? '—';
  const emp = (id: string | null) => employees.find(e => e.id === id);
  const faceOf = (id: string) => faces.find(x => x.employee_id === id);

  const mealName = (m: MealRecord) => m.visitor_name ?? emp(m.employee_id)?.name ?? '—';
  const mealRows = meals.filter(m => (f.company === 'all' || m.company_id === f.company) && (!f.from || m.meal_date >= f.from) && (!f.to || m.meal_date <= f.to) && mealName(m).toLocaleLowerCase().includes(f.name.toLocaleLowerCase()));
  const people = employees.filter(e => (f.company === 'all' || e.company_id === f.company) && e.name.toLocaleLowerCase().includes(f.name.toLocaleLowerCase()) && (f.face === 'all' || (f.face === 'sim') === !!faceOf(e.id)));
  const report = () => ({ columns: ['Data', 'Horário', 'Nome', 'Tipo', 'Cargo', 'Empresa', 'Origem'], rows: mealRows.map(m => ({ company_id: m.company_id, date: m.meal_date, cells: [br(m.meal_date), hour(m.served_at), mealName(m), m.employee_id ? 'Colaborador' : 'Visita', job(emp(m.employee_id)?.job_id), company(m.company_id), m.source === 'manual' ? 'Manual' : m.source === 'visita' ? 'Tablet · visita' : 'Facial'] })) });

  async function storeFace(blob: Blob, type: string) {
    if (!editing || !session) return;
    setBusy(true);
    try {
      const path = `${session.user.id}/faces/${editing.id}-${crypto.randomUUID()}.${type === 'image/png' ? 'png' : 'jpg'}`;
      const { error } = await supabase.storage.from('people-documents').upload(path, blob, { contentType: type });
      if (error) throw error;
      await save({ data: { employee_id: editing.id, photo_path: path } });
      await refresh(); setCamera(false); toast.success('Facial cadastrada');
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Não foi possível salvar a foto'); } finally { setBusy(false); }
  }
  const onFile = (file?: File) => { if (!file) return; if (!['image/png', 'image/jpeg'].includes(file.type) || file.size > 5 * 1024 * 1024) { toast.error('Selecione PNG ou JPEG de até 5 MB.'); return; } void storeFace(file, file.type); };
  const onShot = async (url: string) => storeFace(await (await fetch(url)).blob(), 'image/jpeg');
  const current = editing ? faceOf(editing.id) : undefined;

  return <>
    <div className="page-heading"><div><h1>Refeitório</h1></div>
      <div className="heading-actions"><Button onClick={() => session ? setManual(true) : requireAccess()}><Plus />Registrar almoço</Button><Button asChild variant="outline"><Link to="/totem"><ScanFace />Abrir tela do tablet</Link></Button></div></div>
    <div className="flex gap-2 mb-3"><Button variant={tab === 'almocos' ? 'default' : 'outline'} onClick={() => setTab('almocos')}><Utensils />Almoços</Button><Button variant={tab === 'faciais' ? 'default' : 'outline'} onClick={() => setTab('faciais')}><ScanFace />Faciais</Button></div>
    <section className="records-section">
      <div className="filter-bar individual-filters"><ClearFilters />
        <label className="table-filter">Empresa<select aria-label="Filtrar Empresa" value={f.company} onChange={e => setF({ ...f, company: e.target.value })}><option value="all">Todos</option>{data.companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
        <label className="table-filter">Nome<Input aria-label="Filtrar Nome" value={f.name} onChange={e => setF({ ...f, name: e.target.value })} /></label>
        {tab === 'almocos' ? <>
          <label className="table-filter">De<Input type="date" aria-label="Data inicial" value={f.from} onChange={e => setF({ ...f, from: e.target.value })} /></label>
          <label className="table-filter">Até<Input type="date" aria-label="Data final" value={f.to} onChange={e => setF({ ...f, to: e.target.value })} /></label>
        </> : <label className="table-filter">Facial<select aria-label="Filtrar Facial" value={f.face} onChange={e => setF({ ...f, face: e.target.value })}><option value="all">Todos</option><option value="sim">Cadastrada</option><option value="nao">Pendente</option></select></label>}
        {tab === 'almocos' && <div className="flex gap-2 items-end ml-auto">
          <Button variant="outline" size="sm" onClick={() => downloadBlob(reportPdf('Relatório de almoços', report(), `${f.from ? br(f.from) : 'início'} a ${f.to ? br(f.to) : 'hoje'}`), 'almocos.pdf')}><FileDown />PDF</Button>
          <Button variant="outline" size="sm" onClick={() => downloadBlob(reportCsv(report()), 'almocos.csv')}><Download />CSV</Button>
        </div>}
      </div>
      {!session ? <div className="empty-state"><Utensils size={32} /><h3>Entre no seu espaço para usar o refeitório</h3><Button onClick={() => requireAccess()}>Entrar</Button></div>
        : query.isLoading ? <div className="loading-page">Carregando...</div>
        : query.error ? <div className="empty-state"><p>Não foi possível carregar.</p><Button onClick={() => query.refetch()}>Tentar novamente</Button></div>
        : tab === 'almocos' ? <div className="table-scroll"><table className="records-table"><thead><tr><th>DATA</th><th>HORÁRIO</th><th>NOME</th><th>TIPO</th><th>CARGO</th><th>EMPRESA</th><th>ORIGEM</th><th>FOTO</th><th></th></tr></thead>
          <tbody>{mealRows.map(m => <tr key={m.id}><td>{br(m.meal_date)}</td><td>{hour(m.served_at)}</td><td><strong>{mealName(m)}</strong></td><td>{m.employee_id ? 'Colaborador' : 'Visita'}</td><td>{job(emp(m.employee_id)?.job_id)}</td><td>{company(m.company_id)}</td><td>{m.source === 'manual' ? 'Manual' : m.source === 'visita' ? 'Tablet · visita' : 'Facial'}</td><td>{m.photo_path ? <Button variant="ghost" size="sm" aria-label={`Ver foto de ${mealName(m)}`} onClick={() => setPhoto(m.photo_path)}><Image /></Button> : <span className="text-muted-foreground">Sem foto antiga</span>}</td>
            <td><Button variant="ghost" size="sm" aria-label="Apagar almoço" onClick={async () => { if (!(await confirmDelete('Apagar este registro de almoço?'))) return; try { await removeMeal({ data: { id: m.id } }); await refresh(); toast.success('Registro apagado'); } catch { toast.error('Não foi possível apagar'); } }}><Trash2 /></Button></td></tr>)}</tbody></table>
          {!mealRows.length && <div className="empty-state"><Utensils size={32} /><h3>Nenhum almoço encontrado</h3></div>}</div>
        : <div className="table-scroll"><table className="records-table"><thead><tr><th>COLABORADOR</th><th>CARGO</th><th>EMPRESA</th><th>FACIAL</th></tr></thead>
          <tbody>{people.map(e => <tr key={e.id} className="document-row" onClick={() => { setEditing({ id: e.id, name: e.name }); setCamera(false); }}><td><strong>{e.name}</strong></td><td>{job(e.job_id)}</td><td>{company(e.company_id)}</td>
            <td>{faceOf(e.id) ? <span className="status-pill text-green-700">Cadastrada</span> : <span className="status-pill text-amber-700">Pendente</span>}</td></tr>)}</tbody></table>
          {!people.length && <div className="empty-state"><ScanFace size={32} /><h3>Nenhum colaborador encontrado</h3></div>}</div>}
    </section>

    {manual && session && <ManualMealDialog employees={employees} companies={data.companies} onClose={() => setManual(false)} onSaved={async () => { await refresh(); await qc.invalidateQueries({ queryKey: ['consult'] }); setManual(false); }} />}
    <Dialog open={!!photo} onOpenChange={o => !o && setPhoto(null)}><DialogContent><DialogHeader><DialogTitle>Foto do almoço</DialogTitle></DialogHeader>{photo && <div className="flex justify-center"><FacePhoto path={photo} /></div>}<DialogFooter><Button variant="outline" onClick={() => setPhoto(null)}>Fechar</Button></DialogFooter></DialogContent></Dialog>
    <Dialog open={!!editing} onOpenChange={o => !o && setEditing(null)}>
      <DialogContent><DialogHeader><DialogTitle>Facial · {editing?.name}</DialogTitle></DialogHeader>
        {camera ? <CameraBox onShot={u => void onShot(u)} busy={busy} />
          : <div className="flex flex-col items-center gap-3">
            {current ? <FacePhoto path={current.photo_path} /> : <p className="field-hint">Nenhuma facial cadastrada. Use uma foto de frente, com o rosto bem iluminado.</p>}
            <div className="flex gap-2 flex-wrap justify-center">
              <Button onClick={() => setCamera(true)}><Camera />Tirar foto agora</Button>
              <Button variant="outline" asChild><label className="cursor-pointer"><Upload />Enviar foto<input type="file" accept="image/png,image/jpeg" className="hidden" onChange={e => onFile(e.target.files?.[0])} /></label></Button>
            </div>
          </div>}
        <DialogFooter>
          {current && !camera && <Button variant="ghost" className="text-destructive mr-auto" onClick={async () => { if (!editing || !(await confirmDelete('Apagar a facial deste colaborador?'))) return; await removeFace({ data: { employee_id: editing.id } }); await refresh(); toast.success('Facial apagada'); }}><Trash2 />Apagar facial</Button>}
          {camera && <Button variant="outline" onClick={() => setCamera(false)}>Voltar</Button>}
          <Button variant="outline" onClick={() => setEditing(null)}>Fechar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  </>;
}

type Result = { status: 'liberado' | 'duplicado' | 'nao_reconhecido' | 'sem_facial' | 'erro'; time: string | null; message?: string };

export function Totem() {
  const { session, requireAccess } = useFinance();
  const get = useServerFn(getTotemPeople), validate = useServerFn(validateMeal), visitorSave = useServerFn(saveVisitorMeal);
  const query = useQuery({ queryKey: ['totem', session?.user.id], queryFn: () => get(), enabled: !!session });
  const [company, setCompany] = useState(''), [search, setSearch] = useState('');
  const [visitor, setVisitor] = useState(false), [visitorName, setVisitorName] = useState('');
  const [person, setPerson] = useState<{ id: string; name: string } | null>(null);
  const [busy, setBusy] = useState(false), [result, setResult] = useState<Result | null>(null);
  const reset = () => { setPerson(null); setResult(null); setSearch(''); setVisitor(false); setVisitorName(''); };
  useEffect(() => { if (!result) return; const t = setTimeout(reset, result.status === 'liberado' ? 3500 : 6000); return () => clearTimeout(t); }, [result]);
  const companies = query.data?.companies ?? [];
  useEffect(() => { if (!company && companies.length === 1 && companies[0]) setCompany(companies[0].id); }, [companies, company]);
  const people = (query.data?.people ?? []).filter(p => (!company || p.company_id === company) && p.name.toLocaleLowerCase().includes(search.toLocaleLowerCase()));
  const first = (visitor ? visitorName : person?.name ?? '').split(' ')[0];

  const check = async (image: string) => {
    if (!person) return; setBusy(true);
    try { setResult(await validate({ data: { employee_id: person.id, image } }) as Result); }
    catch { setResult({ status: 'erro', time: null, message: 'Falha de conexão.' }); } finally { setBusy(false); }
  };

  const checkVisitor = async (image: string) => {
    if (!company || !visitorName.trim()) { toast.error('Informe seu nome e selecione a empresa'); return; }
    setBusy(true);
    try { setResult(await visitorSave({ data: { company_id: company, visitor_name: visitorName.trim(), image } })); }
    catch (e) { setResult({ status: 'erro', time: null, message: e instanceof Error ? e.message : 'Não foi possível registrar' }); }
    finally { setBusy(false); }
  };

  if (!session) return <main className="access-page"><div className="access-panel text-center flex flex-col gap-3"><Utensils className="mx-auto" size={40} /><h1 className="text-2xl font-bold">Refeitório</h1><p>Entre com a conta da empresa para ligar o tablet.</p><Button onClick={() => requireAccess()}>Entrar</Button><Link to="/acesso" className="text-sm text-muted-foreground">Ir para a página de acesso</Link></div></main>;

  return <main className="min-h-svh bg-muted p-4 flex flex-col items-center gap-4">
    <header className="w-full max-w-3xl flex items-center justify-between"><h1 className="text-2xl font-bold flex items-center gap-2"><Utensils />Refeitório · {br(todayBr())}</h1><Link to="/refeitorio" className="text-sm text-muted-foreground flex items-center gap-1"><ArrowLeft size={14} />Sair do totem</Link></header>
    <section className="w-full max-w-3xl rounded-xl bg-card border p-6 shadow-sm">
      {result ? <div className="flex flex-col items-center gap-4 py-10 text-center" role="status">
          {result.status === 'liberado' ? <><CheckCircle2 size={96} className="text-green-600" /><h2 className="text-3xl font-bold text-green-700">Almoço liberado!</h2><p className="text-xl">Bom apetite, {first}!</p></>
          : result.status === 'duplicado' ? <><AlertTriangle size={96} className="text-amber-500" /><h2 className="text-3xl font-bold text-amber-600">Almoço já registrado hoje</h2>{result.time && <p className="text-xl">Registrado às {hour(result.time)}.</p>}</>
          : <><XCircle size={96} className="text-destructive" /><h2 className="text-3xl font-bold text-destructive">{result.status === 'nao_reconhecido' ? 'Rosto não reconhecido' : result.status === 'sem_facial' ? 'Facial não cadastrada' : 'Não foi possível validar'}</h2><p className="text-xl">{result.status === 'nao_reconhecido' ? 'Tente novamente olhando para a câmera.' : result.status === 'sem_facial' ? 'Procure o RH para cadastrar sua facial.' : result.message}</p></>}
          <Button size="lg" onClick={reset}>Próximo</Button>
        </div>
      : visitor ? <div className="flex flex-col gap-4"><h2 className="text-2xl font-semibold">Sou visita</h2><label>Empresa<select aria-label="Empresa da visita" disabled={busy} className="w-full h-12 rounded-md border bg-background px-3" value={company} onChange={e => setCompany(e.target.value)}><option value="">Selecione</option>{companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label><label>Nome completo<Input aria-label="Nome da visita" disabled={busy} maxLength={150} value={visitorName} onChange={e => setVisitorName(e.target.value)} /></label><p className="text-sm text-muted-foreground">Sua foto será guardada com o almoço para conferência pelo RH.</p><CameraBox onShot={u => void checkVisitor(u)} label="Tirar foto e registrar almoço" busy={busy} disabled={!company || !visitorName.trim()} /><Button variant="outline" disabled={busy} onClick={reset}>Voltar</Button></div>
      : person ? <div className="flex flex-col gap-4 items-center"><h2 className="text-2xl font-semibold">Olá, {first}! Olhe para a câmera.</h2><CameraBox onShot={u => void check(u)} label="Validar almoço" busy={busy} /><Button variant="outline" disabled={busy} onClick={reset}>Não sou eu</Button></div>
      : <div className="flex flex-col gap-4">
          {companies.length > 1 && <select aria-label="Empresa" className="h-12 rounded-md border px-3 text-lg" value={company} onChange={e => setCompany(e.target.value)}><option value="">Todas as empresas</option>{companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select>}
          <Button variant="outline" size="lg" onClick={() => setVisitor(true)}><UserRound />Sou visita</Button><Input aria-label="Pesquisar seu nome" placeholder="Digite seu nome" className="h-14 text-xl" value={search} onChange={e => setSearch(e.target.value)} />
          {query.isLoading ? <p>Carregando...</p> : <div className="grid gap-2 sm:grid-cols-2 max-h-[60svh] overflow-y-auto">
            {people.map(p => <Button key={p.id} variant="outline" className="h-auto min-h-14 whitespace-normal flex flex-col items-start p-4 text-left text-lg font-medium" disabled={!p.hasFace} onClick={() => setPerson({ id: p.id, name: p.name })}>{p.name}{!p.hasFace && <small className="block text-sm text-muted-foreground">Facial não cadastrada</small>}</Button>)}
            {!people.length && <p className="text-muted-foreground">Nenhum nome encontrado.</p>}
          </div>}
        </div>}
    </section>
  </main>;
}


function ManualMealDialog({ employees, companies, onClose, onSaved }: { employees: { id: string; company_id: string; name: string }[]; companies: { id: string; name: string }[]; onClose: () => void; onSaved: () => Promise<void> }) {
  const save = useServerFn(saveManualMeal);
  const [form, setForm] = useState({ company_id: companies.length === 1 ? companies[0]?.id ?? '' : '', kind: 'colaborador', employee_id: '', visitor_name: '', meal_date: todayBr(), time: hour(new Date().toISOString()) });
  const [image, setImage] = useState(''), [camera, setCamera] = useState(false), [busy, setBusy] = useState(false);
  const readPhoto = (file?: File) => {
    if (!file) return;
    if (!['image/png','image/jpeg'].includes(file.type) || file.size > 5 * 1024 * 1024) { toast.error('Selecione PNG ou JPEG de até 5 MB.'); return; }
    const reader = new FileReader(); reader.onload = () => { if (typeof reader.result === 'string') setImage(reader.result); }; reader.readAsDataURL(file);
  };
  const submit = async () => {
    if (!form.company_id || !form.meal_date || !form.time || !image || (form.kind === 'colaborador' ? !form.employee_id : !form.visitor_name.trim())) { toast.error('Preencha os campos e anexe ou tire uma foto'); return; }
    setBusy(true);
    try { await save({ data: { company_id: form.company_id, employee_id: form.kind === 'colaborador' ? form.employee_id : undefined, visitor_name: form.kind === 'visita' ? form.visitor_name : undefined, meal_date: form.meal_date, time: form.time, image } }); await onSaved(); toast.success('Almoço registrado'); }
    catch (e) { toast.error(e instanceof Error ? e.message : 'Não foi possível registrar'); } finally { setBusy(false); }
  };
  return <Dialog open onOpenChange={o => !o && !busy && onClose()}><DialogContent className="max-h-[90svh] overflow-y-auto"><DialogHeader><DialogTitle>Registrar almoço manual</DialogTitle></DialogHeader>
    <div className="grid gap-3"><label>Empresa<select aria-label="Empresa do almoço" className="h-9 w-full rounded-md border bg-background px-3" value={form.company_id} onChange={e => setForm({ ...form, company_id: e.target.value, employee_id: '' })}><option value="">Selecione</option>{companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
    <div className="flex gap-2"><Button variant={form.kind === 'colaborador' ? 'default' : 'outline'} onClick={() => setForm({ ...form, kind: 'colaborador' })}>Colaborador</Button><Button variant={form.kind === 'visita' ? 'default' : 'outline'} onClick={() => setForm({ ...form, kind: 'visita' })}><UserRound />Visita</Button></div>
    {form.kind === 'colaborador' ? <label>Colaborador<SearchSelect label="Colaborador do almoço" value={form.employee_id} onChange={employee_id => setForm({ ...form, employee_id })} options={employees.filter(e => e.company_id === form.company_id).map(e => ({ value: e.id, label: e.name }))} /></label> : <label>Nome da visita<Input aria-label="Nome da visita" maxLength={150} value={form.visitor_name} onChange={e => setForm({ ...form, visitor_name: e.target.value })} /></label>}
    <div className="grid grid-cols-2 gap-3"><label>Data<Input aria-label="Data do almoço" type="date" value={form.meal_date} onChange={e => setForm({ ...form, meal_date: e.target.value })} /></label><label>Horário<Input aria-label="Horário do almoço" type="time" value={form.time} onChange={e => setForm({ ...form, time: e.target.value })} /></label></div>
    {camera ? <CameraBox onShot={u => { setImage(u); setCamera(false); }} /> : <>{image && <img src={image} alt="Foto do almoço a registrar" className="mx-auto h-32 w-32 rounded-md object-cover" />}<div className="flex gap-2"><Button variant="outline" onClick={() => setCamera(true)}><Camera />Tirar foto</Button><Button variant="outline" asChild><label className="cursor-pointer"><Upload />Enviar foto<input aria-label="Foto do almoço" type="file" accept="image/png,image/jpeg" className="hidden" onChange={e => readPhoto(e.target.files?.[0])} /></label></Button></div></>}
    </div><DialogFooter><Button variant="outline" disabled={busy} onClick={onClose}>Voltar</Button><Button disabled={busy || !image} onClick={() => void submit()}>{busy ? 'Salvando...' : 'Salvar almoço'}</Button></DialogFooter>
  </DialogContent></Dialog>;
}
