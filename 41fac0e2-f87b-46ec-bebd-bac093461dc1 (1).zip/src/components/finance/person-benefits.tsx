import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { Gift } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from '@tanstack/react-router';
import { getPersonBenefits, setPersonBenefit } from '@/lib/benefits.functions';

/** Aba "Benefícios" do colaborador/dependente: marca e desmarca a pessoa nos benefícios cadastrados. */
export function PersonBenefits({ personId, target }: { personId: string; target: 'colaborador' | 'dependente' }) {
  const get = useServerFn(getPersonBenefits), set = useServerFn(setPersonBenefit);
  const qc = useQueryClient();
  const key = ['person-benefits', personId];
  const q = useQuery({ queryKey: key, queryFn: () => get({ data: { person_id: personId, target } }) });
  const toggle = async (benefit_id: string, active: boolean) => {
    try { await set({ data: { benefit_id, person_id: personId, active } }); await Promise.all([qc.invalidateQueries({ queryKey: key }), qc.invalidateQueries({ queryKey: ['benefits'] })]); toast.success(active ? 'Benefício incluído' : 'Benefício retirado'); }
    catch (e) { toast.error(e instanceof Error ? e.message : 'Não foi possível atualizar'); }
  };
  if (q.isLoading) return <div className="loading-page">Carregando...</div>;
  if (q.error) return <div className="empty-state"><p>Não foi possível carregar os benefícios.</p></div>;
  const list = q.data ?? [];
  if (!list.length) return <div className="empty-state"><Gift size={32} /><h3>Nenhum benefício para {target === 'colaborador' ? 'colaborador' : 'dependente'} cadastrado nesta empresa</h3><Link to="/beneficios" className="text-primary underline">Cadastrar benefícios</Link></div>;
  return <div className="table-scroll"><table className="records-table"><thead><tr><th>RECEBE</th><th>BENEFÍCIO</th><th>OBSERVAÇÕES</th></tr></thead>
    <tbody>{list.map(b => <tr key={b.id}><td><input type="checkbox" aria-label={b.name} checked={b.active} onChange={e => toggle(b.id, e.target.checked)} /></td><td><strong>{b.name}</strong></td><td>{b.notes || '—'}</td></tr>)}</tbody></table></div>;
}
