import { useRef, useState } from 'react';
import { Paperclip, Download, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { deliverFile } from '@/lib/download';
import type { Documents } from '@/lib/people-schema';

export function PeopleDocuments({required,value,onChange,owner,onBusy}:{required:readonly (readonly [string,string])[];value:Documents;onChange:(v:Documents)=>void;owner:string;onBusy?:(busy:boolean)=>void}) {
  return <div className="people-documents">{required.map(([key,label])=><Document key={key} label={label} value={value[key]??{na:false,path:'',name:''}} owner={owner} {...(onBusy?{onBusy}:{})} onChange={doc=>onChange({...value,[key]:doc})}/>)}</div>;
}
function Document({label,value,onChange,owner,onBusy}:{label:string;value:Documents[string];onChange:(v:Documents[string])=>void;owner:string;onBusy?:(b:boolean)=>void}) {
  const input=useRef<HTMLInputElement>(null);const [busy,setBusy]=useState(false);
  async function upload(file?:File) {
    if(!file)return;
    if(!['image/png','image/jpeg','application/pdf'].includes(file.type)||file.size>10*1024*1024) {toast.error('Selecione PNG, JPEG ou PDF de até 10 MB.');return;}
    setBusy(true);onBusy?.(true);
    try {
      const bytes=new Uint8Array(await file.slice(0,8).arrayBuffer());
      const valid=file.type==='application/pdf'?String.fromCharCode(...bytes.slice(0,5))==='%PDF-':file.type==='image/png'?bytes[0]===137&&bytes[1]===80&&bytes[2]===78&&bytes[3]===71:bytes[0]===255&&bytes[1]===216&&bytes[2]===255;
      if(!valid)throw new Error('O conteúdo do arquivo não corresponde ao formato.');
      const extension=file.type==='application/pdf'?'pdf':file.type==='image/png'?'png':'jpg';
      const path=`${owner}/${crypto.randomUUID()}/documento.${extension}`;
      const {error}=await supabase.storage.from('people-documents').upload(path,file,{contentType:file.type});if(error)throw error;
      onChange({na:false,path,name:file.name});
    }catch(e){toast.error(e instanceof Error?e.message:'Não foi possível anexar.');}finally{setBusy(false);onBusy?.(false);}
  }
  async function download(){setBusy(true);try{const {data,error}=await supabase.storage.from('people-documents').download(value.path);if(error)throw error;await deliverFile(data,value.name||'documento');}catch{toast.error('Não foi possível baixar o documento.');}finally{setBusy(false);}}
  return <div className="people-document"><h3>{label}{!value.na&&<span className="text-primary"> *</span>}</h3><input hidden ref={input} type="file" accept="image/png,image/jpeg,application/pdf" aria-label={`Anexar ${label}`} onChange={e=>{void upload(e.target.files?.[0]);e.target.value='';}}/>
    <div className="flex flex-wrap items-center gap-2"><Button type="button" variant="outline" disabled={busy||value.na} onClick={()=>input.current?.click()}><Paperclip size={16}/>{busy?'Aguarde...':value.path?'Substituir anexo':'Anexar documento'}</Button>{value.path&&<><Button type="button" variant="ghost" size="icon" title={`Baixar ${label}`} disabled={busy} onClick={download}><Download/></Button><Button type="button" variant="ghost" size="icon" title={`Remover ${label}`} onClick={()=>onChange({na:false,path:'',name:''})}><X/></Button></>}</div>
    {value.path&&<small className="document-name">{value.name}</small>}<label className="people-check"><input type="checkbox" checked={value.na} disabled={busy} onChange={e=>onChange({...value,na:e.target.checked})}/>Não se aplica</label>
  </div>;
}