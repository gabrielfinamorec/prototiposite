import { useEffect, useMemo, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { ChevronLeft, ChevronRight, Plus, Palmtree, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { SearchSelect } from './search-select';
import { useFinance } from './workspace';
import { actOnVacations, deleteVacation, getVacations, saveVacation } from '@/lib/vacations.functions';
import { getCalendar } from '@/lib/calendar.functions';
import { allowedActions, statusClass, vacationDays, vacationSchema, vacationStatus, vacationStatuses, type VacationAction, type VacationStatus } from '@/lib/vacation-rules';
import { iso, kindLabels, resolveDay } from '@/lib/calendar-rules';
import { ClearFilters, confirmDelete } from './confirm-delete';

const months = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
const weekdays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
const br = (d: string) => d ? d.split('-').reverse().join('/') : '—';
const actionLabels: Record<VacationAction, string> = { aprovar: 'Aprovar', cancelar: 'Cancelar', reabrir: 'Reabrir', finalizar: 'Finalizar', desfazer: 'Desfazer confirmação' };

export type VacationRow = { id: string; employee_id: string; company_id: string; name: string; department: string; department_id: string; job: string; job_id: string; start_date: string; end_date: string; days: number; status: VacationStatus; notes: string };

export function useVacations() {
  const { data, session } = useFinance();
  const get = useServerFn(getVacations);
  const query = useQuery({ queryKey: ['vacations', session?.user.id], queryFn: () => get(), enabled: !!session });
  const today = query.data?.today ?? iso(new Date().getFullYear(), new Date().getMonth() + 1, new Date().getDate());
  const employees = query.data?.employees ?? [];
  const rows: VacationRow[] = useMemo(() => (query.data?.requests ?? []).map(r => {
    const emp = employees.find(e => e.id === r.employee_id);
    const job = data.jobs.find(j => j.id === emp?.job_id);
    const dep = data.departments.find(d => d.id === job?.department_id);
    return { id: r.id, employee_id: r.employee_id, company_id: r.company_id, name: emp?.name ?? '—', department: dep?.name ?? '—', department_id: dep?.id ?? '', job: job?.name ?? '—', job_id: job?.id ?? '', start_date: r.start_date, end_date: r.end_date, days: vacationDays(r.start_date, r.end_date), status: vacationStatus(r, today), notes: r.notes };
  }), [query.data, employees, data.jobs, data.departments, today]);
  return { query, rows, employees, today };
}

type FilterKey = 'company_id' | 'name' | 'department_id' | 'job_id' | 'start' | 'end' | 'days' | 'status' | 'employee';
function useFilters() {
  const [filters, setFilters] = useState<Partial<Record<FilterKey, string>>>({});
  const field = (key: FilterKey, label: string, options?: { value: string; label: string }[], type = 'text') => <label className="table-filter">{label}{options
    ? <select aria-label={`Filtrar ${label}`} value={filters[key] ?? 'all'} onChange={e => setFilters(f => ({ ...f, [key]: e.target.value }))}><option value="all">Todos</option>{options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}</select>
    : <Input type={type} aria-label={`Filtrar ${label}`} value={filters[key] ?? ''} onChange={e => setFilters(f => ({ ...f, [key]: e.target.value }))} />}</label>;
  return { filters, field };
}
const uniq = (list: { value: string; label: string }[]) => [...new Map(list.filter(o => o.value).map(o => [o.value, o])).values()].sort((a, b) => a.label.localeCompare(b.label));

/* ---------- Calendário mensal com férias encaixadas ---------- */
export function VacationMonth({ companyId, items, highlight, initial }: { companyId: string; items: VacationRow[]; highlight?: string; initial?: string }) {
  const { session } = useFinance();
  const load = useServerFn(getCalendar);
  const start = initial ? new Date(`${initial}T12:00:00`) : new Date();
  const [year, setYear] = useState(start.getFullYear()), [month, setMonth] = useState(start.getMonth());
  const cal = useQuery({ queryKey: ['calendar', companyId, year], queryFn: () => load({ data: { company_id: companyId, year } }), enabled: !!session && !!companyId });
  const saved = useMemo(() => Object.fromEntries((cal.data ?? []).map(r => [r.day, r])), [cal.data]);
  const first = new Date(year, month, 1).getDay(), total = new Date(year, month + 1, 0).getDate();
  const cells: (string | null)[] = [...Array(first).fill(null), ...Array.from({ length: total }, (_, i) => iso(year, month + 1, i + 1))];
  const [picked, setPicked] = useState<string | null>(null);
  const dayItems = (day: string) => items.filter(v => v.start_date <= day && day <= v.end_date && (!companyId || v.company_id === companyId));
  const pr = picked ? resolveDay(picked, saved[picked]) : null;
  const go = (d: number) => { const x = new Date(year, month + d, 1); setYear(x.getFullYear()); setMonth(x.getMonth()); };
  return <div className="vacation-month">
    <div className="calendar-nav"><Button variant="outline" size="icon" aria-label="Mês anterior" onClick={() => go(-1)}><ChevronLeft /></Button><strong>{months[month]} {year}</strong><Button variant="outline" size="icon" aria-label="Próximo mês" onClick={() => go(1)}><ChevronRight /></Button></div>
    <div className="calendar-grid">
      {weekdays.map(w => <div key={w} className="calendar-weekday">{w}</div>)}
      {cells.map((day, i) => {
        if (!day) return <div key={`e${i}`} className="calendar-cell empty" />;
        const r = resolveDay(day, saved[day]);
        const here = dayItems(day);
        return <button type="button" key={day} onClick={() => setPicked(day)} aria-label={`Ver informações de ${br(day)}`} className={`calendar-cell kind-${r.kind}`} title={`${kindLabels[r.kind]}${r.title ? ` · ${r.title}` : ''}`}>
          <span className="calendar-num">{Number(day.slice(8))}</span>
          {r.title && <span className="calendar-title">{r.title}</span>}
          {here.slice(0, 4).map(v => <span key={v.id} className={`vacation-chip ${statusClass[v.status]} ${v.id === highlight ? 'highlight' : ''}`} title={`${v.name} · ${v.status}`}>{v.name}</span>)}
          {here.length > 4 && <span className="calendar-title">+{here.length - 4}</span>}
        </button>;
      })}
    </div>
    <Dialog open={!!picked} onOpenChange={o => !o && setPicked(null)}>
      <DialogContent style={{ maxWidth: 820, width: "95vw" }}>{picked && pr && <>
        <DialogHeader><DialogTitle>{br(picked)} · {weekdays[new Date(`${picked}T12:00:00`).getDay()]}</DialogTitle></DialogHeader>
        <p><span className={`calendar-legend-dot kind-${pr.kind}`} /> <strong>{kindLabels[pr.kind]}</strong>{pr.title ? ` · ${pr.title}` : ''}</p>
        <h4 className="text-sm font-semibold">Férias neste dia ({dayItems(picked).length})</h4>
        {dayItems(picked).length ? <div className="table-scroll"><table className="records-table"><thead><tr><th>COLABORADOR</th><th>DEPARTAMENTO</th><th>CARGO</th><th>PERÍODO</th><th>DIAS</th><th>STATUS</th></tr></thead>
          <tbody>{dayItems(picked).map(v => <tr key={v.id}><td>{v.name}</td><td>{v.department}</td><td>{v.job}</td><td>{br(v.start_date)} a {br(v.end_date)}</td><td>{v.days}</td><td><span className={`status-badge ${statusClass[v.status]}`}>{v.status}</span></td></tr>)}</tbody></table></div>
          : <p className="text-sm text-muted-foreground">Ninguém de férias neste dia.</p>}
        <DialogFooter><Button variant="outline" onClick={() => setPicked(null)}>Fechar</Button></DialogFooter>
      </>}</DialogContent>
    </Dialog>
  </div>;
}

/* ---------- Solicitação de férias ---------- */
export function VacationRequests() {
  const { data, session, requireAccess } = useFinance();
  const { query, rows, employees } = useVacations();
  const qc = useQueryClient();
  const act = useServerFn(actOnVacations), save = useServerFn(saveVacation), remove = useServerFn(deleteVacation);
  const { filters, field } = useFilters();
  const [selected, setSelected] = useState<string[]>([]);
  const [open, setOpen] = useState<VacationRow | null>(null);
  const [form, setForm] = useState<{ id?: string; employee_id: string; start_date: string; end_date: string; notes: string } | null>(null);
  const [search, setSearch] = useState(''), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const refresh = () => qc.invalidateQueries({ queryKey: ['vacations'] });

  const visible = rows.filter(r => (!filters.company_id || filters.company_id === 'all' || r.company_id === filters.company_id)
    && (!filters.name || r.name.toLocaleLowerCase().includes(filters.name.toLocaleLowerCase()))
    && (!filters.department_id || filters.department_id === 'all' || r.department_id === filters.department_id)
    && (!filters.job_id || filters.job_id === 'all' || r.job_id === filters.job_id)
    && (!filters.start || r.start_date >= filters.start) && (!filters.end || r.end_date <= filters.end)
    && (!filters.days || String(r.days) === filters.days.trim())
    && (!filters.status || filters.status === 'all' || r.status === filters.status));
  const run = async (action: VacationAction, ids: string[]) => {
    setBusy(true);
    try { const res = await act({ data: { ids, action } }); await refresh(); setSelected([]);
      toast.success(`${res.updated} solicitação(ões) atualizada(s)${res.skipped ? ` · ${res.skipped} ignorada(s) por não se aplicar` : ''}`);
      if (open) setOpen(null);
    } catch (e) { toast.error(e instanceof Error ? e.message : 'Não foi possível atualizar'); } finally { setBusy(false); }
  };
  const submit = async () => {
    if (!form) return; setError('');
    const parsed = vacationSchema.safeParse(form);
    if (!parsed.success) { setError(parsed.error.issues[0]?.message ?? 'Verifique os campos'); return; }
    setBusy(true);
    try { await save({ data: parsed.data }); await refresh(); setForm(null); toast.success('Solicitação salva como pendente'); }
    catch (e) { setError(e instanceof Error ? e.message : 'Não foi possível salvar'); } finally { setBusy(false); }
  };
  const formDays = form?.start_date && form.end_date && form.end_date >= form.start_date ? vacationDays(form.start_date, form.end_date) : 0;
  const allChecked = visible.length > 0 && visible.every(r => selected.includes(r.id));

  return <>
    <div className="page-heading"><div><h1>Solicitação de férias</h1><p>Registre as solicitações e aprove. Clique em uma linha para ver no calendário e o histórico do colaborador.</p></div>
      <div className="heading-actions">
        <select aria-label="Ações" className="actions-select" disabled={!selected.length || busy} value="" onChange={e => e.target.value && run(e.target.value as VacationAction, selected)}>
          <option value="">Ações ({selected.length})</option>{(Object.keys(actionLabels) as VacationAction[]).map(a => <option key={a} value={a}>{actionLabels[a]}</option>)}
        </select>
        <Button onClick={() => { if (!requireAccess()) return; setError(''); setSearch(''); setForm({ employee_id: '', start_date: '', end_date: '', notes: '' }); }}><Plus />Nova solicitação</Button>
      </div>
    </div>
    <section className="records-section">
      <div className="filter-bar individual-filters"><ClearFilters/>
        {field('company_id', 'Empresa', data.companies.map(c => ({ value: c.id, label: c.name })))}
        {field('name', 'Colaborador')}
        {field('department_id', 'Departamento', uniq(data.departments.map(d => ({ value: d.id, label: d.name }))))}
        {field('job_id', 'Cargo', uniq(data.jobs.map(j => ({ value: j.id, label: j.name }))))}
        {field('start', 'Início a partir de', undefined, 'date')}
        {field('end', 'Final até', undefined, 'date')}
        {field('days', 'Nº de dias')}
        {field('status', 'Status', vacationStatuses.map(s => ({ value: s, label: s })))}
      </div>
      {!session ? <div className="empty-state"><Palmtree size={32} /><h3>Entre no seu espaço para registrar solicitações de férias</h3></div>
        : query.isLoading ? <div className="loading-page">Carregando...</div>
        : query.error ? <div className="empty-state"><p>Não foi possível carregar as solicitações.</p><Button onClick={() => query.refetch()}>Tentar novamente</Button></div>
        : <div className="table-scroll"><table className="records-table"><thead><tr>
          <th><input type="checkbox" aria-label="Selecionar todas" checked={allChecked} onChange={e => setSelected(e.target.checked ? visible.map(r => r.id) : [])} /></th>
          <th>COLABORADOR</th><th>DEPARTAMENTO</th><th>CARGO</th><th>INÍCIO DAS FÉRIAS</th><th>FINAL DAS FÉRIAS</th><th>Nº DE DIAS</th><th>STATUS</th></tr></thead>
          <tbody>{visible.map(r => <tr key={r.id} className="document-row" onClick={() => setOpen(r)}>
            <td onClick={e => e.stopPropagation()}><input type="checkbox" aria-label={`Selecionar ${r.name}`} checked={selected.includes(r.id)} onChange={e => setSelected(s => e.target.checked ? [...s, r.id] : s.filter(x => x !== r.id))} /></td>
            <td><strong>{r.name}</strong></td><td>{r.department}</td><td>{r.job}</td><td>{br(r.start_date)}</td><td>{br(r.end_date)}</td><td>{r.days}</td>
            <td><span className={`status-badge ${statusClass[r.status]}`}>{r.status}</span></td>
          </tr>)}</tbody></table>
          {!visible.length && <div className="empty-state"><Palmtree size={32} /><h3>{rows.length ? 'Nenhum resultado encontrado' : 'Nenhuma solicitação de férias registrada'}</h3></div>}
        </div>}
    </section>

    <Dialog open={!!form} onOpenChange={o => !o && setForm(null)}>
      <DialogContent><DialogHeader><DialogTitle>{form?.id ? 'Editar solicitação' : 'Nova solicitação de férias'}</DialogTitle></DialogHeader>
        {form && <div className="form-grid">
          <label>Colaborador *<SearchSelect label="Colaborador" value={form.employee_id} onChange={v => setForm({ ...form, employee_id: v })} options={employees.map(e => ({ value: e.id, label: e.name }))} /></label>
          <label>Início das férias *<Input type="date" aria-label="Início das férias" value={form.start_date} onChange={e => setForm({ ...form, start_date: e.target.value })} /></label>
          <label>Final das férias *<Input type="date" aria-label="Final das férias" min={form.start_date} value={form.end_date} onChange={e => setForm({ ...form, end_date: e.target.value })} /></label>
          <p className="field-hint">Número de dias: <strong>{formDays || '—'}</strong></p>
          <label>Observações<Textarea maxLength={2000} value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} /></label>
          {error && <p className="field-error" role="alert">{error}</p>}
        </div>}
        <DialogFooter><Button variant="outline" onClick={() => setForm(null)}>Fechar</Button><Button disabled={busy} onClick={submit}>Salvar</Button></DialogFooter>
      </DialogContent>
    </Dialog>

    <Dialog open={!!open} onOpenChange={o => !o && setOpen(null)}>
      <DialogContent className="vacation-dialog">{open && <VacationDetail row={open} rows={rows} busy={busy}
        onAction={a => run(a, [open.id])}
        onEdit={() => { setError(''); setSearch(''); setForm({ id: open.id, employee_id: open.employee_id, start_date: open.start_date, end_date: open.end_date, notes: open.notes }); setOpen(null); }}
        onDelete={async () => { if (!(await confirmDelete('A solicitação de férias será apagada.'))) return; setBusy(true); try { await remove({ data: { id: open.id } }); await refresh(); setOpen(null); toast.success('Solicitação excluída'); } catch (e) { toast.error(e instanceof Error ? e.message : 'Erro'); } finally { setBusy(false); } }} />}
      </DialogContent>
    </Dialog>
  </>;
}

function VacationDetail({ row, rows, busy, onAction, onEdit, onDelete }: { row: VacationRow; rows: VacationRow[]; busy: boolean; onAction: (a: VacationAction) => void; onEdit: () => void; onDelete: () => void }) {
  const [compare, setCompare] = useState('all');
  const others = rows.filter(r => r.company_id === row.company_id && r.id !== row.id && ['Pendente', 'Aprovada', 'Confirmada', 'Aviso', 'Finalizada'].includes(r.status));
  const people = uniq(others.map(r => ({ value: r.employee_id, label: r.name })));
  const items = [row, ...others.filter(r => compare === 'all' || r.employee_id === compare)];
  const history = rows.filter(r => r.employee_id === row.employee_id).sort((a, b) => b.start_date.localeCompare(a.start_date));
  return <>
    <DialogHeader><DialogTitle>Férias de {row.name}</DialogTitle></DialogHeader>
    <div className="vacation-summary">
      <span>{row.department} · {row.job}</span><span>{br(row.start_date)} a {br(row.end_date)} · <strong>{row.days} dias</strong></span>
      <span className={`status-badge ${statusClass[row.status]}`}>{row.status}</span>
    </div>
    {row.status === 'Aviso' && <p className="vacation-warning" role="status">As férias terminaram em {br(row.end_date)}. Clique em Finalizar para encerrar.</p>}
    <div className="vacation-actions">
      {allowedActions(row.status).map(a => <Button key={a} disabled={busy} variant={a === 'cancelar' ? 'outline' : 'default'} onClick={() => onAction(a)}>{actionLabels[a]}</Button>)}
      {row.status === 'Pendente' && <><Button variant="outline" onClick={onEdit}>Editar</Button><Button variant="ghost" className="text-destructive" onClick={onDelete}><Trash2 />Excluir</Button></>}
    </div>
    <div className="vacation-compare">
      <label className="table-filter">Comparar com<select aria-label="Comparar com colaborador" value={compare} onChange={e => setCompare(e.target.value)}><option value="all">Todas as férias pendentes e confirmadas</option>{people.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}</select></label>
      <div className="calendar-legend"><span><i className="vacation-chip highlight sample" />Esta solicitação</span><span><i className="vacation-chip pending sample" />Pendente</span><span><i className="vacation-chip approved sample" />Aprovada</span><span><i className="vacation-chip positive sample" />Confirmada</span><span><i className="vacation-chip warning sample" />Aviso</span><span><i className="vacation-chip finished sample" />Finalizada</span></div>
    </div>
    <VacationMonth companyId={row.company_id} items={items} highlight={row.id} initial={row.start_date} />
    <h3 className="vacation-history-title">Histórico de férias de {row.name}</h3>
    <div className="table-scroll"><table className="records-table compact"><thead><tr><th>INÍCIO</th><th>FINAL</th><th>DIAS</th><th>STATUS</th></tr></thead>
      <tbody>{history.map(h => <tr key={h.id} className={h.id === row.id ? 'current-row' : ''}><td>{br(h.start_date)}</td><td>{br(h.end_date)}</td><td>{h.days}</td><td><span className={`status-badge ${statusClass[h.status]}`}>{h.status}</span></td></tr>)}</tbody></table></div>
  </>;
}

/* ---------- Calendário de férias ---------- */
export function VacationCalendar() {
  const { data, session } = useFinance();
  const { rows, query } = useVacations();
  const { filters, field } = useFilters();
  const [company, setCompany] = useState('');
  useEffect(() => { if (!data.companies.some(c => c.id === company)) setCompany(data.companies[0]?.id ?? ''); }, [data.companies, company]);
  const planned = rows.filter(r => r.company_id === company && ['Pendente', 'Aprovada', 'Confirmada', 'Aviso', 'Finalizada'].includes(r.status)
    && (!filters.department_id || filters.department_id === 'all' || r.department_id === filters.department_id)
    && (!filters.job_id || filters.job_id === 'all' || r.job_id === filters.job_id)
    && (!filters.employee || filters.employee === 'all' || r.employee_id === filters.employee)
    && (!filters.status || filters.status === 'all' || r.status === filters.status));
  return <>
    <div className="page-heading"><div><h1>Calendário de férias</h1><p>Compare férias planejadas e confirmadas por departamento, cargo e colaborador.</p></div></div>
    <div className="filter-bar individual-filters"><ClearFilters/>
      <label className="table-filter">Empresa<select aria-label="Empresa" value={company} onChange={e => setCompany(e.target.value)}>{data.companies.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
      {field('department_id', 'Departamento', uniq(data.departments.filter(d => d.company_id === company).map(d => ({ value: d.id, label: d.name }))))}
      {field('job_id', 'Cargo', uniq(data.jobs.filter(j => j.company_id === company).map(j => ({ value: j.id, label: j.name }))))}
      {field('employee', 'Colaborador', uniq(rows.filter(r => r.company_id === company).map(r => ({ value: r.employee_id, label: r.name }))))}
      {field('status', 'Status', ['Pendente', 'Aprovada', 'Confirmada', 'Aviso', 'Finalizada'].map(s => ({ value: s, label: s === 'Pendente' ? 'Pendente (planejada)' : s })))}
    </div>
    <div className="calendar-legend"><span><i className="vacation-chip pending sample" />Pendente (planejada)</span><span><i className="vacation-chip approved sample" />Aprovada</span><span><i className="vacation-chip positive sample" />Confirmada (em férias)</span><span><i className="vacation-chip warning sample" />Aviso</span><span><i className="vacation-chip finished sample" />Finalizada</span></div>
    {!session ? <div className="empty-state"><Palmtree size={32} /><h3>Entre no seu espaço para ver o calendário de férias</h3></div>
      : query.isLoading ? <div className="loading-page">Carregando...</div>
      : !company ? <div className="empty-state">Cadastre uma empresa para ver o calendário.</div>
      : <VacationMonth key={company} companyId={company} items={planned} />}
  </>;
}
