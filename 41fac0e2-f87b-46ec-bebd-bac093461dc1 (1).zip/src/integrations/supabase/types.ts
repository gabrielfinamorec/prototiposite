export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      benefits: {
        Row: {
          company_id: string
          created_at: string
          id: string
          member_ids: string[]
          name: string
          notes: string
          owner_id: string
          target: string
        }
        Insert: {
          company_id: string
          created_at?: string
          id?: string
          member_ids?: string[]
          name: string
          notes?: string
          owner_id?: string
          target: string
        }
        Update: {
          company_id?: string
          created_at?: string
          id?: string
          member_ids?: string[]
          name?: string
          notes?: string
          owner_id?: string
          target?: string
        }
        Relationships: [
          {
            foreignKeyName: "benefits_company_id_owner_id_fkey"
            columns: ["company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id", "owner_id"]
          },
        ]
      }
      companies: {
        Row: {
          cnpj: string
          created_at: string
          id: string
          name: string
          owner_id: string
        }
        Insert: {
          cnpj: string
          created_at?: string
          id?: string
          name: string
          owner_id?: string
        }
        Update: {
          cnpj?: string
          created_at?: string
          id?: string
          name?: string
          owner_id?: string
        }
        Relationships: []
      }
      company_calendar_days: {
        Row: {
          company_id: string
          created_at: string
          day: string
          id: string
          kind: string
          owner_id: string
          title: string
        }
        Insert: {
          company_id: string
          created_at?: string
          day: string
          id?: string
          kind: string
          owner_id?: string
          title?: string
        }
        Update: {
          company_id?: string
          created_at?: string
          day?: string
          id?: string
          kind?: string
          owner_id?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "company_calendar_days_company_id_owner_id_fkey"
            columns: ["company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id", "owner_id"]
          },
        ]
      }
      controlled_documents: {
        Row: {
          attachments: Json
          company_id: string
          created_at: string
          employee_id: string
          expiry_date: string | null
          id: string
          issue_date: string | null
          notes: string
          owner_id: string
          state: string
          type_id: string
          updated_at: string
        }
        Insert: {
          attachments?: Json
          company_id: string
          created_at?: string
          employee_id: string
          expiry_date?: string | null
          id?: string
          issue_date?: string | null
          notes?: string
          owner_id?: string
          state?: string
          type_id: string
          updated_at?: string
        }
        Update: {
          attachments?: Json
          company_id?: string
          created_at?: string
          employee_id?: string
          expiry_date?: string | null
          id?: string
          issue_date?: string | null
          notes?: string
          owner_id?: string
          state?: string
          type_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "controlled_documents_employee_id_company_id_owner_id_fkey"
            columns: ["employee_id", "company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id", "company_id", "owner_id"]
          },
          {
            foreignKeyName: "controlled_documents_type_id_owner_id_fkey"
            columns: ["type_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "document_types"
            referencedColumns: ["id", "owner_id"]
          },
        ]
      }
      departments: {
        Row: {
          active: boolean
          company_id: string
          created_at: string
          id: string
          name: string
          owner_id: string
        }
        Insert: {
          active: boolean
          company_id: string
          created_at?: string
          id?: string
          name: string
          owner_id?: string
        }
        Update: {
          active?: boolean
          company_id?: string
          created_at?: string
          id?: string
          name?: string
          owner_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "departments_company_id_owner_id_fkey"
            columns: ["company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id", "owner_id"]
          },
        ]
      }
      dependents: {
        Row: {
          active: boolean
          birth_date: string
          company_id: string
          cpf: string
          created_at: string
          degree: string
          documents: Json
          employee_id: string
          id: string
          name: string
          owner_id: string
          rg: string
          sex: string
        }
        Insert: {
          active?: boolean
          birth_date: string
          company_id: string
          cpf: string
          created_at?: string
          degree: string
          documents?: Json
          employee_id: string
          id?: string
          name: string
          owner_id?: string
          rg: string
          sex: string
        }
        Update: {
          active?: boolean
          birth_date?: string
          company_id?: string
          cpf?: string
          created_at?: string
          degree?: string
          documents?: Json
          employee_id?: string
          id?: string
          name?: string
          owner_id?: string
          rg?: string
          sex?: string
        }
        Relationships: [
          {
            foreignKeyName: "dependents_employee_id_company_id_owner_id_fkey"
            columns: ["employee_id", "company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id", "company_id", "owner_id"]
          },
        ]
      }
      document_history: {
        Row: {
          action: string
          created_at: string
          document_id: string
          id: string
          owner_id: string
          snapshot: Json
        }
        Insert: {
          action: string
          created_at?: string
          document_id: string
          id?: string
          owner_id?: string
          snapshot: Json
        }
        Update: {
          action?: string
          created_at?: string
          document_id?: string
          id?: string
          owner_id?: string
          snapshot?: Json
        }
        Relationships: [
          {
            foreignKeyName: "document_history_document_id_owner_id_fkey"
            columns: ["document_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "controlled_documents"
            referencedColumns: ["id", "owner_id"]
          },
        ]
      }
      document_types: {
        Row: {
          active: boolean
          attachments: Json
          created_at: string
          department_ids: string[]
          duration: number
          employee_ids: string[]
          guidance: string
          has_expiry: boolean
          id: string
          job_ids: string[]
          name: string
          owner_id: string
          responsible_id: string
          unit: string
        }
        Insert: {
          active?: boolean
          attachments?: Json
          created_at?: string
          department_ids?: string[]
          duration?: number
          employee_ids?: string[]
          guidance?: string
          has_expiry?: boolean
          id?: string
          job_ids?: string[]
          name: string
          owner_id?: string
          responsible_id: string
          unit?: string
        }
        Update: {
          active?: boolean
          attachments?: Json
          created_at?: string
          department_ids?: string[]
          duration?: number
          employee_ids?: string[]
          guidance?: string
          has_expiry?: boolean
          id?: string
          job_ids?: string[]
          name?: string
          owner_id?: string
          responsible_id?: string
          unit?: string
        }
        Relationships: []
      }
      employee_faces: {
        Row: {
          company_id: string
          employee_id: string
          owner_id: string
          photo_path: string
          updated_at: string
        }
        Insert: {
          company_id: string
          employee_id: string
          owner_id?: string
          photo_path: string
          updated_at?: string
        }
        Update: {
          company_id?: string
          employee_id?: string
          owner_id?: string
          photo_path?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "employee_faces_employee_id_company_id_owner_id_fkey"
            columns: ["employee_id", "company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id", "company_id", "owner_id"]
          },
        ]
      }
      employee_movements: {
        Row: {
          attachments: Json
          company_id: string
          created_at: string
          employee_id: string
          end_date: string | null
          has_notice: boolean
          id: string
          kind: string
          notes: string
          notice_end: string | null
          notice_start: string | null
          notice_type: string
          owner_id: string
          return_date: string | null
          start_date: string
          type_id: string
        }
        Insert: {
          attachments?: Json
          company_id: string
          created_at?: string
          employee_id: string
          end_date?: string | null
          has_notice?: boolean
          id?: string
          kind: string
          notes?: string
          notice_end?: string | null
          notice_start?: string | null
          notice_type?: string
          owner_id?: string
          return_date?: string | null
          start_date: string
          type_id: string
        }
        Update: {
          attachments?: Json
          company_id?: string
          created_at?: string
          employee_id?: string
          end_date?: string | null
          has_notice?: boolean
          id?: string
          kind?: string
          notes?: string
          notice_end?: string | null
          notice_start?: string | null
          notice_type?: string
          owner_id?: string
          return_date?: string | null
          start_date?: string
          type_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "employee_movements_employee_id_company_id_owner_id_fkey"
            columns: ["employee_id", "company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id", "company_id", "owner_id"]
          },
          {
            foreignKeyName: "employee_movements_type_id_owner_id_fkey"
            columns: ["type_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "movement_types"
            referencedColumns: ["id", "owner_id"]
          },
        ]
      }
      employees: {
        Row: {
          company_id: string
          created_at: string
          documents: Json
          finance: Json
          id: string
          job_id: string
          owner_id: string
          personal: Json
        }
        Insert: {
          company_id: string
          created_at?: string
          documents?: Json
          finance?: Json
          id?: string
          job_id: string
          owner_id?: string
          personal: Json
        }
        Update: {
          company_id?: string
          created_at?: string
          documents?: Json
          finance?: Json
          id?: string
          job_id?: string
          owner_id?: string
          personal?: Json
        }
        Relationships: [
          {
            foreignKeyName: "employees_company_id_owner_id_fkey"
            columns: ["company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id", "owner_id"]
          },
          {
            foreignKeyName: "employees_job_id_company_id_owner_id_fkey"
            columns: ["job_id", "company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id", "company_id", "owner_id"]
          },
        ]
      }
      jobs: {
        Row: {
          attachments: string[]
          cbo: string
          company_id: string
          created_at: string
          department_id: string
          details: Json
          hourly_rate: number
          id: string
          name: string
          no_superior: boolean
          owner_id: string
          position_x: number
          position_y: number
          superior_id: string | null
        }
        Insert: {
          attachments: string[]
          cbo: string
          company_id: string
          created_at?: string
          department_id: string
          details: Json
          hourly_rate: number
          id?: string
          name: string
          no_superior?: boolean
          owner_id?: string
          position_x?: number
          position_y?: number
          superior_id?: string | null
        }
        Update: {
          attachments?: string[]
          cbo?: string
          company_id?: string
          created_at?: string
          department_id?: string
          details?: Json
          hourly_rate?: number
          id?: string
          name?: string
          no_superior?: boolean
          owner_id?: string
          position_x?: number
          position_y?: number
          superior_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "jobs_department_id_company_id_owner_id_fkey"
            columns: ["department_id", "company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id", "company_id", "owner_id"]
          },
          {
            foreignKeyName: "jobs_superior_id_company_id_owner_id_fkey"
            columns: ["superior_id", "company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id", "company_id", "owner_id"]
          },
        ]
      }
      meal_entries: {
        Row: {
          company_id: string
          created_at: string
          employee_id: string | null
          id: string
          meal_date: string
          owner_id: string
          photo_path: string | null
          served_at: string
          source: string
          visitor_name: string | null
        }
        Insert: {
          company_id: string
          created_at?: string
          employee_id?: string | null
          id?: string
          meal_date?: string
          owner_id?: string
          photo_path?: string | null
          served_at?: string
          source: string
          visitor_name?: string | null
        }
        Update: {
          company_id?: string
          created_at?: string
          employee_id?: string | null
          id?: string
          meal_date?: string
          owner_id?: string
          photo_path?: string | null
          served_at?: string
          source?: string
          visitor_name?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "meal_entries_company_id_owner_id_fkey"
            columns: ["company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id", "owner_id"]
          },
          {
            foreignKeyName: "meal_entries_employee_id_company_id_owner_id_fkey"
            columns: ["employee_id", "company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id", "company_id", "owner_id"]
          },
        ]
      }
      meal_logs: {
        Row: {
          company_id: string
          created_at: string
          employee_id: string
          id: string
          meal_date: string
          owner_id: string
        }
        Insert: {
          company_id: string
          created_at?: string
          employee_id: string
          id?: string
          meal_date?: string
          owner_id?: string
        }
        Update: {
          company_id?: string
          created_at?: string
          employee_id?: string
          id?: string
          meal_date?: string
          owner_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "meal_logs_employee_id_company_id_owner_id_fkey"
            columns: ["employee_id", "company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id", "company_id", "owner_id"]
          },
        ]
      }
      movement_types: {
        Row: {
          active: boolean
          created_at: string
          description: string
          id: string
          initiative: string
          kind: string
          name: string
          owner_id: string
          requires_document: boolean
        }
        Insert: {
          active?: boolean
          created_at?: string
          description?: string
          id?: string
          initiative?: string
          kind: string
          name: string
          owner_id?: string
          requires_document?: boolean
        }
        Update: {
          active?: boolean
          created_at?: string
          description?: string
          id?: string
          initiative?: string
          kind?: string
          name?: string
          owner_id?: string
          requires_document?: boolean
        }
        Relationships: []
      }
      news_posts: {
        Row: {
          body: string
          created_at: string
          id: string
          image_name: string
          image_path: string
          owner_id: string
          title: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          image_name?: string
          image_path: string
          owner_id?: string
          title: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          image_name?: string
          image_path?: string
          owner_id?: string
          title?: string
        }
        Relationships: []
      }
      org_connections: {
        Row: {
          company_id: string
          id: string
          owner_id: string
          source_handle: string
          source_id: string
          target_handle: string
          target_id: string
        }
        Insert: {
          company_id: string
          id?: string
          owner_id?: string
          source_handle?: string
          source_id: string
          target_handle?: string
          target_id: string
        }
        Update: {
          company_id?: string
          id?: string
          owner_id?: string
          source_handle?: string
          source_id?: string
          target_handle?: string
          target_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "org_connections_source_id_company_id_owner_id_fkey"
            columns: ["source_id", "company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id", "company_id", "owner_id"]
          },
          {
            foreignKeyName: "org_connections_target_id_company_id_owner_id_fkey"
            columns: ["target_id", "company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id", "company_id", "owner_id"]
          },
        ]
      }
      vacation_requests: {
        Row: {
          company_id: string
          created_at: string
          employee_id: string
          end_date: string
          finished: boolean
          id: string
          notes: string
          owner_id: string
          start_date: string
          state: string
          updated_at: string
        }
        Insert: {
          company_id: string
          created_at?: string
          employee_id: string
          end_date: string
          finished?: boolean
          id?: string
          notes?: string
          owner_id?: string
          start_date: string
          state?: string
          updated_at?: string
        }
        Update: {
          company_id?: string
          created_at?: string
          employee_id?: string
          end_date?: string
          finished?: boolean
          id?: string
          notes?: string
          owner_id?: string
          start_date?: string
          state?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "vacation_requests_employee_id_company_id_owner_id_fkey"
            columns: ["employee_id", "company_id", "owner_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id", "company_id", "owner_id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      document_action: {
        Args: { _action: string; _ids: string[] }
        Returns: undefined
      }
      sync_document_assignments: {
        Args: { _owner: string }
        Returns: undefined
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
