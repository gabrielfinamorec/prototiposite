import { z } from 'zod';

const short = z.string().trim().min(1, 'Campo obrigatório').max(150);
const optional = z.string().trim().max(150).default('');
export const sexSchema = z.enum(['masculino', 'feminino']);
export const civilOptions = ['Solteiro(a)', 'Casado(a)', 'Divorciado(a)', 'Viúvo(a)', 'Separado(a)'] as const;
export const accountOptions = ['Conta corrente', 'Conta Poupança', 'Conta Investimento', 'Conta Salário'] as const;
export const birthSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Informe uma data válida').refine(value => {
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value && value <= new Date().toISOString().slice(0, 10);
}, 'Informe uma data de nascimento válida');
export const cpfSchema = z.string().trim().refine(v => v.replace(/\D/g, '').length === 11, 'CPF deve conter 11 números').transform(v => v.replace(/\D/g, ''));
export const admissionSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Informe uma data válida').refine(value => {const date=new Date(`${value}T12:00:00Z`);return Number.isFinite(date.getTime())&&date.toISOString().slice(0,10)===value;}, 'Data de admissão inválida');
export const personalSchema = z.object({
  cpf: cpfSchema, name: short, registration: optional, rg: short, work_card: short, voter_id: short,
  father: optional, father_na: z.boolean(), mother: optional, mother_na: z.boolean(),
  birth_date: birthSchema, sex: sexSchema, civil_status: z.enum(civilOptions),
  phone: z.string().trim().refine(v => v.replace(/\D/g, '').length === 11, 'Telefone deve conter DDD e 9 dígitos'),
  email: z.union([z.literal(''), z.string().trim().email('E-mail inválido').max(255)]),
  admission_date: z.union([z.literal(''),admissionSchema]).default(''),
  unhealthy: z.boolean(), dangerous: z.boolean(), night_bonus: z.boolean().default(false), hourly_rate: z.number().finite().min(0).max(9999999999),
}).superRefine((v, ctx) => {
  if (!v.father_na && !v.father) ctx.addIssue({code:'custom', path:['father'], message:'Informe o nome do pai ou marque não se aplica'});
  if (!v.mother_na && !v.mother) ctx.addIssue({code:'custom', path:['mother'], message:'Informe o nome da mãe ou marque não se aplica'});
});
export const financeSchema = z.object({bank:optional, account_type:z.union([z.literal(''),z.enum(accountOptions)]), agency:optional, account:optional, pix:optional});
export const documentSchema = z.object({na:z.boolean(), path:z.string().max(500).default(''), name:z.string().max(255).default('')});
export const documentsSchema = z.record(z.string().max(50),documentSchema);
export type Documents = z.infer<typeof documentsSchema>;
export const personalDocuments = [
  ['work_card','Carteira de Trabalho Digital'], ['pis','Cartão PIS'], ['voter','Título de eleitor'],
  ['residence','Comprovante de Residência'], ['license','CNH'], ['education','Comprovante de escolaridade'],
  ['birth','Certidão de Nascimento'], ['reservist','Certificado de reservista'], ['cpf','Arquivo CPF'], ['rg','Arquivo RG'], ['other','Outros'],
] as const;
export function employeeDocuments(sex:string) { return personalDocuments.filter(([key])=>key !== 'reservist' || sex === 'masculino'); }
export function ageAt(birth:string, today = new Date()) {
  const [y=0,m=0,d=0] = birth.split('-').map(Number);
  return today.getUTCFullYear()-y-(today.getUTCMonth()+1<m || (today.getUTCMonth()+1===m && today.getUTCDate()<d)?1:0);
}
export function dependentDocuments(v:{degree:string;birth_date:string},today = new Date()): readonly (readonly [string,string])[] {
  return v.degree === 'Cônjuge' ? [['marriage','Certidão de casamento'],['cpf','Arquivo CPF'],['rg','Arquivo RG'],['other','Outros']] :
    [['birth','Certidão de nascimento'], ageAt(v.birth_date,today)<6?['vaccine','Cartão de vacina']:['school','Declaração Escolar'], ['cpf','Arquivo CPF'],['rg','Arquivo RG'],['other','Outros']];
}
export function documentsComplete(documents:Documents, required:readonly (readonly [string,string])[]) { return required.every(([key])=>documents[key]?.na || !!documents[key]?.path); }
export const employeeMainSchema = z.object({company_id:z.string().uuid('Selecione uma empresa'), job_id:z.string().uuid('Selecione um cargo'),personal:personalSchema.refine(v=>v.admission_date.length>0,{path:['admission_date'],message:'Data de admissão obrigatória'})});
export const employeeSchema = employeeMainSchema.extend({finance:financeSchema,documents:documentsSchema}).superRefine((v,ctx)=>{
  for(const [key,label] of employeeDocuments(v.personal.sex)) if(!v.documents[key]?.na && !v.documents[key]?.path) ctx.addIssue({code:'custom',path:['documents',key],message:`Anexe ${label} ou marque não se aplica`});
});
export const dependentSchema = z.object({degree:z.enum(['Cônjuge','Filho']),name:short,cpf:cpfSchema,rg:short,birth_date:birthSchema,sex:sexSchema,active:z.boolean(),documents:documentsSchema});
export type EmployeePersonal = z.infer<typeof personalSchema>;
export type DependentValue = z.infer<typeof dependentSchema>;
export function dependentStatus(v:DependentValue,today=new Date()) { return !v.active?'Inativo':documentsComplete(v.documents,dependentDocuments(v,today))?'Ativo':'Documentação Pendente'; }
export const employeeDefaults = () => ({company_id:'',job_id:'',personal:{cpf:'',name:'',registration:'',rg:'',work_card:'',voter_id:'',father:'',father_na:false,mother:'',mother_na:false,birth_date:'',admission_date:'',sex:'' as ''|'masculino'|'feminino',civil_status:'',phone:'',email:'',unhealthy:false,dangerous:false,night_bonus:false,hourly_rate:''},finance:{bank:'',account_type:'',agency:'',account:'',pix:''},documents:{} as Documents});
export const dependentDefaults = () => ({degree:'Filho' as 'Filho'|'Cônjuge',name:'',cpf:'',rg:'',birth_date:'',sex:'' as ''|'masculino'|'feminino',active:true,documents:{} as Documents});
export function formatPhone(value:string) { const n=value.replace(/\D/g,'').slice(0,11); return n.length>7?`${n.slice(0,2)} ${n.slice(2,7)}-${n.slice(7)}`:n.length>2?`${n.slice(0,2)} ${n.slice(2)}`:n; }
export const formatCpf = (value:string)=>value.replace(/\D/g,'').slice(0,11).replace(/^(\d{3})(\d)/,'$1.$2').replace(/^(\d{3})\.(\d{3})(\d)/,'$1.$2.$3').replace(/(\d{3})\.(\d{3})\.(\d{3})(\d)/,'$1.$2.$3-$4');