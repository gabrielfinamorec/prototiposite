export type RecordFilters = Record<string,string>;
export function matchesRecord(record:Record<string,unknown>,filters:RecordFilters,jobs:{id:string;name:string}[]) {
  return Object.entries(filters).every(([key,value])=>{
    if(!value||value==='all')return true;
    if(key==='superior_id')return value==='none'?record['no_superior']===true:value==='pending'? !record['no_superior'] && !record['superior_id']:record['superior_id']===value;
    if(key==='company_id'||key==='department_id'||key==='active')return String(record[key])===value;
    if(key==='hourly_rate')return Number(record[key])===Number(value.replace(',','.'));
    if(key==='department_count')return Number(record[key])===Number(value);
    return String(record[key]??'').toLocaleLowerCase().includes(value.toLocaleLowerCase());
  });
}