export const demoData = {
 connections: [],
 companies: [
 {id:'demo-1',name:'Artvisão Indústria e Comércio LTDA',cnpj:'12345678000190',owner_id:'demo',created_at:''},
 {id:'demo-2',name:'Metalúrgica Vale do Aço S.A.',cnpj:'98765432000110',owner_id:'demo',created_at:''},
 {id:'demo-3',name:'Indústrias Reunidas Norte',cnpj:'55444333000122',owner_id:'demo',created_at:''}],
 departments:[{id:'dd-1',name:'Financeiro',company_id:'demo-1',active:true,owner_id:'demo',created_at:''},{id:'dd-2',name:'Recursos Humanos',company_id:'demo-1',active:true,owner_id:'demo',created_at:''},{id:'dd-3',name:'Operações',company_id:'demo-2',active:true,owner_id:'demo',created_at:''}],
 jobs:[{id:'dj-1',name:'Supervisor',company_id:'demo-1',department_id:'dd-1',cbo:'4101-05',hourly_rate:95,superior_id:null,no_superior:true,details:{summary:'Supervisão da equipe e planejamento das atividades.'},attachments:[],position_x:260,position_y:40,owner_id:'demo',created_at:''},{id:'dj-2',name:'Empacotador 1',company_id:'demo-1',department_id:'dd-1',cbo:'7841-05',hourly_rate:35,superior_id:'dj-1',no_superior:false,details:{summary:'Preparação e embalagem de produtos.'},attachments:[],position_x:60,position_y:280,owner_id:'demo',created_at:''},{id:'dj-3',name:'Empacotador 2',company_id:'demo-1',department_id:'dd-1',cbo:'7841-05',hourly_rate:18.5,superior_id:'dj-1',no_superior:false,details:{summary:'Preparação e embalagem de produtos.'},attachments:[],position_x:440,position_y:280,owner_id:'demo',created_at:''}]
};