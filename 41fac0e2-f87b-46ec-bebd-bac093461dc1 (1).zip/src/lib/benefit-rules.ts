import { z } from 'zod';

export const benefitTargets = ['colaborador', 'dependente'] as const;
export type BenefitTarget = (typeof benefitTargets)[number];
export const targetLabels: Record<BenefitTarget, string> = { colaborador: 'Colaborador', dependente: 'Dependente' };

export const benefitSchema = z.object({
  id: z.string().uuid().optional(),
  company_id: z.string().uuid({ message: 'Selecione a empresa' }),
  name: z.string().trim().min(1, 'Informe o nome do benefício').max(200),
  target: z.enum(benefitTargets, { message: 'Escolha se é para colaborador ou dependente' }),
  notes: z.string().max(4000).default(''),
});

type Person = { id: string; company_id: string };
/** Pessoas que podem ser marcadas no benefício: mesma empresa e do tipo escolhido. */
export function eligiblePeople<E extends Person, D extends Person>(b: { company_id: string; target: BenefitTarget }, employees: E[], dependents: D[]): (E | D)[] {
  return (b.target === 'colaborador' ? employees : dependents).filter(p => p.company_id === b.company_id);
}
