import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { calendarSaveSchema, datesBetween, isoDate } from './calendar-rules';

export const getCalendar = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator(z.object({ company_id: z.string().uuid(), year: z.number().int().min(1900).max(2200) }))
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await context.supabase.from('company_calendar_days').select('day,kind,title')
      .eq('company_id', data.company_id).gte('day', `${data.year}-01-01`).lte('day', `${data.year}-12-31`);
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const saveCalendarDays = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator(calendarSaveSchema).handler(async ({ data, context }) => {
    const days = datesBetween(data.start, data.end);
    if (days.length > 366) throw new Error('Selecione no máximo 1 ano');
    if (data.reset) {
      const { error } = await context.supabase.from('company_calendar_days').delete().eq('company_id', data.company_id).gte('day', data.start).lte('day', data.end);
      if (error) throw new Error(error.message);
      return { ok: true };
    }
    const { error } = await context.supabase.from('company_calendar_days').upsert(
      days.map(day => ({ company_id: data.company_id, owner_id: context.userId, day, kind: data.kind, title: data.title })),
      { onConflict: 'company_id,day,owner_id' });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
export { isoDate };
