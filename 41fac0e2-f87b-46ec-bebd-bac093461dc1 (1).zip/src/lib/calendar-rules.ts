import { z } from 'zod';

export const dayKinds = ['trabalhado', 'obrigatorio', 'facultativo', 'recesso', 'folga'] as const;
export type DayKind = (typeof dayKinds)[number];
export const kindLabels: Record<DayKind, string> = {
  trabalhado: 'Dia trabalhado', obrigatorio: 'Feriado obrigatório', facultativo: 'Feriado facultativo', recesso: 'Recesso coletivo', folga: 'Folga / descanso',
};
export const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
export const calendarSaveSchema = z.object({
  company_id: z.string().uuid(), start: isoDate, end: isoDate, kind: z.enum(dayKinds), title: z.string().trim().max(150), reset: z.boolean().default(false),
}).refine(v => v.end >= v.start, { path: ['end'], message: 'Data final antes da inicial' });

const pad = (n: number) => String(n).padStart(2, '0');
export const iso = (y: number, m: number, d: number) => `${y}-${pad(m)}-${pad(d)}`;
function easter(y: number) {
  const a = y % 19, b = Math.floor(y / 100), c = y % 100, d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30, i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451);
  return new Date(Date.UTC(y, Math.floor((h + l - 7 * m + 114) / 31) - 1, ((h + l - 7 * m + 114) % 31) + 1));
}
const shift = (d: Date, days: number) => { const x = new Date(d); x.setUTCDate(x.getUTCDate() + days); return x.toISOString().slice(0, 10); };

/** Feriados nacionais do Brasil (obrigatórios) e pontos facultativos móveis. */
export function nationalHolidays(y: number): Record<string, { kind: DayKind; title: string }> {
  const e = easter(y);
  const fixed: [number, number, string][] = [[1, 1, 'Confraternização Universal'], [4, 21, 'Tiradentes'], [5, 1, 'Dia do Trabalho'], [9, 7, 'Independência do Brasil'], [10, 12, 'Nossa Senhora Aparecida'], [11, 2, 'Finados'], [11, 15, 'Proclamação da República'], [11, 20, 'Dia da Consciência Negra'], [12, 25, 'Natal']];
  const out: Record<string, { kind: DayKind; title: string }> = {};
  for (const [m, d, t] of fixed) out[iso(y, m, d)] = { kind: 'obrigatorio', title: t };
  out[shift(e, -2)] = { kind: 'obrigatorio', title: 'Sexta-feira Santa' };
  out[shift(e, -48)] = { kind: 'facultativo', title: 'Carnaval' };
  out[shift(e, -47)] = { kind: 'facultativo', title: 'Carnaval' };
  out[shift(e, 60)] = { kind: 'facultativo', title: 'Corpus Christi' };
  return out;
}

/** Classificação final: dia salvo prevalece; depois feriado nacional; fim de semana = folga; demais = trabalhado. */
export function resolveDay(date: string, saved?: { kind: string; title: string }) {
  if (saved) return { kind: saved.kind as DayKind, title: saved.title, custom: true };
  const h = nationalHolidays(Number(date.slice(0, 4)))[date];
  if (h) return { ...h, custom: false };
  const wd = new Date(`${date}T12:00:00Z`).getUTCDay();
  return { kind: (wd === 0 || wd === 6 ? 'folga' : 'trabalhado') as DayKind, title: '', custom: false };
}

export function datesBetween(start: string, end: string) {
  const out: string[] = []; let d = new Date(`${start}T12:00:00Z`);
  const last = new Date(`${end}T12:00:00Z`);
  while (d <= last && out.length <= 366) { out.push(d.toISOString().slice(0, 10)); d = new Date(d.getTime() + 86400000); }
  return out;
}
