import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { employeeSchema, dependentSchema } from './people-schema';
import type { Json } from '@/integrations/supabase/types';
import { employeeMovementStatus } from './movement-rules';
import { todayLocal } from './document-rules';

export const getPeople = createServerFn({method:'GET'}).middleware([requireSupabaseAuth]).handler(async({context})=>{
  const [e,d,v,m]=await Promise.all([context.supabase.from('employees').select('*').order('created_at'),context.supabase.from('dependents').select('*').order('created_at'),context.supabase.from('vacation_requests').select('employee_id').eq('state','aprovada').eq('finished',false).lte('start_date',todayLocal()).gte('end_date',todayLocal()),context.supabase.from('employee_movements').select('employee_id,kind,start_date,end_date,return_date,has_notice,notice_start,notice_end').lte('start_date','9999-12-31')]);
  if(e.error||d.error) throw new Error(e.error?.message||d.error?.message);
  return {employees:e.data??[],dependents:d.data??[],onVacation:[...new Set((v.data??[]).map(x=>x.employee_id))],movementStatus:employeeMovementStatus(m.data??[],todayLocal())};
});
export const saveEmployee = createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(z.object({id:z.string().uuid(),value:employeeSchema})).handler(async({data,context})=>{
  const {company_id,job_id,personal,finance,documents}=data.value;
  for(const doc of Object.values(documents)) if(doc.path && !doc.path.startsWith(`${context.userId}/`)) throw new Error('Documento inválido');
  const {data:job,error:jobError}=await context.supabase.from('jobs').select('id').eq('id',job_id).eq('company_id',company_id).single();
  if(jobError||!job) throw new Error('Selecione um cargo da empresa');
  const {error}=await context.supabase.from('employees').upsert({id:data.id,owner_id:context.userId,company_id,job_id,personal:personal as unknown as Json,finance,documents});
  if(error) throw new Error(error.message); return {id:data.id};
});
export const saveDependent = createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(z.object({id:z.string().uuid().optional(),employee_id:z.string().uuid(),value:dependentSchema})).handler(async({data,context})=>{
  const {data:employee,error:e}=await context.supabase.from('employees').select('company_id').eq('id',data.employee_id).single();
  if(e||!employee) throw new Error('Colaborador não encontrado');
  for(const doc of Object.values(data.value.documents)) if(doc.path && !doc.path.startsWith(`${context.userId}/`)) throw new Error('Documento inválido');
  const {data:row,error}=await context.supabase.from('dependents').upsert({...data.value,...(data.id?{id:data.id}:{}),employee_id:data.employee_id,company_id:employee.company_id,owner_id:context.userId}).select('id').single();
  if(error) throw new Error(error.message);return row;
});
export const deletePerson = createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(z.object({kind:z.enum(['employees','dependents']),id:z.string().uuid()})).handler(async({data,context})=>{
  const {error}=await context.supabase.from(data.kind).delete().eq('id',data.id);if(error)throw new Error(error.message);return {ok:true};
});