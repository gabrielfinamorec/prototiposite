import { z } from 'zod';

export const vacationStatuses = ['Pendente', 'Aprovada', 'Confirmada', 'Aviso', 'Finalizada', 'Cancelada'] as const;
export type VacationStatus = (typeof vacationStatuses)[number];
export const vacationActions = ['aprovar', 'cancelar', 'reabrir', 'finalizar', 'desfazer'] as const;
export type VacationAction = (typeof vacationActions)[number];

const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Informe uma data válida');
export const vacationSchema = z.object({
  id: z.string().uuid().optional(),
  employee_id: z.string().uuid('Selecione um colaborador'),
  start_date: isoDate, end_date: isoDate,
  notes: z.string().trim().max(2000).default(''),
}).refine(v => v.end_date >= v.start_date, { path: ['end_date'], message: 'O final deve ser depois do início' })
  .refine(v => vacationDays(v.start_date, v.end_date) <= 365, { path: ['end_date'], message: 'Período máximo de 1 ano' });

/** Número de dias corridos, contando o primeiro e o último dia. */
export function vacationDays(start: string, end: string) {
  return Math.round((Date.parse(`${end}T12:00:00Z`) - Date.parse(`${start}T12:00:00Z`)) / 86400000) + 1;
}

/** Status exibido: aprovada vira Confirmada no período, Aviso ao terminar e Finalizada depois de reconhecida. */
export function vacationStatus(v: { state: string; start_date: string; end_date: string; finished: boolean }, today: string): VacationStatus {
  if (v.state === 'cancelada') return 'Cancelada';
  if (v.state === 'pendente') return 'Pendente';
  if (v.finished) return 'Finalizada';
  if (today < v.start_date) return 'Aprovada';
  if (today <= v.end_date) return 'Confirmada';
  return 'Aviso';
}

/** Ações permitidas por status. */
export function allowedActions(status: VacationStatus): VacationAction[] {
  switch (status) {
    case 'Pendente': return ['aprovar', 'cancelar'];
    case 'Aprovada': return ['cancelar', 'desfazer'];
    case 'Confirmada': return ['desfazer'];
    case 'Cancelada': return ['reabrir'];
    case 'Aviso': return ['finalizar'];
    default: return [];
  }
}

export const overlaps = (a: { start_date: string; end_date: string }, b: { start_date: string; end_date: string }) => a.start_date <= b.end_date && b.start_date <= a.end_date;

export const statusClass: Record<VacationStatus, string> = {
  Pendente: 'pending', Aprovada: 'approved', Confirmada: 'positive', Aviso: 'warning', Finalizada: 'finished', Cancelada: 'inactive',
};
