import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { mealDay, mealImageSchema, manualMealSchema, visitorMealSchema, mealServedAt } from './meal-rules';
import type { SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '@/integrations/supabase/types';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';

const nameOf = (p: unknown) => (p && typeof p === 'object' && 'name' in p ? String((p as { name: unknown }).name) : '');

export const getMeals = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const [e, f, m] = await Promise.all([
    context.supabase.from('employees').select('id,company_id,job_id,personal'),
    context.supabase.from('employee_faces').select('employee_id,photo_path,updated_at'),
    context.supabase.from('meal_entries').select('*').order('served_at', { ascending: false }).limit(5000),
  ]);
  if (e.error || f.error || m.error) throw new Error(e.error?.message || f.error?.message || m.error?.message);
  return {
    employees: (e.data ?? []).map(x => ({ id: x.id, company_id: x.company_id, job_id: x.job_id, name: nameOf(x.personal) })).sort((a, b) => a.name.localeCompare(b.name)),
    faces: f.data ?? [],
    meals: m.data ?? [],
  };
});

export const saveFace = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator(z.object({ employee_id: z.string().uuid(), photo_path: z.string().min(5).max(300) }))
  .handler(async ({ data, context }) => {
    if (!data.photo_path.startsWith(`${context.userId}/`)) throw new Error('Foto inválida');
    const { data: emp } = await context.supabase.from('employees').select('company_id').eq('id', data.employee_id).maybeSingle();
    if (!emp) throw new Error('Colaborador não encontrado');
    const { error } = await context.supabase.from('employee_faces').upsert({ employee_id: data.employee_id, company_id: emp.company_id, owner_id: context.userId, photo_path: data.photo_path, updated_at: new Date().toISOString() });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteFace = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator(z.object({ employee_id: z.string().uuid() }))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from('employee_faces').delete().eq('employee_id', data.employee_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteMeal = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator(z.object({ id: z.string().uuid() }))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from('meal_entries').delete().eq('id', data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Lista para o totem: só nomes e se possui facial — sem dados sensíveis. */
export const getTotemPeople = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const [e, f, c] = await Promise.all([
    context.supabase.from('employees').select('id,company_id,personal'),
    context.supabase.from('employee_faces').select('employee_id'),
    context.supabase.from('companies').select('id,name').order('name'),
  ]);
  if (e.error || f.error || c.error) throw new Error('Não foi possível carregar a lista');
  const withFace = new Set((f.data ?? []).map(x => x.employee_id));
  return {
    companies: c.data ?? [],
    people: (e.data ?? []).map(x => ({ id: x.id, company_id: x.company_id, name: nameOf(x.personal), hasFace: withFace.has(x.id) })).sort((a, b) => a.name.localeCompare(b.name)),
  };
});

export const validateMeal = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator(z.object({ employee_id: z.string().uuid(), image: mealImageSchema }))
  .handler(async ({ data, context }) => {
    const today = mealDay();
    const { data: face } = await context.supabase.from('employee_faces').select('photo_path,company_id').eq('employee_id', data.employee_id).maybeSingle();
    if (!face) return { status: 'sem_facial' as const, time: null };
    const { data: already, error: checkError } = await context.supabase.from('meal_entries').select('served_at').eq('employee_id', data.employee_id).eq('meal_date', today).order('served_at').limit(1).maybeSingle();
    if (checkError) throw new Error(checkError.message);
    if (already) return { status: 'duplicado' as const, time: already.served_at };
    const { data: blob, error } = await context.supabase.storage.from('people-documents').download(face.photo_path);
    if (error || !blob) return { status: 'erro' as const, time: null, message: 'Foto de cadastro indisponível.' };
    const { compareFaces } = await import('./ai/face.server');
    const base64 = data.image.replace(/^data:image\/\w+;base64,/, '');
    const result = await compareFaces(new Uint8Array(await blob.arrayBuffer()), blob.type || 'image/jpeg', base64);
    if (result.error) return { status: 'erro' as const, time: null, message: result.error };
    if (!result.match) return { status: 'nao_reconhecido' as const, time: null };
    const photo_path = await storeMealPhoto(context.supabase, context.userId, data.image);
    const served_at = new Date().toISOString();
    const { data: ins, error: insErr } = await context.supabase.from('meal_entries').insert({ employee_id: data.employee_id, company_id: face.company_id, owner_id: context.userId, meal_date: mealDay(new Date(served_at)), served_at, source: 'facial', photo_path }).select('served_at').single();
    if (insErr) await context.supabase.storage.from('people-documents').remove([photo_path]);
    if (insErr) return insErr.code === '23505' ? { status: 'duplicado' as const, time: null } : { status: 'erro' as const, time: null, message: 'Não foi possível registrar.' };
    return { status: 'liberado' as const, time: ins.served_at };
  });


async function storeMealPhoto(client: SupabaseClient<Database>, owner: string, image: string) {
  const raw = atob(image.split(',')[1] ?? '');
  const bytes = Uint8Array.from(raw, c => c.charCodeAt(0));
  const png = image.startsWith('data:image/png;');
  const valid = png ? [137,80,78,71,13,10,26,10].every((b,i) => bytes[i] === b) : bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
  if (!valid || bytes.length > 5 * 1024 * 1024) throw new Error('Foto inválida. Use PNG ou JPEG de até 5 MB.');
  const path = `${owner}/meals/${crypto.randomUUID()}.${png ? 'png' : 'jpg'}`;
  const { error } = await client.storage.from('people-documents').upload(path, bytes, { contentType: png ? 'image/png' : 'image/jpeg' });
  if (error) throw new Error('Não foi possível guardar a foto. Tente novamente.');
  return path;
}

export const saveManualMeal = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator(manualMealSchema).handler(async ({ data, context }) => {
    const { data: company } = await context.supabase.from('companies').select('id').eq('id', data.company_id).maybeSingle();
    if (!company) throw new Error('Empresa não encontrada');
    if (data.employee_id) {
      const { data: emp } = await context.supabase.from('employees').select('id').eq('id', data.employee_id).eq('company_id', data.company_id).maybeSingle();
      if (!emp) throw new Error('Colaborador não pertence à empresa');
    }
    const photo_path = await storeMealPhoto(context.supabase, context.userId, data.image);
    const { error } = await context.supabase.from('meal_entries').insert({ owner_id: context.userId, company_id: data.company_id, employee_id: data.employee_id ?? null, visitor_name: data.visitor_name ?? null, meal_date: data.meal_date, served_at: mealServedAt(data.meal_date, data.time), source: 'manual', photo_path });
    if (error) { await context.supabase.storage.from('people-documents').remove([photo_path]); throw new Error('Não foi possível registrar o almoço'); }
    return { ok: true };
  });

export const saveVisitorMeal = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator(visitorMealSchema).handler(async ({ data, context }) => {
    const { data: company } = await context.supabase.from('companies').select('id').eq('id', data.company_id).maybeSingle();
    if (!company) throw new Error('Selecione a empresa');
    const photo_path = await storeMealPhoto(context.supabase, context.userId, data.image);
    const served_at = new Date().toISOString();
    const { error } = await context.supabase.from('meal_entries').insert({ owner_id: context.userId, company_id: data.company_id, visitor_name: data.visitor_name, meal_date: mealDay(new Date(served_at)), served_at, source: 'visita', photo_path });
    if (error) { await context.supabase.storage.from('people-documents').remove([photo_path]); throw new Error('Não foi possível registrar o almoço'); }
    return { status: 'liberado' as const, time: served_at };
  });
