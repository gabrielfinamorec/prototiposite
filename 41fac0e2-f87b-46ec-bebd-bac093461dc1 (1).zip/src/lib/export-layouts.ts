import { useEffect, useState } from 'react';
import { z } from 'zod';
import { detailLabels } from './finance-schema';
export type ExportKind='companies'|'departments'|'jobs';
export const exportFields:Record<ExportKind,string[]>={companies:['Nome','CNPJ'],departments:['Nome','Empresa','Ativo'],jobs:['Nome do cargo','Empresa','Departamento','CBO','Valor da hora','Superior direto',...Object.values(detailLabels),'Arquivos anexos']};
export const layoutSchema=z.object({title:z.string().max(150),subtitle:z.string().max(200),orientation:z.enum(['portrait','landscape']),font:z.enum(['helvetica','times','courier']),fontSize:z.number().min(8).max(16),margin:z.number().min(10).max(30),accent:z.enum(['red','blue','gray']),pageNumbers:z.boolean(),fields:z.array(z.string()),delimiter:z.enum([';',',','\t']),headers:z.boolean()});
export type ExportLayout=z.infer<typeof layoutSchema>;
export type ExportLayouts=Record<ExportKind,ExportLayout>;
export const defaultLayouts=():ExportLayouts=>Object.fromEntries(Object.entries(exportFields).map(([kind,fields])=>[kind,{title:'Fincore',subtitle:'Gestão de pessoas & organização',orientation:'portrait',font:'helvetica',fontSize:10,margin:18,accent:'red',pageNumbers:true,fields:[...fields],delimiter:';',headers:true}])) as ExportLayouts;
export function encodeCsv(rows:Record<string,string>[],layout:ExportLayout) {
  const values=rows.map(row=>layout.fields.map(field=>row[field]??''));
  if(layout.headers)values.unshift(layout.fields);
  return '\uFEFF'+values.map(row=>row.map(value=>'"'+value.replace(/"/g,'""')+'"').join(layout.delimiter)).join('\r\n');
}
export function useExportLayouts(owner?:string) {
  const [layouts,setLayouts]=useState(defaultLayouts);
  const key=`fincore-export-layouts:${owner??'sample'}`;
  useEffect(()=>{
    const load=()=>{try{const raw=JSON.parse(localStorage.getItem(key)??'null');const defaults=defaultLayouts();for(const kind of Object.keys(defaults) as ExportKind[]){const parsed=layoutSchema.safeParse(raw?.[kind]);if(parsed.success)defaults[kind]={...parsed.data,fields:parsed.data.fields.filter(field=>exportFields[kind].includes(field))};}setLayouts(defaults);}catch{setLayouts(defaultLayouts());}};
    load();window.addEventListener('fincore-layouts',load);window.addEventListener('storage',load);
    return()=>{window.removeEventListener('fincore-layouts',load);window.removeEventListener('storage',load);};
  },[key]);
  const save=(value:ExportLayouts)=>{localStorage.setItem(key,JSON.stringify(value));setLayouts(value);window.dispatchEvent(new Event('fincore-layouts'));};
  return {layouts,save};
}