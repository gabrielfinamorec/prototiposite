import { jsPDF } from 'jspdf';
import { detailLabels, money, superiorLabel } from './finance-schema';
import { defaultLayouts, type ExportLayout } from './export-layouts';
type PdfJob = {name:string;company_id:string;department_id:string;cbo:string;hourly_rate:number;superior_id:string|null;no_superior?:boolean;details:unknown;attachments:string[]};
type PdfData = {companies:{id:string;name:string}[];departments:{id:string;name:string}[];jobs:{id:string;name:string}[]};
export function jobInformation(job:PdfJob,data:PdfData):[string,string][] {
  return [['Nome do cargo',job.name],['Empresa',data.companies.find(c=>c.id===job.company_id)?.name??'—'],['Departamento',data.departments.find(d=>d.id===job.department_id)?.name??'—'],['CBO',job.cbo],['Valor da hora',money(job.hourly_rate)],['Superior direto',superiorLabel(job,data.jobs)],...Object.entries(detailLabels).map(([k,label]):[string,string]=>[label,String((job.details as Record<string,string>)[k]??'Não informado')]),['Arquivos anexos',job.attachments.map(p=>p.split('/').at(-1)).join('\n')||'Nenhum anexo']];
}
export function createJobPdf(jobs:PdfJob[],data:PdfData,layout:ExportLayout=defaultLayouts().jobs) {
  const pdf=new jsPDF({unit:'mm',format:'a4',orientation:layout.orientation});
  const width=pdf.internal.pageSize.getWidth(),height=pdf.internal.pageSize.getHeight();
  const left=layout.margin,bottom=height-layout.margin-8,lineHeight=layout.fontSize*.5;
  let y=layout.margin;
  const page=()=>{pdf.addPage();y=layout.margin;};
  jobs.forEach((job,index)=>{
    if(index)page();
    pdf.setFont(layout.font,'bold');pdf.setFontSize(layout.fontSize+6);
    const accent=layout.accent==='red'?[166,37,46]:layout.accent==='blue'?[32,100,160]:[55,55,55];
    pdf.setTextColor(accent[0]??0,accent[1]??0,accent[2]??0);
    const title=pdf.splitTextToSize(layout.title,width-left*2) as string[];
    pdf.text(title,left,y);y+=title.length*8;
    pdf.setTextColor(45);pdf.setFont(layout.font,'normal');pdf.setFontSize(layout.fontSize);
    const subtitle=pdf.splitTextToSize(layout.subtitle,width-left*2) as string[];
    pdf.text(subtitle,left,y);y+=subtitle.length*lineHeight+10;
    const values=new Map(jobInformation(job,data));
    for(const label of layout.fields){
      const value=values.get(label);if(value===undefined)continue;
      pdf.setFont(layout.font,'normal');pdf.setFontSize(layout.fontSize);
      const lines=pdf.splitTextToSize(value,width-left*2) as string[];
      if(y+Math.min(lines.length,4)*lineHeight+12>bottom)page();
      pdf.setFont(layout.font,'bold');pdf.text(label,left,y);y+=lineHeight+1;
      pdf.setFont(layout.font,'normal');
      for(const line of lines){if(y>bottom)page();pdf.text(line,left,y);y+=lineHeight;}
      y+=6;
    }
  });
  const total=pdf.getNumberOfPages();
  if(layout.pageNumbers)for(let i=1;i<=total;i++){pdf.setPage(i);pdf.setFont(layout.font,'normal');pdf.setFontSize(8);pdf.text(`${i} / ${total}`,width-left,height-10,{align:'right'});}
  return pdf.output('blob');
}