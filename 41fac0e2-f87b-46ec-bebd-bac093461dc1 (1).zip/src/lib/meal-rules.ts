import { z } from 'zod';

export const mealDay = (date = new Date()) => new Date(date.getTime() - 3 * 3600_000).toISOString().slice(0, 10);
export const mealImageSchema = z.string().max(7_000_000).regex(/^data:image\/(jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/, 'Envie uma foto PNG ou JPEG').refine(v => v.length >= 100, 'Foto inválida');
export const manualMealSchema = z.object({
  company_id: z.string().uuid(),
  employee_id: z.string().uuid().optional(),
  visitor_name: z.string().trim().min(1).max(150).optional(),
  meal_date: z.string().date(),
  time: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Horário inválido'),
  image: mealImageSchema,
}).superRefine((v, ctx) => {
  if (!!v.employee_id === !!v.visitor_name) ctx.addIssue({ code: 'custom', message: 'Escolha um colaborador ou informe o nome da visita' });
});
export const visitorMealSchema = z.object({ company_id: z.string().uuid(), visitor_name: z.string().trim().min(1, 'Informe seu nome').max(150), image: mealImageSchema });
export const mealServedAt = (day: string, time: string) => new Date(`${day}T${time}:00-03:00`).toISOString();
export type MealRecord = { id: string; company_id: string; employee_id: string | null; visitor_name?: string | null; meal_date: string; created_at: string; served_at?: string; source?: string; photo_path?: string | null };