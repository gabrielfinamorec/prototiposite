import { connectionSide } from './finance-schema';
export function visualEdges(connections:{id:string;company_id:string;source_id:string;target_id:string;source_handle?:string;target_handle?:string}[],company:string|undefined) {
  return connections.filter(e=>e.company_id===company).map(e=>({id:e.id,source:e.source_id,target:e.target_id,sourceHandle:connectionSide.catch('right').parse(e.source_handle),targetHandle:connectionSide.catch('left').parse(e.target_handle)}));
}