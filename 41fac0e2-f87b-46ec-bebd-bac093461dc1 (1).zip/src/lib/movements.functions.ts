import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { movementKinds, movementSchema, movementTypeSchema } from './movement-rules';

const nameOf = (p: unknown) => (p && typeof p === 'object' && 'name' in p ? String((p as { name: unknown }).name) : '');

export const getMovementTypes = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const { data, error } = await context.supabase.from('movement_types').select('id,kind,name,description,initiative,requires_document,active').order('name');
  if (error) throw new Error(error.message);
  return data ?? [];
});

export const saveMovementType = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).inputValidator(movementTypeSchema).handler(async ({ data, context }) => {
  const { id, ...row } = data;
  const q = id ? context.supabase.from('movement_types').update(row).eq('id', id) : context.supabase.from('movement_types').insert({ ...row, owner_id: context.userId });
  const { error } = await q;
  if (error) throw new Error(error.message);
  return { ok: true };
});

export const deleteMovementType = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).inputValidator(z.object({ id: z.string().uuid() })).handler(async ({ data, context }) => {
  const { error } = await context.supabase.from('movement_types').delete().eq('id', data.id);
  if (error) throw new Error(error.code === '23503' ? 'Este tipo já foi usado em registros. Deixe-o inativo em vez de excluir.' : error.message);
  return { ok: true };
});

export const getMovements = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).inputValidator(z.object({ kind: z.enum(movementKinds) })).handler(async ({ data, context }) => {
  const [m, e] = await Promise.all([
    context.supabase.from('employee_movements').select('*').eq('kind', data.kind).order('start_date', { ascending: false }),
    context.supabase.from('employees').select('id,company_id,job_id,personal'),
  ]);
  if (m.error || e.error) throw new Error(m.error?.message || e.error?.message);
  return { movements: m.data ?? [], employees: (e.data ?? []).map(x => ({ id: x.id, company_id: x.company_id, job_id: x.job_id, name: nameOf(x.personal) })) };
});

export const saveMovement = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).inputValidator(movementSchema).handler(async ({ data, context }) => {
  const [emp, type] = await Promise.all([
    context.supabase.from('employees').select('company_id').eq('id', data.employee_id).maybeSingle(),
    context.supabase.from('movement_types').select('kind,active,requires_document').eq('id', data.type_id).maybeSingle(),
  ]);
  if (!emp.data) throw new Error('Colaborador não encontrado');
  if (!type.data || type.data.kind !== data.kind) throw new Error('Tipo inválido');
  if (type.data.requires_document && !data.attachments.length) throw new Error('Este tipo exige anexar um documento');
  const { id, ...rest } = data;
  const row = { ...rest, company_id: emp.data.company_id, ...(data.has_notice ? {} : { notice_type: '' as const, notice_start: null, notice_end: null }) };
  if (!id) {
    if (!type.data.active) throw new Error('Este tipo está inativo');
    if (data.kind === 'demissao') {
      const { count } = await context.supabase.from('employee_movements').select('id', { count: 'exact', head: true }).eq('kind', 'demissao').eq('employee_id', data.employee_id);
      if (count) throw new Error('Este colaborador já tem uma demissão registrada');
    }
  }
  const { error } = id ? await context.supabase.from('employee_movements').update(row).eq('id', id) : await context.supabase.from('employee_movements').insert({ ...row, owner_id: context.userId });
  if (error) throw new Error(error.message);
  return { ok: true };
});

export const deleteMovement = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).inputValidator(z.object({ id: z.string().uuid() })).handler(async ({ data, context }) => {
  const { error } = await context.supabase.from('employee_movements').delete().eq('id', data.id);
  if (error) throw new Error(error.message);
  return { ok: true };
});
