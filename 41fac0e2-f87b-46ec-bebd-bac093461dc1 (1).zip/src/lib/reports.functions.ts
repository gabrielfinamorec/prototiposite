import { createServerFn } from '@tanstack/react-start';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';

export const getConsultData = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const s = context.supabase;
  const r = await Promise.all([
    s.from('employees').select('id,company_id,job_id,personal'),
    s.from('dependents').select('id,company_id,employee_id,name,degree,birth_date,active'),
    s.from('vacation_requests').select('id,company_id,employee_id,start_date,end_date,state,finished'),
    s.from('employee_movements').select('id,kind,company_id,employee_id,type_id,start_date,end_date,return_date,has_notice,notice_type,notice_start,notice_end'),
    s.from('movement_types').select('id,name'),
    s.from('controlled_documents').select('id,company_id,employee_id,type_id,state,issue_date,expiry_date'),
    s.from('document_types').select('id,name'),
    s.from('benefits').select('id,company_id,name,target,member_ids'),
    s.from('meal_entries').select('id,company_id,employee_id,visitor_name,meal_date,created_at,served_at,source,photo_path').order('meal_date', { ascending: false }).order('served_at', { ascending: false }),
  ]);
  const err = r.find(x => x.error)?.error;
  if (err) throw new Error(err.message);
  const [employees, dependents, vacations, movements, movementTypes, documents, documentTypes, benefits, meals] = r.map(x => x.data ?? []);
  return {
    employees: (employees as { id: string; company_id: string; job_id: string; personal: unknown }[]).map(e => {
      const p = (e.personal ?? {}) as Record<string, unknown>;
      return { id: e.id, company_id: e.company_id, job_id: e.job_id, name: String(p['name'] ?? ''), registration: String(p['registration'] ?? ''), birth_date: String(p['birth_date'] ?? ''), admission_date: String(p['admission_date'] ?? ''), sex: String(p['sex'] ?? '') };
    }),
    dependents: dependents as { id: string; company_id: string; employee_id: string; name: string; degree: string; birth_date: string; active: boolean }[],
    vacations: vacations as { id: string; company_id: string; employee_id: string; start_date: string; end_date: string; state: string; finished: boolean }[],
    movements: movements as { id: string; kind: string; company_id: string; employee_id: string; type_id: string; start_date: string; end_date: string | null; return_date: string | null; has_notice: boolean; notice_type: string; notice_start: string | null; notice_end: string | null }[],
    movementTypes: movementTypes as { id: string; name: string }[],
    documents: documents as { id: string; company_id: string; employee_id: string; type_id: string; state: string; issue_date: string | null; expiry_date: string | null }[],
    documentTypes: documentTypes as { id: string; name: string }[],
    benefits: benefits as { id: string; company_id: string; name: string; target: string; member_ids: string[] }[],
    meals: meals as import('./meal-rules').MealRecord[],
  };
});
