import { jsPDF } from 'jspdf';
import { daysBetween, employeeMovementStatus, movementStatus, type MovementKind } from './movement-rules';
import { vacationStatus } from './vacation-rules';
import { documentStatus } from './document-rules';
import type { MealRecord } from './meal-rules';

export const br = (d: string | null | undefined) => (d ? d.split('-').reverse().join('/') : '—');

/** Próximo aniversário (data ISO) a partir de hoje, e quantos dias faltam. */
export function nextBirthday(birth: string, today: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(birth)) return null;
  const y = Number(today.slice(0, 4)), md = birth.slice(5);
  const safe = (yy: number) => (md === '02-29' && !(yy % 4 === 0 && (yy % 100 !== 0 || yy % 400 === 0)) ? `${yy}-02-28` : `${yy}-${md}`);
  let next = safe(y);
  if (next < today) next = safe(y + 1);
  const days = Math.round((Date.parse(`${next}T00:00:00Z`) - Date.parse(`${today}T00:00:00Z`)) / 86400000);
  return { date: next, days, age: Number(next.slice(0, 4)) - Number(birth.slice(0, 4)) };
}

export function addDays(iso: string, n: number) { const d = new Date(`${iso}T00:00:00Z`); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); }

export type ConsultData = {
  employees: { id: string; company_id: string; job_id: string; name: string; registration: string; birth_date: string; admission_date: string; sex: string }[];
  dependents: { id: string; company_id: string; employee_id: string; name: string; degree: string; birth_date: string; active: boolean }[];
  vacations: { id: string; company_id: string; employee_id: string; start_date: string; end_date: string; state: string; finished: boolean }[];
  movements: { id: string; kind: string; company_id: string; employee_id: string; type_id: string; start_date: string; end_date: string | null; return_date: string | null; has_notice: boolean; notice_type: string; notice_start: string | null; notice_end: string | null }[];
  movementTypes: { id: string; name: string }[];
  documents: { id: string; company_id: string; employee_id: string; type_id: string; state: string; issue_date: string | null; expiry_date: string | null }[];
  documentTypes: { id: string; name: string }[];
  benefits: { id: string; company_id: string; name: string; target: string; member_ids: string[] }[];
  meals: MealRecord[];
};
export type Org = { companies: { id: string; name: string }[]; departments: { id: string; name: string }[]; jobs: { id: string; name: string; department_id: string }[] };

/** Status do colaborador. Prioridade: Desligado > Em aviso prévio > Afastado > Em férias > Ativo. */
export function employeeStatuses(d: ConsultData, today: string) {
  const mv = employeeMovementStatus(d.movements, today);
  const vac = new Set(d.vacations.filter(v => vacationStatus(v, today) === 'Confirmada').map(v => v.employee_id));
  return Object.fromEntries(d.employees.map(e => [e.id, mv[e.id] ?? (vac.has(e.id) ? 'Em férias' : 'Ativo')])) as Record<string, string>;
}

export const reportKinds = { colaboradores: 'Colaboradores', atestados: 'Atestados', afastamentos: 'Afastamentos', avisos: 'Avisos prévios', demissoes: 'Demissões', ferias: 'Férias', documentos: 'Documentos', beneficios: 'Benefícios', aniversarios: 'Aniversários', almocos: 'Almoços' } as const;
export type ReportKind = keyof typeof reportKinds;
export type Report = { columns: string[]; rows: { company_id: string; date: string; cells: string[] }[] };

export function buildReport(kind: ReportKind, d: ConsultData, org: Org, today: string): Report {
  const emp = (id: string) => d.employees.find(e => e.id === id);
  const job = (id?: string) => org.jobs.find(j => j.id === id);
  const dept = (id?: string) => org.departments.find(x => x.id === id)?.name ?? '—';
  const co = (id: string) => org.companies.find(c => c.id === id)?.name ?? '—';
  const st = employeeStatuses(d, today);
  const who = (id: string) => { const e = emp(id); const j = job(e?.job_id); return [e?.name ?? '—', dept(j?.department_id), j?.name ?? '—']; };
  switch (kind) {
    case 'colaboradores': return { columns: ['Nome', 'Matrícula', 'Empresa', 'Departamento', 'Cargo', 'Admissão', 'Status'], rows: d.employees.map(e => { const j = job(e.job_id); return { company_id: e.company_id, date: e.admission_date, cells: [e.name, e.registration || '—', co(e.company_id), dept(j?.department_id), j?.name ?? '—', br(e.admission_date), st[e.id] ?? 'Ativo'] }; }) };
    case 'atestados': return { columns: ['Colaborador', 'Departamento', 'Cargo', 'Tipo de atestado', 'Início', 'Final', 'Dias', 'Situação'], rows: d.movements.filter(m => m.kind === 'atestado').map(m => ({ company_id: m.company_id, date: m.start_date, cells: [...who(m.employee_id), d.movementTypes.find(t => t.id === m.type_id)?.name ?? '—', br(m.start_date), br(m.end_date), String(daysBetween(m.start_date, m.end_date)), movementStatus({ ...m, kind: m.kind as MovementKind }, today)] })) };
    case 'afastamentos': return { columns: ['Colaborador', 'Departamento', 'Cargo', 'Tipo de afastamento', 'Início', 'Final', 'Retorno', 'Situação'], rows: d.movements.filter(m => m.kind === 'afastamento').map(m => ({ company_id: m.company_id, date: m.start_date, cells: [...who(m.employee_id), d.movementTypes.find(t => t.id === m.type_id)?.name ?? '—', br(m.start_date), br(m.end_date), br(m.return_date), String(daysBetween(m.start_date, m.return_date ?? m.end_date)), movementStatus({ ...m, kind: m.kind as MovementKind }, today)] })) };
    case 'avisos': return { columns: ['Colaborador', 'Departamento', 'Cargo', 'Tipo do aviso', 'Início', 'Fim', 'Dias', 'Situação'], rows: d.movements.filter(m => m.has_notice && m.notice_start).map(m => ({ company_id: m.company_id, date: m.notice_start!, cells: [...who(m.employee_id), m.notice_type === 'indenizado' ? 'Indenizado' : m.notice_type === 'trabalhado' ? 'Trabalhado' : '—', br(m.notice_start), br(m.notice_end), String(daysBetween(m.notice_start!, m.notice_end)), today < m.notice_start! ? 'Agendado' : !m.notice_end || today <= m.notice_end ? 'Em andamento' : 'Encerrado'] })) };
    case 'demissoes': return { columns: ['Colaborador', 'Departamento', 'Cargo', 'Motivo', 'Data do desligamento', 'Aviso prévio', 'Situação'], rows: d.movements.filter(m => m.kind === 'demissao').map(m => ({ company_id: m.company_id, date: m.start_date, cells: [...who(m.employee_id), d.movementTypes.find(t => t.id === m.type_id)?.name ?? '—', br(m.start_date), m.has_notice ? `${m.notice_type === 'indenizado' ? 'Indenizado' : 'Trabalhado'} ${br(m.notice_start)} a ${br(m.notice_end)}` : 'Sem aviso', movementStatus({ ...m, kind: m.kind as MovementKind }, today)] })) };
    case 'ferias': return { columns: ['Colaborador', 'Departamento', 'Cargo', 'Início', 'Final', 'Status'], rows: d.vacations.map(v => ({ company_id: v.company_id, date: v.start_date, cells: [...who(v.employee_id), br(v.start_date), br(v.end_date), vacationStatus(v, today)] })) };
    case 'documentos': return { columns: ['Colaborador', 'Departamento', 'Cargo', 'Documento', 'Emissão', 'Validade', 'Status'], rows: d.documents.map(x => ({ company_id: x.company_id, date: x.issue_date ?? '', cells: [...who(x.employee_id), d.documentTypes.find(t => t.id === x.type_id)?.name ?? '—', br(x.issue_date), br(x.expiry_date), documentStatus(x, today)] })) };
    case 'beneficios': return { columns: ['Benefício', 'Empresa', 'Beneficiário', 'Tipo', 'Titular'], rows: d.benefits.flatMap(b => b.member_ids.map(id => { const dep = d.dependents.find(x => x.id === id); const e = dep ? emp(dep.employee_id) : emp(id); return { company_id: b.company_id, date: '', cells: [b.name, co(b.company_id), dep ? dep.name : e?.name ?? '—', dep ? `Dependente (${dep.degree})` : 'Colaborador', dep ? e?.name ?? '—' : '—'] }; })) };
    case 'aniversarios': return { columns: ['Nome', 'Tipo', 'Empresa', 'Nascimento', 'Próximo aniversário', 'Fará (anos)', 'Faltam (dias)'], rows: [...d.employees.map(e => ({ n: e.name, t: 'Colaborador', c: e.company_id, b: e.birth_date })), ...d.dependents.map(x => ({ n: x.name, t: `Dependente (${x.degree})`, c: x.company_id, b: x.birth_date }))]
      .map(p => ({ p, nb: nextBirthday(p.b, today) })).filter(x => x.nb).sort((a, b) => a.nb!.days - b.nb!.days)
      .map(({ p, nb }) => ({ company_id: p.c, date: nb!.date, cells: [p.n, p.t, co(p.c), br(p.b), br(nb!.date), String(nb!.age), String(nb!.days)] })) };
    case 'almocos': return { columns: ['Nome', 'Tipo', 'Cargo', 'Empresa', 'Data', 'Horário', 'Origem'], rows: d.meals.map(m => { const e = m.employee_id ? emp(m.employee_id) : undefined; return { company_id: m.company_id, date: m.meal_date, cells: [m.visitor_name ?? e?.name ?? '—', m.employee_id ? 'Colaborador' : 'Visita', job(e?.job_id)?.name ?? '—', co(m.company_id), br(m.meal_date), mealTime(m.served_at ?? m.created_at), m.source === 'manual' ? 'Manual' : m.source === 'visita' ? 'Tablet · visita' : 'Facial'] }; }) };
  }
}

/** Horário do almoço no horário de Brasília (UTC-3), a partir do created_at (ISO UTC). */
export function mealTime(iso: string) {
  const d = new Date(iso);
  return isNaN(d.getTime()) ? '—' : new Date(d.getTime() - 3 * 3600000).toISOString().slice(11, 16);
}

export function reportCsv(r: Report) {
  const esc = (v: string) => `"${v.replace(/"/g, '""')}"`;
  return new Blob(['\uFEFF' + [r.columns, ...r.rows.map(x => x.cells)].map(l => l.map(esc).join(';')).join('\r\n')], { type: 'text/csv;charset=utf-8' });
}

export function reportPdf(title: string, r: Report, subtitle: string) {
  const pdf = new jsPDF({ unit: 'mm', format: 'a4', orientation: 'landscape' });
  const W = pdf.internal.pageSize.getWidth(), H = pdf.internal.pageSize.getHeight(), m = 12, colW = (W - 2 * m) / r.columns.length;
  let y = m;
  const header = () => { pdf.setFont('helvetica', 'bold'); pdf.setFontSize(8); pdf.setFillColor(166, 37, 46); pdf.setTextColor(255); pdf.rect(m, y, W - 2 * m, 7, 'F'); r.columns.forEach((c, i) => pdf.text(c.toUpperCase(), m + 1.5 + i * colW, y + 4.7, { maxWidth: colW - 2 })); y += 9; pdf.setTextColor(30); pdf.setFont('helvetica', 'normal'); };
  pdf.setFont('helvetica', 'bold'); pdf.setFontSize(15); pdf.setTextColor(166, 37, 46); pdf.text(title, m, y + 5); y += 9;
  pdf.setFont('helvetica', 'normal'); pdf.setFontSize(9); pdf.setTextColor(90); pdf.text(subtitle, m, y + 2); y += 6;
  header();
  for (const row of r.rows) {
    const lines = row.cells.map(c => pdf.splitTextToSize(c, colW - 2) as string[]);
    const h = Math.max(...lines.map(l => l.length)) * 3.6 + 2;
    if (y + h > H - m) { pdf.addPage(); y = m; header(); }
    lines.forEach((l, i) => pdf.text(l, m + 1.5 + i * colW, y + 3));
    pdf.setDrawColor(225); pdf.line(m, y + h - 0.5, W - m, y + h - 0.5); y += h;
  }
  if (!r.rows.length) pdf.text('Nenhum registro.', m, y + 4);
  return pdf.output('blob');
}
