import { generateText } from 'ai';
import { createLovableAiGatewayProvider } from './gateway-helpers.server';

/** Compara a foto de referência com a foto capturada no totem. */
export async function compareFaces(reference: Uint8Array, refType: string, captured: string) {
  const key = process.env['LOVABLE_API_KEY'];
  if (!key) return { match: false, error: 'IA não configurada.' };
  const provider = createLovableAiGatewayProvider(key, undefined, { baseURL: 'https://ai.gateway.lovable.dev/v1' });
  try {
    const result = await generateText({
      model: provider('google/gemini-3.8-flash'), maxRetries: 1,
      system: 'Você verifica identidade facial para liberar refeições. Compare o rosto da FOTO 1 (cadastro) com o rosto da FOTO 2 (câmera agora). Responda somente SIM se for claramente a mesma pessoa real, ou NAO caso contrário, se não houver rosto visível, se houver mais de um rosto principal, ou se a FOTO 2 parecer foto de tela/papel.',
      messages: [{ role: 'user', content: [
        { type: 'text', text: 'FOTO 1 (cadastro):' },
        { type: 'file', data: reference, mediaType: refType },
        { type: 'text', text: 'FOTO 2 (câmera agora):' },
        { type: 'file', data: captured, mediaType: 'image/jpeg' },
        { type: 'text', text: 'É a mesma pessoa? Responda SIM ou NAO.' },
      ] }],
    });
    const t = result.text.trim().toUpperCase();
    return { match: t.startsWith('SIM'), error: null };
  } catch (e) {
    console.error('face compare', e);
    return { match: false, error: 'Não foi possível verificar o rosto agora.' };
  }
}
