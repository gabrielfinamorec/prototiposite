import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';

export const newsSchema=z.object({id:z.string().uuid().optional(),title:z.string().trim().min(1).max(150),body:z.string().trim().min(1).max(20000),image_path:z.string().min(1).max(500),image_name:z.string().max(255)});
export const getNews=createServerFn({method:'GET'}).middleware([requireSupabaseAuth]).handler(async({context})=>{
  const {data,error}=await context.supabase.from('news_posts').select('*').order('created_at',{ascending:false});if(error)throw new Error(error.message);
  return Promise.all((data??[]).map(async post=>{const {data:image}=await context.supabase.storage.from('people-documents').createSignedUrl(post.image_path,3600);return {...post,image_url:image?.signedUrl??''};}));
});
export const saveNews=createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(newsSchema).handler(async({data,context})=>{
  if(!data.image_path.startsWith(`${context.userId}/`)||!/^.+\.(png|jpg|jpeg)$/i.test(data.image_path))throw new Error('Imagem inválida');
  const {id,...post}=data;
  const {data:row,error}=await context.supabase.from('news_posts').upsert({...post,...(id?{id}:{}),owner_id:context.userId}).select('id').single();if(error)throw new Error(error.message);return row;
});
export const deleteNews=createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(z.object({id:z.string().uuid()})).handler(async({data,context})=>{const {error}=await context.supabase.from('news_posts').delete().eq('id',data.id);if(error)throw new Error(error.message);return {ok:true};});