import { z } from 'zod';

export const movementKinds = ['atestado', 'afastamento', 'demissao'] as const;
export type MovementKind = typeof movementKinds[number];
export const kindLabels: Record<MovementKind, string> = { atestado: 'Atestado', afastamento: 'Afastamento', demissao: 'Demissão' };
export const typeLabels: Record<MovementKind, string> = { atestado: 'Tipos de atestado', afastamento: 'Tipos de afastamento', demissao: 'Motivos de demissão' };
export const initiativeLabels = { empresa: 'Iniciativa da empresa', colaborador: 'Iniciativa do colaborador', outro: 'Outro' } as const;

const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Data inválida');
const optDate = z.union([date, z.literal(''), z.null()]).transform(v => v || null);

export const movementTypeSchema = z.object({
  id: z.string().uuid().optional(),
  kind: z.enum(movementKinds),
  name: z.string().trim().min(1, 'Informe o nome').max(200),
  description: z.string().max(4000).default(''),
  initiative: z.enum(['', 'empresa', 'colaborador', 'outro']).default(''),
  requires_document: z.boolean().default(false),
  active: z.boolean(),
});

const attachment = z.object({ path: z.string().min(1).max(500), name: z.string().min(1).max(300) });

export const movementSchema = z.object({
  id: z.string().uuid().optional(),
  kind: z.enum(movementKinds),
  employee_id: z.string().uuid('Selecione o colaborador'),
  type_id: z.string().uuid('Selecione o tipo'),
  start_date: date,
  end_date: optDate,
  return_date: optDate,
  has_notice: z.boolean().default(false),
  notice_type: z.enum(['', 'trabalhado', 'indenizado']).default(''),
  notice_start: optDate,
  notice_end: optDate,
  notes: z.string().max(4000).default(''),
  attachments: z.array(attachment).max(30).default([]),
}).superRefine((v, ctx) => {
  const err = (message: string) => ctx.addIssue({ code: 'custom', message });
  if (v.kind !== 'demissao' && !v.end_date) err('Informe a data final');
  if (v.end_date && v.end_date < v.start_date) err('A data final não pode ser antes do início');
  if (v.return_date && v.return_date < v.start_date) err('A data de retorno não pode ser antes do início');
  if (v.kind === 'demissao' && v.has_notice) {
    if (!v.notice_type) err('Escolha o tipo do aviso prévio');
    if (!v.notice_start || !v.notice_end) err('Informe o início e o fim do aviso prévio');
    else if (v.notice_end < v.notice_start) err('O fim do aviso não pode ser antes do início');
  }
});

/** Dias corridos, contando o primeiro e o último dia. */
export function daysBetween(start: string, end: string | null) {
  if (!start || !end) return 0;
  const d = (Date.parse(`${end}T00:00:00Z`) - Date.parse(`${start}T00:00:00Z`)) / 86400000;
  return d < 0 ? 0 : d + 1;
}

/** Situação mostrada na tabela, calculada pela data de hoje. */
export function movementStatus(m: { kind: MovementKind; start_date: string; end_date: string | null; return_date: string | null; has_notice: boolean; notice_start: string | null; notice_end: string | null }, today: string) {
  if (m.kind === 'demissao') {
    if (m.has_notice && m.notice_start && today >= m.notice_start && (!m.notice_end || today <= m.notice_end)) return 'Em aviso prévio';
    if (today >= m.start_date) return 'Desligado';
    return 'Agendada';
  }
  const end = m.return_date ?? m.end_date;
  if (today < m.start_date) return 'Agendado';
  if (m.return_date && today >= m.return_date) return 'Encerrado';
  if (end && today > end) return 'Encerrado';
  return 'Em andamento';
}

type Row = { employee_id: string; kind: string; start_date: string; end_date: string | null; return_date: string | null; has_notice: boolean; notice_start: string | null; notice_end: string | null };
/** Situação do colaborador pelas movimentações. Prioridade: Desligado > Em aviso prévio > Afastado > Atestado. */
export function employeeMovementStatus(rows: Row[], today: string) {
  const rank = { 'Desligado': 4, 'Em aviso prévio': 3, 'Afastado': 2, 'Atestado': 1 } as const;
  const out: Record<string, keyof typeof rank> = {};
  for (const r of rows) {
    const s = movementStatus({ ...r, kind: r.kind as MovementKind }, today);
    const v = s === 'Desligado' ? 'Desligado' : s === 'Em aviso prévio' ? 'Em aviso prévio' : s === 'Em andamento' ? (r.kind === 'atestado' ? 'Atestado' : 'Afastado') : null;
    if (v && (!out[r.employee_id] || rank[v] > rank[out[r.employee_id]!])) out[r.employee_id] = v;
  }
  return out;
}
