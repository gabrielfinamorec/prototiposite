import { z } from 'zod';
const text = z.string().trim().min(1, 'Campo obrigatório').max(150);
export const companySchema = z.object({ name: text, cnpj: z.string().regex(/^\d{14}$/, 'CNPJ deve conter 14 números') });
export const departmentSchema = z.object({ name: text, company_id: z.string().uuid(), active: z.boolean() });
export const detailLabels = { summary: 'Descrição sumária', knowledge: 'Conhecimento obrigatório / desejável', availability: 'Disponibilidades exigidas', epi: 'EPI', education: 'Formação escolar', experience: 'Experiência desejada', training: 'Treinamento obrigatório / desejável', behavior: 'Atitudes comportamentais' };
const longText = z.string().trim().min(1, 'Campo obrigatório').max(5000);
export const longDetailKeys = ['summary','knowledge','availability','epi','experience','training','behavior'];
export const detailsSchema = z.object({ summary: longText, knowledge: longText, availability: longText, epi: longText, education: text, experience: longText, training: longText, behavior: longText });
export const jobSchema = z.object({ name: text, company_id: z.string().uuid(), department_id: z.string().uuid(), cbo: z.string().trim().min(1).max(30), hourly_rate: z.number().min(0).max(9999999999), details: detailsSchema, attachments: z.array(z.string().min(1)).default([]) });
export const connectionSide = z.enum(['top','right','bottom','left']);
export const connectionSchema = z.object({company_id:z.string().uuid(),source_id:z.string().uuid(),target_id:z.string().uuid(),source_handle:connectionSide.default('right'),target_handle:connectionSide.default('left')}).refine(v=>v.source_id!==v.target_id,'Conecte dois cargos diferentes.');
export const superiorLabel = (job:{superior_id:string|null;no_superior?:boolean},jobs:{id:string;name:string}[]) => job.no_superior?'Sem superior direto':jobs.find(j=>j.id===job.superior_id)?.name ?? 'Pendente';
export function hierarchyAllowed(id: string, superior: string | null, jobs: {id: string; superior_id: string | null}[]) {
  const visited = new Set<string>([id]);
  let current = superior;
  while (current) { if (visited.has(current)) return false; visited.add(current); current = jobs.find(j => j.id === current)?.superior_id ?? null; }
  return true;
}
export const money = (v: number) => v.toLocaleString('pt-BR', {style:'currency', currency:'BRL'});
export const cnpjFormat = (s: string) => s.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, '$1.$2.$3/$4-$5');