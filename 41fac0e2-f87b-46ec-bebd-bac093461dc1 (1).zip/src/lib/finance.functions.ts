import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { companySchema, departmentSchema, jobSchema, connectionSchema } from './finance-schema';

export const getFinance = createServerFn({method:'GET'}).middleware([requireSupabaseAuth]).handler(async ({context}) => {
  const [c,d,j,e] = await Promise.all([context.supabase.from('companies').select('*').order('created_at'), context.supabase.from('departments').select('*').order('created_at'), context.supabase.from('jobs').select('*').order('created_at'),context.supabase.from('org_connections').select('*')]);
  if (c.error || d.error || j.error || e.error) throw new Error(c.error?.message || d.error?.message || j.error?.message || e.error?.message);
  return {companies:c.data ?? [], departments:d.data ?? [], jobs:j.data ?? [],connections:e.data ?? []};
});
const saveSchema = z.discriminatedUnion('kind', [z.object({kind:z.literal('companies'), id:z.string().uuid().optional(), value:companySchema}), z.object({kind:z.literal('departments'), id:z.string().uuid().optional(), value:departmentSchema}), z.object({kind:z.literal('jobs'), id:z.string().uuid().optional(), value:jobSchema})]);
export const saveRecord = createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(saveSchema).handler(async ({data,context}) => {
  const query = data.id ? context.supabase.from(data.kind).update(data.value).eq('id',data.id) : context.supabase.from(data.kind).insert({...data.value,owner_id:context.userId});
  const {error} = await query; if(error) throw new Error(error.message); return {ok:true};
});
export const deleteRecord = createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(z.object({kind:z.enum(['companies','departments','jobs']),id:z.string().uuid()})).handler(async ({data,context}) => {
  const {error} = await context.supabase.from(data.kind).delete().eq('id',data.id); if(error) throw new Error('Este cadastro possui vínculos. Remova os vínculos antes de excluir.'); return {ok:true};
});
export const updateHierarchy = createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(z.object({id:z.string().uuid(), superior_id:z.string().uuid().nullable().optional(), no_superior:z.boolean().optional(),position_x:z.number().finite().optional(),position_y:z.number().finite().optional()}).refine(v=>!v.no_superior||!v.superior_id,'Um cargo sem superior não pode ter superior direto.')).handler(async ({data,context}) => {
  const {id}=data; const value={...(data.superior_id!==undefined?{superior_id:data.superior_id}:{}),...(data.no_superior!==undefined?{no_superior:data.no_superior}:{}),...(data.position_x!==undefined?{position_x:data.position_x}:{}),...(data.position_y!==undefined?{position_y:data.position_y}:{})}; const {error}=await context.supabase.from('jobs').update(value).eq('id',id); if(error) throw new Error(error.message); return {ok:true};
});
export const saveConnection = createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(connectionSchema).handler(async({data,context})=>{const {error}=await context.supabase.from('org_connections').upsert({...data,owner_id:context.userId},{onConflict:'source_id,target_id'});if(error)throw new Error(error.message);return {ok:true};});
export const deleteConnection = createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(z.object({id:z.string().uuid()})).handler(async({data,context})=>{const {error}=await context.supabase.from('org_connections').delete().eq('id',data.id);if(error)throw new Error(error.message);return {ok:true};});
export const summarizeJob = createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(z.object({id:z.string().uuid()})).handler(async ({data,context}) => {
  const {data:job,error}=await context.supabase.from('jobs').select('name,details').eq('id',data.id).single();
  if(error || !job) throw new Error('Cargo não encontrado');
  const {summarize}=await import('./ai/summary.server'); return summarize(job);
});