import { z } from 'zod';
import { addDays, addWeeks, addMonths, addYears, format, parseISO } from 'date-fns';
export const units = ['dias','semanas','meses','anos'] as const;
export const attachmentSchema=z.object({path:z.string().min(1).max(500),name:z.string().min(1).max(255)});
export type Attachment=z.infer<typeof attachmentSchema>;
export const typeSchema=z.object({id:z.string().uuid().optional(),name:z.string().trim().min(1,'Informe o nome').max(150),has_expiry:z.boolean(),duration:z.number().int().min(1).max(999),unit:z.enum(units),responsible_id:z.string().uuid('Selecione um responsável'),department_ids:z.array(z.string().uuid()),job_ids:z.array(z.string().uuid()),employee_ids:z.array(z.string().uuid()),guidance:z.string().max(20000),active:z.boolean(),attachments:z.array(attachmentSchema)});
export type TypeForm=z.infer<typeof typeSchema>;
export const typeDefaults=():TypeForm=>({name:'',has_expiry:false,duration:1,unit:'dias',responsible_id:'',department_ids:[],job_ids:[],employee_ids:[],guidance:'',active:true,attachments:[]});
export function todayLocal(){return new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());}
export function expiryDate(issue:string,quantity:number,unit:typeof units[number]){if(!issue)return '';const date=parseISO(issue);if(!Number.isFinite(date.getTime()))return '';return format(({dias:addDays,semanas:addWeeks,meses:addMonths,anos:addYears}[unit])(date,quantity),'yyyy-MM-dd');}
export function documentStatus(doc:{state:string;expiry_date:string|null},today=todayLocal()){return doc.state==='cancelado'?'cancelado':doc.state==='pendente'?'pendente':doc.expiry_date&&doc.expiry_date<today?'vencido':'em dia';}
export function assignedEmployees(type:Pick<TypeForm,'department_ids'|'job_ids'|'employee_ids'>,employees:{id:string;job_id:string}[],jobs:{id:string;department_id:string}[]){return employees.filter(e=>type.employee_ids.includes(e.id)||type.job_ids.includes(e.job_id)||type.department_ids.includes(jobs.find(j=>j.id===e.job_id)?.department_id??'')).map(e=>e.id);}
export const dateSchema=z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(v=>{const date=parseISO(v);return Number.isFinite(date.getTime())&&format(date,'yyyy-MM-dd')===v;},'Data inválida');
export const documentInfoSchema=z.object({id:z.string().uuid(),issue_date:dateSchema.nullable(),expiry_date:dateSchema.nullable(),notes:z.string().max(20000),attachments:z.array(attachmentSchema)});
