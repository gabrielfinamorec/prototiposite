import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { typeSchema, documentInfoSchema, type Attachment } from './document-rules';
function checkAttachments(files:Attachment[],owner:string){for(const file of files)if(!file.path.startsWith(`${owner}/`)||!/^.+\.(png|jpg|jpeg|pdf)$/i.test(file.path))throw new Error('Anexo inválido');}
export const getDocumentManagement=createServerFn({method:'GET'}).middleware([requireSupabaseAuth]).handler(async({context})=>{
 const results=await Promise.all([context.supabase.from('document_types').select('*').order('created_at',{ascending:false}),context.supabase.from('controlled_documents').select('*').order('created_at',{ascending:false}),context.supabase.from('employees').select('*').order('created_at')]);
 for(const r of results)if(r.error)throw new Error(r.error.message);
 return {types:results[0].data??[],documents:results[1].data??[],employees:results[2].data??[]};
});
export const saveDocumentType=createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(typeSchema).handler(async({data,context})=>{
 checkAttachments(data.attachments,context.userId);const {id,...value}=data;
 const {error}=id?await context.supabase.from('document_types').update(value).eq('id',id):await context.supabase.from('document_types').insert({...value,owner_id:context.userId});
 if(error)throw new Error(error.message);return {ok:true};
});
export const saveDocumentInfo=createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(documentInfoSchema).handler(async({data,context})=>{
 checkAttachments(data.attachments,context.userId);const {id,...value}=data;
 const {data:row,error}=await context.supabase.from('controlled_documents').update({...value,updated_at:new Date().toISOString()}).eq('id',id).neq('state','cancelado').select('id').single();
 if(error||!row)throw new Error(error?.message??'Documentos cancelados não podem ser editados');return {ok:true};
});
export const actOnDocuments=createServerFn({method:'POST'}).middleware([requireSupabaseAuth]).inputValidator(z.object({ids:z.array(z.string().uuid()).min(1).max(1000),action:z.enum(['validar','desfazer_validacao','renovar','cancelar','desfazer_cancelamento'])})).handler(async({data,context})=>{
 const {error}=await context.supabase.rpc('document_action',{_ids:[...new Set(data.ids)],_action:data.action});if(error)throw new Error(error.message);return {ok:true};
});
export const getDocumentHistory=createServerFn({method:'GET'}).middleware([requireSupabaseAuth]).inputValidator(z.object({id:z.string().uuid()})).handler(async({data,context})=>{
 const {data:rows,error}=await context.supabase.from('document_history').select('*').eq('document_id',data.id).order('created_at',{ascending:false});if(error)throw new Error(error.message);return rows??[];
});
