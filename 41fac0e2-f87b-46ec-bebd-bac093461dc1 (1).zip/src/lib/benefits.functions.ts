import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { benefitSchema } from './benefit-rules';

const nameOf = (p: unknown) => (p && typeof p === 'object' && 'name' in p ? String((p as { name: unknown }).name) : '');

export const getBenefits = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const [b, e, d] = await Promise.all([
    context.supabase.from('benefits').select('id,company_id,name,target,notes,member_ids').order('name'),
    context.supabase.from('employees').select('id,company_id,job_id,personal'),
    context.supabase.from('dependents').select('id,company_id,employee_id,name,degree,active'),
  ]);
  if (b.error || e.error || d.error) throw new Error(b.error?.message || e.error?.message || d.error?.message);
  return {
    benefits: b.data ?? [],
    employees: (e.data ?? []).map(x => ({ id: x.id, company_id: x.company_id, job_id: x.job_id, name: nameOf(x.personal) })),
    dependents: d.data ?? [],
  };
});

export const saveBenefit = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).inputValidator(benefitSchema).handler(async ({ data, context }) => {
  const row = { company_id: data.company_id, name: data.name, target: data.target, notes: data.notes, owner_id: context.userId };
  if (data.id) {
    const { data: cur } = await context.supabase.from('benefits').select('company_id,target').eq('id', data.id).single();
    if (!cur) throw new Error('Benefício não encontrado');
    const changed = cur.company_id !== data.company_id || cur.target !== data.target;
    const { error } = await context.supabase.from('benefits').update(changed ? { ...row, member_ids: [] } : row).eq('id', data.id);
    if (error) throw new Error(error.message);
    return { id: data.id };
  }
  const { data: ins, error } = await context.supabase.from('benefits').insert(row).select('id').single();
  if (error) throw new Error(error.message);
  return { id: ins.id };
});

export const saveBenefitMembers = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator(z.object({ id: z.string().uuid(), member_ids: z.array(z.string().uuid()).max(5000) }))
  .handler(async ({ data, context }) => {
    const { data: b } = await context.supabase.from('benefits').select('company_id,target').eq('id', data.id).single();
    if (!b) throw new Error('Benefício não encontrado');
    const ids = [...new Set(data.member_ids)];
    if (ids.length) {
      const q = b.target === 'colaborador'
        ? await context.supabase.from('employees').select('id').eq('company_id', b.company_id).in('id', ids)
        : await context.supabase.from('dependents').select('id').eq('company_id', b.company_id).in('id', ids);
      if (q.error) throw new Error(q.error.message);
      if ((q.data ?? []).length !== ids.length) throw new Error('Há pessoas que não pertencem a esta empresa');
    }
    const { error } = await context.supabase.from('benefits').update({ member_ids: ids }).eq('id', data.id);
    if (error) throw new Error(error.message);
    return { count: ids.length };
  });

export const deleteBenefit = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).inputValidator(z.object({ id: z.string().uuid() })).handler(async ({ data, context }) => {
  const { error } = await context.supabase.from('benefits').delete().eq('id', data.id);
  if (error) throw new Error(error.message);
  return { ok: true };
});

export const getPersonBenefits = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth])
  .inputValidator(z.object({ person_id: z.string().uuid(), target: z.enum(['colaborador', 'dependente']) }))
  .handler(async ({ data, context }) => {
    const p = await context.supabase.from(data.target === 'colaborador' ? 'employees' : 'dependents').select('company_id').eq('id', data.person_id).maybeSingle();
    if (p.error) throw new Error(p.error.message);
    if (!p.data) return [];
    const { data: rows, error } = await context.supabase.from('benefits').select('id,name,notes,member_ids').eq('company_id', p.data.company_id).eq('target', data.target).order('name');
    if (error) throw new Error(error.message);
    return (rows ?? []).map(b => ({ id: b.id, name: b.name, notes: b.notes, active: b.member_ids.includes(data.person_id) }));
  });

export const setPersonBenefit = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator(z.object({ benefit_id: z.string().uuid(), person_id: z.string().uuid(), active: z.boolean() }))
  .handler(async ({ data, context }) => {
    const { data: b } = await context.supabase.from('benefits').select('company_id,target,member_ids').eq('id', data.benefit_id).single();
    if (!b) throw new Error('Benefício não encontrado');
    const p = await context.supabase.from(b.target === 'colaborador' ? 'employees' : 'dependents').select('id').eq('id', data.person_id).eq('company_id', b.company_id).maybeSingle();
    if (!p.data) throw new Error('Esta pessoa não pertence à empresa do benefício');
    const ids = data.active ? [...new Set([...b.member_ids, data.person_id])] : b.member_ids.filter(x => x !== data.person_id);
    const { error } = await context.supabase.from('benefits').update({ member_ids: ids }).eq('id', data.benefit_id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
