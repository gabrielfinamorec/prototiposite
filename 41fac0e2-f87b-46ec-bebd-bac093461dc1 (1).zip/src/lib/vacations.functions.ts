import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { allowedActions, overlaps, vacationActions, vacationSchema, vacationStatus } from './vacation-rules';
import { todayLocal } from './document-rules';

const nameOf = (personal: unknown) => (personal && typeof personal === 'object' && 'name' in personal ? String((personal as { name: unknown }).name) : '');

export const getVacations = createServerFn({ method: 'GET' }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const [v, e] = await Promise.all([
    context.supabase.from('vacation_requests').select('id,company_id,employee_id,start_date,end_date,state,finished,notes,created_at').order('start_date', { ascending: false }),
    context.supabase.from('employees').select('id,company_id,job_id,personal'),
  ]);
  if (v.error || e.error) throw new Error(v.error?.message || e.error?.message);
  return {
    requests: v.data ?? [],
    employees: (e.data ?? []).map(x => ({ id: x.id, company_id: x.company_id, job_id: x.job_id, name: nameOf(x.personal) })),
    today: todayLocal(),
  };
});

export const saveVacation = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).inputValidator(vacationSchema).handler(async ({ data, context }) => {
  const { data: emp, error: ee } = await context.supabase.from('employees').select('company_id').eq('id', data.employee_id).single();
  if (ee || !emp) throw new Error('Colaborador não encontrado');
  if (data.id) {
    const { data: cur } = await context.supabase.from('vacation_requests').select('state').eq('id', data.id).single();
    if (!cur) throw new Error('Solicitação não encontrada');
    if (cur.state !== 'pendente') throw new Error('Só é possível alterar solicitações pendentes');
  }
  const { data: others, error: oe } = await context.supabase.from('vacation_requests').select('id,start_date,end_date').eq('employee_id', data.employee_id).neq('state', 'cancelada');
  if (oe) throw new Error(oe.message);
  if ((others ?? []).some(o => o.id !== data.id && overlaps(o, data))) throw new Error('Já existe uma solicitação de férias desse colaborador nesse período');
  const row = { employee_id: data.employee_id, company_id: emp.company_id, owner_id: context.userId, start_date: data.start_date, end_date: data.end_date, notes: data.notes, updated_at: new Date().toISOString() };
  const res = data.id ? await context.supabase.from('vacation_requests').update(row).eq('id', data.id) : await context.supabase.from('vacation_requests').insert(row);
  if (res.error) throw new Error(res.error.message);
  return { ok: true };
});

export const actOnVacations = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth])
  .inputValidator(z.object({ ids: z.array(z.string().uuid()).min(1).max(500), action: z.enum(vacationActions) }))
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await context.supabase.from('vacation_requests').select('id,employee_id,start_date,end_date,state,finished').in('id', data.ids);
    if (error) throw new Error(error.message);
    const today = todayLocal();
    const eligible = (rows ?? []).filter(r => allowedActions(vacationStatus(r, today)).includes(data.action));
    if (data.action === 'reabrir') {
      const { data: active } = await context.supabase.from('vacation_requests').select('id,employee_id,start_date,end_date').neq('state', 'cancelada').in('employee_id', eligible.map(r => r.employee_id));
      const clash = eligible.find(r => (active ?? []).some(a => a.employee_id === r.employee_id && overlaps(a, r)));
      if (clash) throw new Error('Não é possível reabrir: já existe outra solicitação ativa nesse período');
    }
    const patch = data.action === 'aprovar' ? { state: 'aprovada' } : data.action === 'cancelar' ? { state: 'cancelada' } : data.action === 'reabrir' || data.action === 'desfazer' ? { state: 'pendente', finished: false } : { finished: true };
    if (eligible.length) {
      const { error: ue } = await context.supabase.from('vacation_requests').update({ ...patch, updated_at: new Date().toISOString() }).in('id', eligible.map(r => r.id));
      if (ue) throw new Error(ue.message);
    }
    return { updated: eligible.length, skipped: (rows?.length ?? 0) - eligible.length };
  });

export const deleteVacation = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).inputValidator(z.object({ id: z.string().uuid() })).handler(async ({ data, context }) => {
  const { error } = await context.supabase.from('vacation_requests').delete().eq('id', data.id).eq('state', 'pendente');
  if (error) throw new Error(error.message);
  return { ok: true };
});
