import { createFileRoute } from '@tanstack/react-router';
import { LayoutEditor } from '@/components/finance/layout-editor';
import { pageHead } from '@/lib/page-head';
export const Route=createFileRoute('/layouts')({head:()=>pageHead('Layouts','Personalize os formatos, informações e ordem das exportações do Fincore.'),component:LayoutEditor});