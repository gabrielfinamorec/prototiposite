import { createFileRoute } from '@tanstack/react-router';
import { Movements } from '@/components/finance/movements';
import { pageHead } from '@/lib/page-head';
export const Route = createFileRoute('/atestados')({ head: () => pageHead('Atestados', 'Registro de atestados dos colaboradores.'), component: () => <Movements kind="atestado" /> });
