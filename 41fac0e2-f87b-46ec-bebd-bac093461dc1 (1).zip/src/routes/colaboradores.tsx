import { createFileRoute } from '@tanstack/react-router';
import { People } from '@/components/finance/people';
import { pageHead } from '@/lib/page-head';
export const Route=createFileRoute('/colaboradores')({head:()=>pageHead('Colaboradores','Cadastre colaboradores, informações financeiras, documentos pessoais e dependentes no Fincore.'),component:()=> <People kind="employees"/>});