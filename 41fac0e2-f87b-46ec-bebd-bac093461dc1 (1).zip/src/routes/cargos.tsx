import { createFileRoute } from '@tanstack/react-router';
import { Records } from '@/components/finance/records';
import { pageHead } from '@/lib/page-head';
export const Route=createFileRoute('/cargos')({head:()=>pageHead('Cargos','Gerencie cargos, requisitos, anexos e exporte informações completas em PDF.'),component:()=> <Records kind="jobs"/>});