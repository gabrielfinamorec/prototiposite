import { createFileRoute } from '@tanstack/react-router';
import { Benefits } from '@/components/finance/benefits';
import { pageHead } from '@/lib/page-head';
export const Route = createFileRoute('/beneficios')({ head: () => pageHead('Benefícios', 'Cadastre benefícios e marque colaboradores ou dependentes beneficiários.'), component: Benefits });
