import { createFileRoute } from '@tanstack/react-router';
import { Movements } from '@/components/finance/movements';
import { pageHead } from '@/lib/page-head';
export const Route = createFileRoute('/afastamentos')({ head: () => pageHead('Afastamentos', 'Registro de afastamentos dos colaboradores.'), component: () => <Movements kind="afastamento" /> });
