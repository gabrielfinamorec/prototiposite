import { createFileRoute } from '@tanstack/react-router';
import { Records } from '@/components/finance/records';
import { pageHead } from '@/lib/page-head';
export const Route=createFileRoute('/departamentos')({head:()=>pageHead('Departamentos','Gerencie departamentos e suas empresas no Fincore.'),component:()=> <Records kind="departments"/>});