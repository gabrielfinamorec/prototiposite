import { createFileRoute } from '@tanstack/react-router';
import { MovementTypes } from '@/components/finance/movements';
import { pageHead } from '@/lib/page-head';
export const Route = createFileRoute('/cadastros-movimentacoes')({ head: () => pageHead('Cadastros de movimentações', 'Tipos de atestado, tipos de afastamento e motivos de demissão.'), component: MovementTypes });
