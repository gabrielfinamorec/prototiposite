import { createFileRoute, Link } from '@tanstack/react-router';
import { AccessPanel } from '@/components/finance/access-panel';
import { pageHead } from '@/lib/page-head';
export const Route=createFileRoute('/acesso')({head:()=>pageHead('Acesso','Entre no seu espaço Fincore para gerenciar pessoas e organização.'),component:Access});
function Access(){return <main className="access-page"><AccessPanel/><Link to="/" className="text-sm text-muted-foreground">Voltar ao início</Link></main>;}