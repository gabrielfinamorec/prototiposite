import { createFileRoute } from '@tanstack/react-router';
import { People } from '@/components/finance/people';
import { pageHead } from '@/lib/page-head';
export const Route=createFileRoute('/dependentes')({head:()=>pageHead('Dependentes','Consulte dependentes, titulares e a situação da documentação no Fincore.'),component:()=> <People kind="dependents"/>});