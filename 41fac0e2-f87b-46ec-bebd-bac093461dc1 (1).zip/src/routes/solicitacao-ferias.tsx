import { createFileRoute } from '@tanstack/react-router';
import { VacationRequests } from '@/components/finance/vacations';
import { pageHead } from '@/lib/page-head';
export const Route = createFileRoute('/solicitacao-ferias')({ head: () => pageHead('Solicitação de férias', 'Registre, aprove e acompanhe as solicitações de férias dos colaboradores.'), component: VacationRequests });
