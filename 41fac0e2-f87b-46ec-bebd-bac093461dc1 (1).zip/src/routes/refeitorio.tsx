import { createFileRoute } from '@tanstack/react-router';
import { Meals } from '@/components/finance/meals';
import { pageHead } from '@/lib/page-head';
export const Route = createFileRoute('/refeitorio')({ head: () => pageHead('Refeitório', 'Registre almoços de colaboradores e visitantes, consulte fotos e exporte relatórios.'), component: Meals });
