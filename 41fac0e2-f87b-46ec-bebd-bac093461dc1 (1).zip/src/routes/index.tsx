import { createFileRoute } from '@tanstack/react-router';
import { News } from '@/components/finance/news';
import { pageHead } from '@/lib/page-head';
export const Route=createFileRoute('/')({head:()=>pageHead('Notícias','Acompanhe notícias e novidades da sua equipe no Fincore.'),component:()=> <News/>});
