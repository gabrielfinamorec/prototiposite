import { createFileRoute } from '@tanstack/react-router';
import { News } from '@/components/finance/news';
import { pageHead } from '@/lib/page-head';
export const Route=createFileRoute('/portal-noticias')({head:()=>pageHead('Cadastro de notícias','Cadastre imagens, títulos e textos das notícias do seu espaço Fincore.'),component:()=> <News manage/>});