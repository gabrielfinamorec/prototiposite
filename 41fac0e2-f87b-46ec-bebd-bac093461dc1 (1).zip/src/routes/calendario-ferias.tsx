import { createFileRoute } from '@tanstack/react-router';
import { VacationCalendar } from '@/components/finance/vacations';
import { pageHead } from '@/lib/page-head';
export const Route = createFileRoute('/calendario-ferias')({ head: () => pageHead('Calendário de férias', 'Compare férias planejadas e confirmadas por departamento, cargo e colaborador.'), component: VacationCalendar });
