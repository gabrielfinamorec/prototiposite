import { createFileRoute } from '@tanstack/react-router';
import { BenefitBeneficiaries } from '@/components/finance/benefits';
import { pageHead } from '@/lib/page-head';
export const Route = createFileRoute('/consulta-beneficiarios')({ head: () => pageHead('Consulta de beneficiários', 'Consulte todos os beneficiários de cada benefício.'), component: BenefitBeneficiaries });
