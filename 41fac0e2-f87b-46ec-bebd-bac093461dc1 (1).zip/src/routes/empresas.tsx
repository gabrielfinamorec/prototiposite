import { createFileRoute } from '@tanstack/react-router';
import { Records } from '@/components/finance/records';
import { pageHead } from '@/lib/page-head';
export const Route=createFileRoute('/empresas')({head:()=>pageHead('Empresas','Cadastre e organize as empresas do seu grupo no Fincore.'),component:()=> <Records kind="companies"/>});