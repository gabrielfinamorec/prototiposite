import { createFileRoute } from '@tanstack/react-router';
import { Reports } from '@/components/finance/consults';
import { pageHead } from '@/lib/page-head';
export const Route = createFileRoute('/relatorios')({ head: () => pageHead('Relatórios', 'Relatórios de colaboradores, movimentações, férias, documentos, benefícios e aniversários.'), component: Reports });
