import { createFileRoute } from '@tanstack/react-router';
import { DocumentManagement } from '@/components/finance/document-management';
import { pageHead } from '@/lib/page-head';
export const Route=createFileRoute('/documentos')({head:()=>pageHead('Documentos','Controle pendências, validações, vencimentos e o histórico de documentos no Fincore.'),component:()=> <DocumentManagement kind="documents"/>});
