import { createFileRoute } from '@tanstack/react-router';
import { Movements } from '@/components/finance/movements';
import { pageHead } from '@/lib/page-head';
export const Route = createFileRoute('/demissoes')({ head: () => pageHead('Demissões', 'Registro de demissões e aviso prévio.'), component: () => <Movements kind="demissao" /> });
