import { createFileRoute } from '@tanstack/react-router';
import { Totem } from '@/components/finance/meals';
import { pageHead } from '@/lib/page-head';
export const Route = createFileRoute('/totem')({ head: () => pageHead('Totem do refeitório', 'Valide seu almoço pela facial ou registre sua visita com nome e foto.'), component: Totem });
