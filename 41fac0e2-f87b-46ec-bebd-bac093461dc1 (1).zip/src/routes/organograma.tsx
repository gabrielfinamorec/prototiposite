import { createFileRoute } from '@tanstack/react-router';
import { OrgChart } from '@/components/finance/org-chart';
import { pageHead } from '@/lib/page-head';
export const Route=createFileRoute('/organograma')({head:()=>pageHead('Organograma','Organize visualmente a hierarquia de cargos por empresa.'),component:OrgChart});