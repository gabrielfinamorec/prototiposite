import { createFileRoute } from '@tanstack/react-router';
import { DocumentManagement } from '@/components/finance/document-management';
import { pageHead } from '@/lib/page-head';
export const Route=createFileRoute('/tipos-documentos')({head:()=>pageHead('Tipos de documentos','Cadastre tipos, validade, responsáveis e atribuições de documentos no Fincore.'),component:()=> <DocumentManagement kind="types"/>});
