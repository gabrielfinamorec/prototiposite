import { createFileRoute } from '@tanstack/react-router';
import { Dashboard } from '@/components/finance/consults';
import { pageHead } from '@/lib/page-head';
export const Route = createFileRoute('/dashboard')({ head: () => pageHead('Dashboard', 'Visão geral de colaboradores, alertas e próximos eventos.'), component: Dashboard });
