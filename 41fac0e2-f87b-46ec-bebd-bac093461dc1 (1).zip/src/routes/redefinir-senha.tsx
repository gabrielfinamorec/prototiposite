import { createFileRoute } from '@tanstack/react-router';
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { pageHead } from '@/lib/page-head';
export const Route=createFileRoute('/redefinir-senha')({head:()=>pageHead('Redefinir senha','Atualize com segurança sua senha de acesso ao Fincore.'),component:Reset});
function Reset(){const [password,setPassword]=useState('');return <form className="reset-form" onSubmit={async e=>{e.preventDefault();const {error}=await supabase.auth.updateUser({password});if(error)toast.error(error.message);else toast.success('Senha atualizada.');}}><h1>Redefinir senha</h1><Input type="password" minLength={8} maxLength={128} required aria-label="Nova senha" value={password} onChange={e=>setPassword(e.target.value)}/><Button>Salvar nova senha</Button></form>;}