import { createFileRoute } from '@tanstack/react-router';
import { CompanyCalendar } from '@/components/finance/company-calendar';
import { pageHead } from '@/lib/page-head';
export const Route = createFileRoute('/calendario-empresa')({ head: () => pageHead('Calendário da empresa', 'Defina dias trabalhados, feriados, recessos coletivos e folgas de cada empresa.'), component: CompanyCalendar });
