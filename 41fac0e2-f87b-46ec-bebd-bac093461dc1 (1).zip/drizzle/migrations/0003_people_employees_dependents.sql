CREATE TABLE public.employees (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL DEFAULT auth.uid(), company_id uuid NOT NULL, job_id uuid NOT NULL,
 personal jsonb NOT NULL, finance jsonb NOT NULL DEFAULT '{}'::jsonb, documents jsonb NOT NULL DEFAULT '{}'::jsonb,
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(id,company_id,owner_id),
 FOREIGN KEY(company_id,owner_id) REFERENCES public.companies(id,owner_id),
 FOREIGN KEY(job_id,company_id,owner_id) REFERENCES public.jobs(id,company_id,owner_id)
);
GRANT SELECT,INSERT,UPDATE,DELETE ON public.employees TO authenticated;
GRANT ALL ON public.employees TO service_role;
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_access ON public.employees FOR ALL TO authenticated USING(owner_id=auth.uid()) WITH CHECK(owner_id=auth.uid());
CREATE TABLE public.dependents (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL DEFAULT auth.uid(), company_id uuid NOT NULL, employee_id uuid NOT NULL,
 degree text NOT NULL CHECK(degree IN ('Cônjuge','Filho')), name text NOT NULL CHECK(length(trim(name)) BETWEEN 1 AND 150), cpf text NOT NULL CHECK(cpf ~ '^\d{11}$'), rg text NOT NULL CHECK(length(trim(rg)) BETWEEN 1 AND 150), birth_date date NOT NULL, sex text NOT NULL CHECK(sex IN ('masculino','feminino')), active boolean NOT NULL DEFAULT true, documents jsonb NOT NULL DEFAULT '{}'::jsonb, created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(employee_id,company_id,owner_id) REFERENCES public.employees(id,company_id,owner_id) ON DELETE CASCADE
);
GRANT SELECT,INSERT,UPDATE,DELETE ON public.dependents TO authenticated;
GRANT ALL ON public.dependents TO service_role;
ALTER TABLE public.dependents ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_access ON public.dependents FOR ALL TO authenticated USING(owner_id=auth.uid()) WITH CHECK(owner_id=auth.uid());
CREATE OR REPLACE FUNCTION public.validate_people_record() RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$
DECLARE k text; p jsonb; doc jsonb;
BEGIN
 IF TG_TABLE_NAME='employees' THEN
  p:=NEW.personal;
  FOREACH k IN ARRAY ARRAY['cpf','name','rg','work_card','voter_id','birth_date','sex','civil_status','phone'] LOOP
   IF jsonb_typeof(p->k) IS DISTINCT FROM 'string' OR length(trim(p->>k)) NOT BETWEEN 1 AND 255 THEN RAISE EXCEPTION 'Campo obrigatório inválido: %',k; END IF;
  END LOOP;
  IF p->>'cpf' !~ '^\d{11}$' OR regexp_replace(p->>'phone','[^0-9]','','g') !~ '^\d{11}$' OR p->>'sex' NOT IN ('masculino','feminino') OR p->>'civil_status' NOT IN ('Solteiro(a)','Casado(a)','Divorciado(a)','Viúvo(a)','Separado(a)') THEN RAISE EXCEPTION 'Dados pessoais inválidos'; END IF;
  IF (p->>'birth_date')::date>current_date THEN RAISE EXCEPTION 'Nascimento inválido'; END IF;
  FOREACH k IN ARRAY ARRAY['unhealthy','dangerous','father_na','mother_na'] LOOP
   IF jsonb_typeof(p->k) IS DISTINCT FROM 'boolean' THEN RAISE EXCEPTION 'Escolha obrigatória: %',k; END IF;
  END LOOP;
  IF jsonb_typeof(p->'hourly_rate') IS DISTINCT FROM 'number' OR (p->>'hourly_rate')::numeric<0 OR (p->>'hourly_rate')::numeric>9999999999 THEN RAISE EXCEPTION 'Valor da hora inválido'; END IF;
  IF (p->>'father_na')::boolean=false AND coalesce(length(trim(p->>'father')),0)=0 OR (p->>'mother_na')::boolean=false AND coalesce(length(trim(p->>'mother')),0)=0 THEN RAISE EXCEPTION 'Informe os pais ou não se aplica'; END IF;
  FOREACH k IN ARRAY ARRAY['work_card','pis','voter','residence','license','education','birth','cpf','rg','other','reservist'] LOOP
   IF k='reservist' AND p->>'sex'<>'masculino' THEN CONTINUE; END IF;
   doc:=NEW.documents->k;
   IF coalesce(doc->>'na','false')<>'true' AND coalesce(doc->>'path','')='' THEN RAISE EXCEPTION 'Documento obrigatório: %',k; END IF;
  END LOOP;
 ELSE
  IF NEW.birth_date>current_date THEN RAISE EXCEPTION 'Nascimento inválido'; END IF;
 END IF;
 IF jsonb_typeof(NEW.documents) IS DISTINCT FROM 'object' THEN RAISE EXCEPTION 'Documentos inválidos'; END IF;
 FOR k,doc IN SELECT * FROM jsonb_each(NEW.documents) LOOP
  IF jsonb_typeof(doc->'na') IS DISTINCT FROM 'boolean' THEN RAISE EXCEPTION 'Documento inválido'; END IF;
  IF coalesce(doc->>'path','')<>'' AND ((doc->>'path') NOT LIKE NEW.owner_id::text||'/%' OR (doc->>'path') !~ '\.(png|jpg|jpeg|pdf)$') THEN RAISE EXCEPTION 'Arquivo inválido'; END IF;
 END LOOP;
 RETURN NEW;
END $$;
CREATE TRIGGER validate_employee BEFORE INSERT OR UPDATE ON public.employees FOR EACH ROW EXECUTE FUNCTION public.validate_people_record();
CREATE TRIGGER validate_dependent BEFORE INSERT OR UPDATE ON public.dependents FOR EACH ROW EXECUTE FUNCTION public.validate_people_record();
CREATE POLICY people_upload ON storage.objects FOR INSERT TO authenticated WITH CHECK(bucket_id='people-documents' AND (storage.foldername(name))[1]=auth.uid()::text AND lower(storage.extension(name)) IN ('png','jpg','jpeg','pdf') AND (metadata->>'mimetype') IN ('image/png','image/jpeg','application/pdf'));
CREATE POLICY people_read ON storage.objects FOR SELECT TO authenticated USING(bucket_id='people-documents' AND (storage.foldername(name))[1]=auth.uid()::text);
CREATE POLICY people_delete ON storage.objects FOR DELETE TO authenticated USING(bucket_id='people-documents' AND (storage.foldername(name))[1]=auth.uid()::text);