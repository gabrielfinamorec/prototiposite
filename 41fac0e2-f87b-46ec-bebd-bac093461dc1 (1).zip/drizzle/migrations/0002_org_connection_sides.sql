ALTER TABLE public.org_connections ADD COLUMN source_handle text NOT NULL DEFAULT 'right' CHECK (source_handle IN ('top','right','bottom','left'));
ALTER TABLE public.org_connections ADD COLUMN target_handle text NOT NULL DEFAULT 'left' CHECK (target_handle IN ('top','right','bottom','left'));
GRANT SELECT, INSERT, UPDATE, DELETE ON public.org_connections TO authenticated;
GRANT ALL ON public.org_connections TO service_role;