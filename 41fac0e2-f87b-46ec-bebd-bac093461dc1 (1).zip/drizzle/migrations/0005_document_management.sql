CREATE TABLE public.document_types (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL DEFAULT auth.uid(), name text NOT NULL,
 has_expiry boolean NOT NULL DEFAULT false, duration integer NOT NULL DEFAULT 1 CHECK(duration BETWEEN 1 AND 999), unit text NOT NULL DEFAULT 'dias' CHECK(unit IN ('dias','semanas','meses','anos')),
 responsible_id uuid NOT NULL, department_ids uuid[] NOT NULL DEFAULT '{}', job_ids uuid[] NOT NULL DEFAULT '{}', employee_ids uuid[] NOT NULL DEFAULT '{}',
 guidance text NOT NULL DEFAULT '', active boolean NOT NULL DEFAULT true, attachments jsonb NOT NULL DEFAULT '[]', created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(id,owner_id)
);
GRANT SELECT,INSERT,UPDATE,DELETE ON public.document_types TO authenticated; GRANT ALL ON public.document_types TO service_role;
ALTER TABLE public.document_types ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_access ON public.document_types FOR ALL TO authenticated USING(owner_id=auth.uid()) WITH CHECK(owner_id=auth.uid());
CREATE TABLE public.controlled_documents (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL DEFAULT auth.uid(), type_id uuid NOT NULL, employee_id uuid NOT NULL, company_id uuid NOT NULL,
 state text NOT NULL DEFAULT 'pendente' CHECK(state IN ('pendente','em dia','cancelado')), issue_date date, expiry_date date, notes text NOT NULL DEFAULT '', attachments jsonb NOT NULL DEFAULT '[]',
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), UNIQUE(type_id,employee_id,owner_id), UNIQUE(id,owner_id),
 FOREIGN KEY(type_id,owner_id) REFERENCES public.document_types(id,owner_id),
 FOREIGN KEY(employee_id,company_id,owner_id) REFERENCES public.employees(id,company_id,owner_id)
);
GRANT SELECT,INSERT,UPDATE ON public.controlled_documents TO authenticated; GRANT ALL ON public.controlled_documents TO service_role;
ALTER TABLE public.controlled_documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_access ON public.controlled_documents FOR ALL TO authenticated USING(owner_id=auth.uid()) WITH CHECK(owner_id=auth.uid());
CREATE TABLE public.document_history (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL DEFAULT auth.uid(), document_id uuid NOT NULL, action text NOT NULL, snapshot jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(document_id,owner_id) REFERENCES public.controlled_documents(id,owner_id)
);
GRANT SELECT,INSERT ON public.document_history TO authenticated; GRANT ALL ON public.document_history TO service_role;
ALTER TABLE public.document_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_read ON public.document_history FOR SELECT TO authenticated USING(owner_id=auth.uid());
CREATE POLICY owner_insert ON public.document_history FOR INSERT TO authenticated WITH CHECK(owner_id=auth.uid());
CREATE FUNCTION public.validate_document_type() RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM public.employees WHERE id=NEW.responsible_id AND owner_id=NEW.owner_id) THEN RAISE EXCEPTION 'Selecione um responsável cadastrado'; END IF;
 IF EXISTS(SELECT 1 FROM unnest(NEW.department_ids) x WHERE NOT EXISTS(SELECT 1 FROM public.departments WHERE id=x AND owner_id=NEW.owner_id)) OR EXISTS(SELECT 1 FROM unnest(NEW.job_ids) x WHERE NOT EXISTS(SELECT 1 FROM public.jobs WHERE id=x AND owner_id=NEW.owner_id)) OR EXISTS(SELECT 1 FROM unnest(NEW.employee_ids) x WHERE NOT EXISTS(SELECT 1 FROM public.employees WHERE id=x AND owner_id=NEW.owner_id)) THEN RAISE EXCEPTION 'Atribuição inválida'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER document_type_validation BEFORE INSERT OR UPDATE ON public.document_types FOR EACH ROW EXECUTE FUNCTION public.validate_document_type();
CREATE FUNCTION public.sync_document_assignments(_owner uuid) RETURNS void LANGUAGE plpgsql SECURITY INVOKER SET search_path=public AS $$
BEGIN
 INSERT INTO public.controlled_documents(owner_id,type_id,employee_id,company_id)
 SELECT t.owner_id,t.id,e.id,e.company_id FROM public.document_types t JOIN public.employees e ON e.owner_id=t.owner_id JOIN public.jobs j ON j.id=e.job_id AND j.owner_id=e.owner_id
 WHERE t.owner_id=_owner AND t.active AND (e.id=ANY(t.employee_ids) OR e.job_id=ANY(t.job_ids) OR j.department_id=ANY(t.department_ids)) ON CONFLICT(type_id,employee_id,owner_id) DO NOTHING;
 UPDATE public.controlled_documents d SET state='cancelado' WHERE d.owner_id=_owner AND d.state<>'cancelado' AND NOT EXISTS(
 SELECT 1 FROM public.document_types t JOIN public.employees e ON e.id=d.employee_id AND e.owner_id=t.owner_id JOIN public.jobs j ON j.id=e.job_id AND j.owner_id=e.owner_id WHERE t.id=d.type_id AND t.active AND (e.id=ANY(t.employee_ids) OR e.job_id=ANY(t.job_ids) OR j.department_id=ANY(t.department_ids)));
END $$;
CREATE FUNCTION public.document_assignment_trigger() RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$ BEGIN PERFORM public.sync_document_assignments(NEW.owner_id); RETURN NEW; END $$;
CREATE TRIGGER document_type_sync AFTER INSERT OR UPDATE ON public.document_types FOR EACH ROW EXECUTE FUNCTION public.document_assignment_trigger();
CREATE TRIGGER employee_document_sync AFTER INSERT OR UPDATE ON public.employees FOR EACH ROW EXECUTE FUNCTION public.document_assignment_trigger();
CREATE TRIGGER job_document_sync AFTER UPDATE ON public.jobs FOR EACH ROW EXECUTE FUNCTION public.document_assignment_trigger();
CREATE FUNCTION public.document_audit_trigger() RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$
BEGIN
 IF TG_OP='INSERT' THEN INSERT INTO public.document_history(owner_id,document_id,action,snapshot) VALUES(NEW.owner_id,NEW.id,'Criado',to_jsonb(NEW));
 ELSIF NEW IS DISTINCT FROM OLD THEN
 INSERT INTO public.document_history(owner_id,document_id,action,snapshot) VALUES(NEW.owner_id,NEW.id,CASE WHEN NEW.state='cancelado' AND OLD.state<>'cancelado' THEN 'Cancelado' WHEN NEW.state='em dia' AND OLD.state<>'em dia' THEN 'Validado' WHEN NEW.state='pendente' AND OLD.state<>'pendente' THEN 'Renovação iniciada' ELSE 'Informações atualizadas' END,jsonb_build_object('anterior',to_jsonb(OLD),'atual',to_jsonb(NEW)));
 END IF; RETURN NEW;
END $$;
CREATE TRIGGER document_audit AFTER INSERT OR UPDATE ON public.controlled_documents FOR EACH ROW EXECUTE FUNCTION public.document_audit_trigger();
CREATE FUNCTION public.document_action(_ids uuid[],_action text) RETURNS void LANGUAGE plpgsql SECURITY INVOKER SET search_path=public AS $$
DECLARE d record; t record; today date := (now() AT TIME ZONE 'America/Sao_Paulo')::date;
BEGIN
 IF _action NOT IN ('validar','renovar','cancelar') OR cardinality(_ids)=0 THEN RAISE EXCEPTION 'Ação inválida'; END IF;
 IF (SELECT count(*) FROM public.controlled_documents WHERE id=ANY(_ids) AND owner_id=auth.uid())<>cardinality(_ids) THEN RAISE EXCEPTION 'Documento não encontrado'; END IF;
 FOR d IN SELECT * FROM public.controlled_documents WHERE id=ANY(_ids) AND owner_id=auth.uid() FOR UPDATE LOOP
 SELECT * INTO t FROM public.document_types WHERE id=d.type_id AND owner_id=auth.uid();
 IF _action='validar' THEN
 IF d.state<>'pendente' OR NOT t.active OR d.issue_date IS NULL OR d.issue_date>today OR (t.has_expiry AND (d.expiry_date IS NULL OR d.expiry_date<today)) THEN RAISE EXCEPTION 'Preencha a emissão e uma validade vigente em todos os documentos pendentes'; END IF;
 UPDATE public.controlled_documents SET state='em dia',updated_at=now() WHERE id=d.id;
 ELSIF _action='renovar' THEN
 IF NOT t.active OR d.state<>'em dia' OR d.expiry_date IS NULL OR d.expiry_date>=today THEN RAISE EXCEPTION 'Somente documentos vencidos podem ser renovados'; END IF;
 UPDATE public.controlled_documents SET state='pendente',issue_date=NULL,expiry_date=NULL,attachments='[]',notes='',updated_at=now() WHERE id=d.id;
 ELSE UPDATE public.controlled_documents SET state='cancelado',updated_at=now() WHERE id=d.id; END IF;
 END LOOP;
END $$;
REVOKE ALL ON FUNCTION public.document_action(uuid[],text) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.document_action(uuid[],text) TO authenticated,service_role;
REVOKE ALL ON FUNCTION public.sync_document_assignments(uuid) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.sync_document_assignments(uuid) TO authenticated,service_role;