CREATE TABLE public.employee_faces (
  employee_id uuid PRIMARY KEY,
  owner_id uuid NOT NULL DEFAULT auth.uid(),
  company_id uuid NOT NULL,
  photo_path text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (employee_id, company_id, owner_id) REFERENCES public.employees(id, company_id, owner_id) ON DELETE CASCADE
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.employee_faces TO authenticated;
GRANT ALL ON public.employee_faces TO service_role;
ALTER TABLE public.employee_faces ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_access ON public.employee_faces FOR ALL TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());

CREATE TABLE public.meal_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL DEFAULT auth.uid(),
  company_id uuid NOT NULL,
  employee_id uuid NOT NULL,
  meal_date date NOT NULL DEFAULT ((now() AT TIME ZONE 'America/Sao_Paulo')::date),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (employee_id, meal_date),
  FOREIGN KEY (employee_id, company_id, owner_id) REFERENCES public.employees(id, company_id, owner_id) ON DELETE CASCADE
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.meal_logs TO authenticated;
GRANT ALL ON public.meal_logs TO service_role;
ALTER TABLE public.meal_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_access ON public.meal_logs FOR ALL TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());