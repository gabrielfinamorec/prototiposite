CREATE TABLE public.company_calendar_days (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL DEFAULT auth.uid(),
  company_id uuid NOT NULL,
  day date NOT NULL,
  kind text NOT NULL CHECK (kind IN ('trabalhado','obrigatorio','facultativo','recesso','folga')),
  title text NOT NULL DEFAULT '' CHECK (char_length(title) <= 150),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, day, owner_id),
  FOREIGN KEY (company_id, owner_id) REFERENCES public.companies(id, owner_id) ON DELETE CASCADE
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.company_calendar_days TO authenticated;
GRANT ALL ON public.company_calendar_days TO service_role;
ALTER TABLE public.company_calendar_days ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_access ON public.company_calendar_days FOR ALL TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());