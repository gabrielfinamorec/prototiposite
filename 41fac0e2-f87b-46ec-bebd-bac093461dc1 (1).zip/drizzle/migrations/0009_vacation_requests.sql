CREATE TABLE public.vacation_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL DEFAULT auth.uid(),
  company_id uuid NOT NULL,
  employee_id uuid NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  state text NOT NULL DEFAULT 'pendente' CHECK (state IN ('pendente','aprovada','cancelada')),
  finished boolean NOT NULL DEFAULT false,
  notes text NOT NULL DEFAULT '' CHECK (char_length(notes) <= 2000),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (end_date >= start_date AND end_date - start_date < 366),
  FOREIGN KEY (employee_id, company_id, owner_id) REFERENCES public.employees(id, company_id, owner_id) ON DELETE CASCADE
);
CREATE INDEX vacation_requests_employee_idx ON public.vacation_requests(employee_id, start_date);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vacation_requests TO authenticated;
GRANT ALL ON public.vacation_requests TO service_role;
ALTER TABLE public.vacation_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_access ON public.vacation_requests FOR ALL TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());