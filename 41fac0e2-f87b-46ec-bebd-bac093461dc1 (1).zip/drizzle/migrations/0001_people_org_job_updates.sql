ALTER TABLE public.jobs DROP CONSTRAINT jobs_attachments_check;
ALTER TABLE public.jobs ADD COLUMN no_superior boolean NOT NULL DEFAULT false;
ALTER TABLE public.jobs ADD CONSTRAINT jobs_no_superior_check CHECK (NOT no_superior OR superior_id IS NULL);
CREATE TABLE public.org_connections (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL DEFAULT auth.uid(), company_id uuid NOT NULL, source_id uuid NOT NULL, target_id uuid NOT NULL,
 FOREIGN KEY (source_id, company_id, owner_id) REFERENCES public.jobs(id, company_id, owner_id) ON DELETE CASCADE,
 FOREIGN KEY (target_id, company_id, owner_id) REFERENCES public.jobs(id, company_id, owner_id) ON DELETE CASCADE,
 UNIQUE (source_id,target_id), CHECK (source_id <> target_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.org_connections TO authenticated;
GRANT ALL ON public.org_connections TO service_role;
ALTER TABLE public.org_connections ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_access ON public.org_connections FOR ALL TO authenticated USING (owner_id=auth.uid()) WITH CHECK (owner_id=auth.uid());