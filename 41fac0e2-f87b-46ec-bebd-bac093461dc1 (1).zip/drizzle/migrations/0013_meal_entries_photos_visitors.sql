CREATE TABLE public.meal_entries (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 owner_id uuid NOT NULL DEFAULT auth.uid(),
 company_id uuid NOT NULL,
 employee_id uuid,
 visitor_name text,
 meal_date date NOT NULL DEFAULT ((now() AT TIME ZONE 'America/Sao_Paulo')::date),
 served_at timestamptz NOT NULL DEFAULT now(),
 created_at timestamptz NOT NULL DEFAULT now(),
 source text NOT NULL CHECK (source IN ('facial','manual','visita','legacy')),
 photo_path text,
 CHECK ((employee_id IS NOT NULL AND visitor_name IS NULL) OR (employee_id IS NULL AND length(trim(visitor_name)) BETWEEN 1 AND 150)),
 CHECK (source = 'legacy' OR (photo_path IS NOT NULL AND photo_path LIKE owner_id::text || '/meals/%')),
 CHECK (source NOT IN ('facial','legacy') OR employee_id IS NOT NULL),
 CHECK (source <> 'visita' OR employee_id IS NULL),
 CHECK (meal_date = (served_at AT TIME ZONE 'America/Sao_Paulo')::date),
 FOREIGN KEY (company_id,owner_id) REFERENCES public.companies(id,owner_id),
 FOREIGN KEY (employee_id,company_id,owner_id) REFERENCES public.employees(id,company_id,owner_id)
);
GRANT SELECT,INSERT,UPDATE,DELETE ON public.meal_entries TO authenticated;
GRANT ALL ON public.meal_entries TO service_role;
ALTER TABLE public.meal_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_access ON public.meal_entries FOR ALL TO authenticated USING (owner_id=auth.uid()) WITH CHECK (owner_id=auth.uid());
CREATE UNIQUE INDEX meal_entries_daily_facial ON public.meal_entries(employee_id,meal_date) WHERE source='facial';
CREATE INDEX meal_entries_owner_date ON public.meal_entries(owner_id,meal_date DESC);
INSERT INTO public.meal_entries (id,owner_id,company_id,employee_id,meal_date,served_at,created_at,source)
SELECT id,owner_id,company_id,employee_id,meal_date,(meal_date + (created_at AT TIME ZONE 'America/Sao_Paulo')::time) AT TIME ZONE 'America/Sao_Paulo',created_at,'legacy' FROM public.meal_logs;
COMMENT ON TABLE public.meal_logs IS 'DEPRECATED: replaced by meal_entries for manual and visitor meals with private capture photos';