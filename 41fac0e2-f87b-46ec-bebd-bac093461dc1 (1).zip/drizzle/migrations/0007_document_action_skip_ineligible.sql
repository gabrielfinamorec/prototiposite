CREATE OR REPLACE FUNCTION public.document_action(_ids uuid[], _action text)
 RETURNS void LANGUAGE plpgsql SET search_path TO 'public'
AS $function$
DECLARE d record; t record; today date := (now() AT TIME ZONE 'America/Sao_Paulo')::date;
BEGIN
 IF _action NOT IN ('validar','desfazer_validacao','renovar','cancelar','desfazer_cancelamento') OR cardinality(_ids)=0 THEN RAISE EXCEPTION 'Ação inválida'; END IF;
 IF (SELECT count(*) FROM public.controlled_documents WHERE id=ANY(_ids) AND owner_id=auth.uid())<>cardinality(_ids) THEN RAISE EXCEPTION 'Documento não encontrado'; END IF;
 FOR d IN SELECT * FROM public.controlled_documents WHERE id=ANY(_ids) AND owner_id=auth.uid() FOR UPDATE LOOP
 SELECT * INTO t FROM public.document_types WHERE id=d.type_id AND owner_id=auth.uid();
 IF _action='validar' THEN
  CONTINUE WHEN d.state<>'pendente';
  IF NOT t.active OR d.issue_date IS NULL OR d.issue_date>today OR (t.has_expiry AND (d.expiry_date IS NULL OR d.expiry_date<today)) THEN RAISE EXCEPTION 'Há documentos pendentes sem data de emissão ou com validade vencida (%). Preencha antes de validar', t.name; END IF;
  UPDATE public.controlled_documents SET state='em dia',updated_at=now() WHERE id=d.id;
 ELSIF _action='desfazer_validacao' THEN
  CONTINUE WHEN d.state<>'em dia';
  UPDATE public.controlled_documents SET state='pendente',updated_at=now() WHERE id=d.id;
 ELSIF _action='renovar' THEN
  CONTINUE WHEN d.state='cancelado';
  UPDATE public.controlled_documents SET state='pendente',issue_date=NULL,expiry_date=NULL,attachments='[]',notes='',updated_at=now() WHERE id=d.id;
 ELSIF _action='cancelar' THEN
  CONTINUE WHEN d.state='cancelado';
  UPDATE public.controlled_documents SET state='cancelado',updated_at=now() WHERE id=d.id;
 ELSE
  CONTINUE WHEN d.state<>'cancelado';
  UPDATE public.controlled_documents SET state='pendente',updated_at=now() WHERE id=d.id;
 END IF;
 END LOOP;
END $function$;