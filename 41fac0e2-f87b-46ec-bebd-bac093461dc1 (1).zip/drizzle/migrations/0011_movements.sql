CREATE TABLE public.movement_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL DEFAULT auth.uid(),
  kind text NOT NULL CHECK (kind IN ('atestado','afastamento','demissao')),
  name text NOT NULL CHECK (char_length(btrim(name)) BETWEEN 1 AND 200),
  description text NOT NULL DEFAULT '' CHECK (char_length(description) <= 4000),
  initiative text NOT NULL DEFAULT '' CHECK (initiative IN ('','empresa','colaborador','outro')),
  requires_document boolean NOT NULL DEFAULT false,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, owner_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.movement_types TO authenticated;
GRANT ALL ON public.movement_types TO service_role;
ALTER TABLE public.movement_types ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_access ON public.movement_types FOR ALL TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());

CREATE TABLE public.employee_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL DEFAULT auth.uid(),
  kind text NOT NULL CHECK (kind IN ('atestado','afastamento','demissao')),
  company_id uuid NOT NULL,
  employee_id uuid NOT NULL,
  type_id uuid NOT NULL,
  start_date date NOT NULL,
  end_date date,
  return_date date,
  has_notice boolean NOT NULL DEFAULT false,
  notice_type text NOT NULL DEFAULT '' CHECK (notice_type IN ('','trabalhado','indenizado')),
  notice_start date,
  notice_end date,
  notes text NOT NULL DEFAULT '' CHECK (char_length(notes) <= 4000),
  attachments jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (employee_id, company_id, owner_id) REFERENCES public.employees(id, company_id, owner_id) ON DELETE CASCADE,
  FOREIGN KEY (type_id, owner_id) REFERENCES public.movement_types(id, owner_id),
  CHECK (end_date IS NULL OR end_date >= start_date),
  CHECK (return_date IS NULL OR return_date >= start_date),
  CHECK (NOT has_notice OR (notice_type <> '' AND notice_start IS NOT NULL AND notice_end IS NOT NULL AND notice_end >= notice_start))
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.employee_movements TO authenticated;
GRANT ALL ON public.employee_movements TO service_role;
ALTER TABLE public.employee_movements ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_access ON public.employee_movements FOR ALL TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());