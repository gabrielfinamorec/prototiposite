CREATE TABLE public.companies (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL DEFAULT auth.uid(), name text NOT NULL CHECK(length(trim(name)) BETWEEN 1 AND 150), cnpj text NOT NULL CHECK(cnpj ~ '^[0-9]{14}$'), created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(id,owner_id), UNIQUE(owner_id,cnpj));
GRANT SELECT,INSERT,UPDATE,DELETE ON public.companies TO authenticated; GRANT ALL ON public.companies TO service_role;
ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_access ON public.companies FOR ALL TO authenticated USING(owner_id=auth.uid()) WITH CHECK(owner_id=auth.uid());
CREATE TABLE public.departments (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL DEFAULT auth.uid(), company_id uuid NOT NULL, name text NOT NULL CHECK(length(trim(name)) BETWEEN 1 AND 150), active boolean NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(id,company_id,owner_id), FOREIGN KEY(company_id,owner_id) REFERENCES public.companies(id,owner_id) ON DELETE RESTRICT);
GRANT SELECT,INSERT,UPDATE,DELETE ON public.departments TO authenticated; GRANT ALL ON public.departments TO service_role;
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_access ON public.departments FOR ALL TO authenticated USING(owner_id=auth.uid()) WITH CHECK(owner_id=auth.uid());
CREATE TABLE public.jobs (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_id uuid NOT NULL DEFAULT auth.uid(), company_id uuid NOT NULL, department_id uuid NOT NULL, name text NOT NULL CHECK(length(trim(name)) BETWEEN 1 AND 150), cbo text NOT NULL CHECK(length(trim(cbo)) BETWEEN 1 AND 30), hourly_rate numeric(12,2) NOT NULL CHECK(hourly_rate>=0), superior_id uuid, details jsonb NOT NULL, attachments text[] NOT NULL CHECK(cardinality(attachments)>0), position_x double precision NOT NULL DEFAULT 0, position_y double precision NOT NULL DEFAULT 0, created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(id,company_id,owner_id), FOREIGN KEY(department_id,company_id,owner_id) REFERENCES public.departments(id,company_id,owner_id) ON DELETE RESTRICT, FOREIGN KEY(superior_id,company_id,owner_id) REFERENCES public.jobs(id,company_id,owner_id) ON DELETE RESTRICT, CHECK(superior_id IS DISTINCT FROM id));
GRANT SELECT,INSERT,UPDATE,DELETE ON public.jobs TO authenticated; GRANT ALL ON public.jobs TO service_role;
ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_access ON public.jobs FOR ALL TO authenticated USING(owner_id=auth.uid()) WITH CHECK(owner_id=auth.uid());
CREATE FUNCTION public.validate_job() RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$ DECLARE k text; BEGIN
FOREACH k IN ARRAY ARRAY['summary','knowledge','availability','epi','education','experience','training','behavior'] LOOP
IF new.details->>k IS NULL OR length(trim(new.details->>k))=0 OR length(new.details->>k)>5000 THEN RAISE EXCEPTION 'Todos os campos do cargo são obrigatórios.'; END IF;
END LOOP;
IF new.superior_id IS NOT NULL AND EXISTS(WITH RECURSIVE ancestors AS (SELECT id,superior_id FROM public.jobs WHERE id=new.superior_id UNION SELECT j.id,j.superior_id FROM public.jobs j JOIN ancestors a ON j.id=a.superior_id) SELECT 1 FROM ancestors WHERE id=new.id) THEN RAISE EXCEPTION 'A hierarquia não pode conter ciclos.'; END IF;
RETURN new; END; $$;
CREATE TRIGGER validate_job_before_save BEFORE INSERT OR UPDATE ON public.jobs FOR EACH ROW EXECUTE FUNCTION public.validate_job();
CREATE POLICY job_files_read ON storage.objects FOR SELECT TO authenticated USING(bucket_id='job-files' AND (storage.foldername(name))[1]=auth.uid()::text);
CREATE POLICY job_files_insert ON storage.objects FOR INSERT TO authenticated WITH CHECK(bucket_id='job-files' AND (storage.foldername(name))[1]=auth.uid()::text);
CREATE POLICY job_files_delete ON storage.objects FOR DELETE TO authenticated USING(bucket_id='job-files' AND (storage.foldername(name))[1]=auth.uid()::text);